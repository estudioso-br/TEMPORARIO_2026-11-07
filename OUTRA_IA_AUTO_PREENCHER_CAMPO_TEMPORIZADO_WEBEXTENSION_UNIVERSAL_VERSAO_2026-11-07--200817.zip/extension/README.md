# Auto Preencher Campo Temporizado — v4.0.0, pacote WebExtension universal

**Um único `manifest.json` e uma única árvore de código** para Firefox 121+ e Chrome/Chromium 121+.
Firefox usa `background.scripts`, enquanto Chrome usa `background.service_worker`.
Edge, Brave e Opera Chromium recentes são candidatos à compatibilidade, mas requerem verificação própria.

## Instalação

1. Extraia o ZIP. Localize a pasta `extension`, que contém o `manifest.json`.
2. **Chrome/Chromium:** `chrome://extensions` → Modo do desenvolvedor → Carregar sem compactação → selecione a pasta `extension`.
3. **Firefox:** `about:debugging` → Este Firefox → Carregar extensão temporária → selecione `extension/manifest.json`.
4. Para instalação **permanente** no Firefox, é necessária assinatura por Mozilla e empacotamento adequado como XPI. A execução com `about:debugging` é temporária.
5. Abra a aba desejada, use o popup da extensão para **Vincular aba atual** e depois **Ativar / retomar**. Em uma atualização da v3, a extensão **é desativada** até a nova vinculação.

O ZIP é uma árvore-fonte única, não uma promessa de arquivo instalador assinado idêntico em todas as lojas.

## Utilização resumida

- Configure intervalo de horas/minutos? O **intervalo de envio** usa minutos e segundos, com jitter positivo opcional; o limite mínimo prático é 30 s. A execução por alarmes pode atrasar.
- Configure os localizadores do campo: CSS, CSS Path, XPath (curto/longo), outerHTML; reservas tipadas aceitam `css|seletor`, `xpath|expressão` etc.
- O modo **auto** prioriza **clique no botão**; caso não encontre, dispara eventos sintéticos de Enter. Eventos sintéticos não equivalem a uma tecla física e podem ser ignorados pelo site.
- Os métodos de confirmação são: `dispatch` (comando disparado, **sem prova remota**), `field-cleared` (campo esvaziado, **indício de aceitação**) e `selector` (surge um novo elemento compatível com o seletor CSS especificado, também uma evidência de interface, não necessariamente de entrega remota).
- No modo **simulação (dry-run)**, a extensão verifica o alvo e contabiliza o ciclo, mas não altera o campo nem envia a mensagem.
- `runOnLoad` agora **não cria ciclos adicionais**: uma página recarregada só pode disparar o ciclo quando o prazo persistente de execução já venceu.
- Na v4, o escopo automático “aba ativa” ou “primeira aba” da v3 foi substituído por **vinculação explícita de uma aba** para impedir envios em páginas não pretendidas. O campo `scope` foi conservado para importação compatível, mas não determina mais a aba de execução.

## Supervisor e recuperação

O supervisor roda separadamente do temporizador de mensagens (`alarms`, com intervalo de verificação configurável). Inspeciona a aba vinculada e realiza `tabs.sendMessage(APC_PING)` para confirmar se o campo existe, é visível e está habilitado. Quando o método é `button`, verifica a disponibilidade do botão. Ausência do campo, falha na comunicação ou página descartada podem acionar recargas **limitadas** por `tabs.reload` ou restauração do URL previamente vinculado, respeitando a origem autorizada.

A supervisão opera inclusive com o popup fechado, **desde que o navegador esteja executando e os alarmes possam disparar**. Não é possível garantir recuperação de fechamento completo do navegador, indisponibilidade prolongada do serviço remoto, interrupções do SO nem qualquer crash simultâneo da própria extensão.

O seletor opcional **bloqueio** (`blockedSelector`) interrompe a sessão quando corresponder a um elemento visível de login, CAPTCHA ou aviso que deva exigir intervenção humana. A extensão **não contorna** autenticação, CAPTCHA ou bloqueios de acesso. O campo pode parecer utilizável sem que o servidor esteja pronto; a confirmação remota depende do site.

## Garantia contra duplicação (limitação expressa)

A v4 mantém um `pendingCycle` persistido **antes** de invocar o envio na página. Depois de uma interrupção durante a tentativa, o resultado é marcado `uncertain` e os envios param até intervenção manual. Não é legítimo reexecutar automaticamente uma transação cujo resultado remoto é desconhecido.

Um envio classificado como `dispatch` conta como **ciclo disparado**, e não como entrega confirmada. A contagem por interface (`selector`, `field-cleared`) também não substitui uma API transacional do serviço remoto. Um sistema totalmente genérico **não consegue garantir entrega exatamente uma vez**.

**Para desbloquear um `uncertain`:** verifique no site se a mensagem anterior chegou, pause, escolha “Reiniciar sessão”, confirme o aviso e ative de novo. Reiniciar a sessão zera contadores e equivale a decisão manual de nova automação; jamais trate essa ação como reenvio automaticamente seguro.

## Limites por ciclos e por duração

Os limites opcionais são independentes. Quando ambos são habilitados, vence o primeiro a ser alcançado. `maxCycles` contabiliza os ciclos concluídos segundo o critério de confirmação selecionado. Os campos `durationHours`, `durationMinutes`, `durationSeconds` definem a duração:

- `wall`: tempo corrido desde a ativação inicial, **incluindo pausas, navegador fechado e recargas**; relógio persistido em milissegundos da época Unix.
- `active`: aproxima o tempo efetivo em sessão `running` e exclui pausas e recuperação. Na retomada do processo em segundo plano, o cálculo limita o intervalo não supervisionado em até dois períodos de heartbeat. **Não é medição exata do tempo efetivamente operacional**, especialmente quando o navegador passa muito tempo fechado. Prefira `wall` se precisão/limite rígido for requisito.

Os limites não reiniciam quando a aba é recarregada; alterar configurações não zera os contadores. O botão “Reiniciar sessão” exige que a execução esteja pausada.

## Estado, logs, privacidade

- Estados persistentes: `idle`, `running`, `recovering`, `paused`, `uncertain`, `completed`.
- Os contadores, o identificador da aba, a origem autorizada, o prazo e o ciclo pendente ficam em `storage.local`.
- Perfis por origem: salve, recupere ou remova até 30 conjuntos de configurações na aba **Configurações**. Não ativam automaticamente a sessão nem selecionam outra aba.
- Logs locais limitados aos 500 eventos mais recentes, exportáveis em TXT; mensagens não são incluídas automaticamente no log.
- As permissões `tabs` e `content_scripts.matches: ["<all_urls>"]` são abrangentes para permitir seleção de sites arbitrários. **A execução de envio só é autorizada para a aba vinculada e sua origem.** Caso use a extensão com dados sensíveis, reveja cuidadosamente as permissões e o destino das mensagens.
- A extensão não implementa telemetria própria nem transmissão externa independente. O texto enviado, porém, é entregue ao site de destino, sujeito às práticas desse serviço.

## Conferência do pacote / execução de testes

Os testes ficam em `tests/`. Dependem de:

- `node tests/test-supervisor.cjs` — Node.js 22+, testes determinísticos com APIs simuladas: instalação/migração, alarme, limites, recarga, recuperação, estado incerto, reinício do worker.
- `python tests/test-content-browser.py` — Python com Playwright e Chromium local. Exercita o DOM real, o botão, a confirmação por seletor, o `dryRun`, a deduplicação e o resultado incerto por Enter sintético.

Os testes **não substituem** a instalação manual e a verificação no Firefox e no Chrome com a extensão carregada. O empacotador do Chromium aceitou o manifesto, mas o ensaio automatizado de carregamento completo do *service worker* não pôde ser concluído neste ambiente. A disponibilidade do Firefox também não foi comprovada nesta execução.

## Compatibilidade e limitações

Fontes oficiais:
- MDN: https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/manifest.json/background
- MDN: https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/Build_a_cross_browser_extension
- Chrome: https://developer.chrome.com/docs/extensions/develop/concepts/service-workers/lifecycle/
- Chrome: https://developer.chrome.com/docs/extensions/reference/api/tabs/
- Mozilla: https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/manifest.json/browser_specific_settings

A instalação final em lojas depende de assinatura, revisão e requisitos particulares de cada loja. Nenhum mecanismo específico de bypass de CAPTCHA/limites do serviço foi adicionado.
