'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');const vm=require('node:vm');
const root=path.resolve(__dirname,'..');
function event() {const e={listeners:[]};e.addListener=fn=>e.listeners.push(fn);e.fire=(...args)=>e.listeners.forEach(fn=>fn(...args));return e;}
async function app() {
  const db={};const alarms=new Map();
  const events={};for(const x of ['installed','startup','alarm','updated','removed','message'])events[x]=event();
  let pageReady=true, sends=0, reloads=0, replies=[];
  const tab={id:42, url:'http://127.0.0.1:8764/demo.html',status:'complete'};
  const storage={local:{
    get:async keys=>{if(keys==null)return {...db};if(typeof keys==='string')return {[keys]:db[keys]};
      if(Array.isArray(keys))return Object.fromEntries(keys.map(k=>[k,db[k]]));
      return Object.fromEntries(Object.entries(keys).map(([k,v])=>[k,db[k]??v]));},
    set:async patch=>Object.assign(db,structuredClone(patch)),
    remove:async keys=>{for(const k of [keys].flat())delete db[k];}
  },onChanged:event()};
  const chrome={
    runtime:{onInstalled:events.installed,onStartup:events.startup,onMessage:events.message,getURL:uri=>'chrome-extension://test/'+uri},
    storage,alarms:{onAlarm:events.alarm,get:async name=>alarms.get(name)||null,
      clear:async name=>alarms.delete(name),create:(name,opts)=>alarms.set(name,{name,...opts})},
    tabs:{onUpdated:events.updated,onRemoved:events.removed,query:async()=>[{...tab}],get:async id=>{if(id!==42)throw Error('Not found');return {...tab};},
      reload:async()=>{reloads++;},update:async(id,p)=>{tab.url=p.url;reloads++;},
      sendMessage:async(id,msg)=>{
        if(id!==42)throw Error('wrong tab');
        if(msg.type==='APC_PING')return {ready:pageReady,reason:pageReady?'pronta':'inoperante'};
        if(msg.type==='APC_FILL') {sends++; if(replies.length)return replies.shift();
          return {ok:true,dispatched:true,confirmed:false,description:'comando simulado'};}
      }},
    action:{setBadgeBackgroundColor:async()=>{},setBadgeText:async()=>{}},
    notifications:{create:async()=>{}},
  };
  const context=vm.createContext({chrome,console,Date,Math,Promise,URL,setTimeout,clearTimeout,globalThis:null});
  context.globalThis=context;
  vm.runInContext(fs.readFileSync(path.join(root,'config.js'),'utf8'),context,{filename:'config.js'});
  vm.runInContext(fs.readFileSync(path.join(root,'background.js'),'utf8'),context,{filename:'background.js'});
  await vm.runInContext('queue(()=>bootstrap("test"))',context);
  return {context,db,alarms,tab,set ready(v){pageReady=v;},set replies(v){replies=v;},get sends(){return sends;},get reloads(){return reloads;},
    call:async expr=>vm.runInContext(`queue(async()=>(${expr}))`,context)};
}
async function main() {
  const {APC_SHARED:SH}=await (async()=>{const c={};c.globalThis=c;vm.runInNewContext(fs.readFileSync(path.join(root,'config.js'),'utf8'),c);return c;})();
  assert.equal(SH.normalize({...SH.DEFAULTS,maxCycles:0}).errors.length>0,true,'limites inválidos');
  assert.equal(SH.nextDelayMs({...SH.DEFAULTS,minutes:0,seconds:30}).milliseconds,30000);
  assert.equal(SH.durationMs({...SH.DEFAULTS,durationHours:1,durationMinutes:2,durationSeconds:3}),3723000);
  const one=await app();
  assert.equal(one.db.enabled,false,'migração inicia desativada');
  assert.equal((await one.call('bindCurrent()')).ok,true);
  await one.call('saveSettings({maxCyclesEnabled:true,maxCycles:2,runOnEnable:false,confirmationMode:"dispatch",notifyOnFail:false})');
  assert.equal((await one.call('setEnabled(true)')).ok,true);
  assert.equal((await one.call('runCycle(await session(),await config(),"teste 1")')).ok,true);
  assert.equal(one.db.apcSession.completedCycles,1);
  assert.equal((await one.call('runCycle(await session(),await config(),"teste 2")')).ok,true);
  assert.equal(one.db.apcSession.completedCycles,2);
  assert.equal(one.db.apcSession.status,'completed');
  assert.equal(one.db.enabled,false);
  assert.equal(one.sends,2);
  await assert.rejects(()=>one.call('setEnabled(true)'),/Limite já alcançado/);
  const two=await app();
  await two.call('bindCurrent()');
  await two.call('saveSettings({runOnEnable:false,notifyOnFail:false,recoveryFailures:2,maxReloads:3})');
  await two.call('setEnabled(true)');
  two.ready=false;
  await two.call('monitor("falha 1",{runDue:false})');
  assert.equal(two.reloads,0);
  await two.call('monitor("falha 2",{runDue:false})');
  assert.equal(two.reloads,1);
  assert.equal(two.db.apcSession.status,'recovering');
  two.ready=true;
  await two.call('monitor("recuperado",{runDue:false})');
  assert.equal(two.db.apcSession.status,'running');
  assert.equal(two.db.apcSession.reloads,0);
  const three=await app();
  await three.call('bindCurrent()');
  await three.call('saveSettings({runOnEnable:false,notifyOnFail:false})');
  await three.call('setEnabled(true)');
  three.replies=[{ok:false,maybeDispatched:true,reason:'confirmação ausente'}];
  await three.call('runCycle(await session(),await config(),"incerto")');
  assert.equal(three.db.apcSession.status,'uncertain');
  assert.equal(three.db.enabled,false);
  assert.equal(three.db.apcSession.completedCycles,0);
  assert.equal(three.sends,1);
  await assert.rejects(()=>three.call('setEnabled(true)'),/Envio incerto/);
  const four=await app();
  await four.call('bindCurrent()');
  await four.call('saveSettings({runOnEnable:false,notifyOnFail:false,durationEnabled:true,durationHours:0,durationMinutes:0,durationSeconds:1})');
  await four.call('setEnabled(true)');
  await four.call('((async()=>{const s=await session();s.startedAt=Date.now()-2000;await save(s);})())');
  await four.call('monitor("prazo")');
  assert.equal(four.db.apcSession.status,'completed');
  assert.equal(four.sends,0);
  const five=await app();
  await five.call('bindCurrent()');
  await five.call('saveSettings({runOnEnable:false,notifyOnFail:false,maxCyclesEnabled:true,maxCycles:3})');
  await five.call('setEnabled(true)');
  await five.call('((async()=>{const s=await session();s.pendingCycle={id:"sent-before-crash"};await save(s);})())');
  await five.call('bootstrap("restart simulated")');
  assert.equal(five.db.apcSession.status,'uncertain');
  assert.equal(five.sends,0);
  const six=await app();
  await six.call('bindCurrent()');
  await six.call('saveSettings({text:"PERFIL SITE",runOnEnable:false})');
  const saved=await six.call('saveProfile()');
  assert.equal(saved.origin,'http://127.0.0.1:8764');
  assert.equal((await six.call('listProfiles()')).length,1);
  await six.call('saveSettings({text:"MODIFICADO"})');
  await six.call('loadProfile("http://127.0.0.1:8764")');
  assert.equal(six.db.text,'PERFIL SITE');
  await six.call('deleteProfile("http://127.0.0.1:8764")');
  assert.equal((await six.call('listProfiles()')).length,0);
  assert.equal(six.db.enabled,false,'carregar perfil não deve ativar a sessão');
  console.log('PASSOU: perfis por origem salvos/carregados/excluídos sem habilitar execução');
  console.log('PASSOU: validação, cronograma, limite ciclos, recarga/retomada, incerteza, duração e reinício SW');
}
main().then(()=>console.log('TESTES: OK')).catch(e=>{console.error(e.stack||e);process.exitCode=1;});
