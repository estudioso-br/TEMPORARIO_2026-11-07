"""DOM integration test: Chromium with content.js injection, no extension install needed."""
from playwright.sync_api import sync_playwright
from pathlib import Path
import json
root=Path(__file__).parent.parent
html=(root/'tests/demo.html').read_text()
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page()
    page.goto('http://example.test/',wait_until='domcontentloaded') if False else None
    page.set_content(html)
    page.evaluate('''() => {
      window.chrome={runtime:{onMessage:{addListener:fn=>window.apcMessageHandler=fn},sendMessage:async()=>({ok:true})},
        storage:{local:{get:async()=>({enabled:false})}}};
    }''')
    page.add_script_tag(path=str(root/'content.js'))
    cfg={
      'selector':'.ProseMirror','selectorType':'css','fallbacks':'css|[contenteditable="true"]',
      'retries':0,'retryDelayMs':200,'text':'Mensagem teste 123','enterMode':'button',
      'sendButtonSelector':'#send','confirmationMode':'selector',
      'confirmationSelector':'.ack','confirmationTimeoutMs':1200,'dryRun':False
    }
    def call(message):
        return page.evaluate('''m=>new Promise(resolve=>window.apcMessageHandler(m,null,resolve))''',message)
    # about:blank page after set_content means origin='null' in JS location.origin
    origin=page.evaluate('location.origin')
    check=call({'type':'APC_PING','settings':cfg,'expectedOrigin':origin})
    assert check['ready'],check
    res=call({'type':'APC_FILL','cycleId':'one','settings':cfg,'expectedOrigin':origin})
    assert res['ok'] and res['confirmed'],res
    assert page.evaluate('window.apcMessages')==['Mensagem teste 123']
    repeat=call({'type':'APC_FILL','cycleId':'one','settings':cfg,'expectedOrigin':origin})
    assert repeat==res
    assert len(page.evaluate('window.apcMessages'))==1,'same cycleId must not send twice'
    dry={**cfg,'dryRun':True}
    r=call({'type':'APC_FILL','cycleId':'two','settings':dry,'expectedOrigin':origin})
    assert r['ok'] and r['dryRun']
    assert len(page.evaluate('window.apcMessages'))==1
    # Event-dispatched Enter cannot be assumed to submit; missing ack becomes uncertain.
    keys={**cfg,'enterMode':'keys','confirmationTimeoutMs':350}
    r=call({'type':'APC_FILL','cycleId':'three','settings':keys,'expectedOrigin':origin})
    assert not r['ok'] and r['maybeDispatched'],r
    assert len(page.evaluate('window.apcMessages'))==1
    page.locator('.ProseMirror').evaluate('(el)=>el.remove()')
    nofield=call({'type':'APC_PING','settings':cfg,'expectedOrigin':origin})
    assert not nofield['ready']
    page.evaluate("""() => {const b=document.createElement('div');b.id='block';b.style='display:block';b.textContent='Login necessário';document.body.append(b);}""")
    blocked=call({'type':'APC_PING','settings':{**cfg,'blockedSelector':'#block'},'expectedOrigin':origin})
    assert blocked['terminal'] and not blocked['ready'],blocked
    print('PASSOU: bloqueio explícito interrompe a prontidão operacional')
    print('PASSOU: campo, clique, confirmação DOM, deduplicação por ciclo, dry-run, Enter incerto, campo ausente')
    browser.close()
