/* Shared, dependency-free validation: browser event page, service worker, popup and options. */
(function (root) {
  'use strict';
  const DEFAULTS = Object.freeze({
    enabled: false, minutes: 37, seconds: 14,
    jitterEnabled: false, jitterMinSec: 0, jitterMaxSec: 300,
    selectorType: 'css', selector: '[aria-label="Pergunte ao ChatGPT"]',
    fallbacks: 'css|[contenteditable="true"][aria-multiline="true"]\ncss|div[role="textbox"]\ncss|.ProseMirror\nxpath-curto|//div[@contenteditable="true" and @role="textbox"]',
    text: 'GOSTEI. OBRIGADO', enterMode: 'auto', scope: 'active', urlContains: '',
    retries: 3, retryDelayMs: 1500, runOnEnable: true, runOnLoad: false,
    debugMode: true, notifyOnFail: true,
    blockedSelector: '', sendButtonSelector: '', confirmationMode: 'dispatch', confirmationSelector: '', confirmationTimeoutMs: 5000,
    watchdogEnabled: true, watchdogMinutes: 1, healthTimeoutMs: 8000,
    maxReloads: 3, recoveryBackoffSec: 30, recoveryFailures: 2,
    maxCyclesEnabled: false, maxCycles: 5,
    durationEnabled: false, durationHours: 3, durationMinutes: 30, durationSeconds: 0,
    durationMode: 'wall', dryRun: false
  });
  const CONFIG_KEYS = Object.freeze(Object.keys(DEFAULTS));
  const bools = new Set(CONFIG_KEYS.filter(k => typeof DEFAULTS[k] === 'boolean'));
  const nums = {
    minutes: [0, 10080], seconds: [0, 59], jitterMinSec: [0, 3600], jitterMaxSec: [0, 3600],
    retries: [0, 20], retryDelayMs: [200, 30000], confirmationTimeoutMs: [300, 15000],
    watchdogMinutes: [0.5, 60], healthTimeoutMs: [1000, 30000], maxReloads: [0, 10],
    recoveryBackoffSec: [30, 3600], recoveryFailures: [1, 10], maxCycles: [1, 100000],
    durationHours: [0, 87600], durationMinutes: [0, 59], durationSeconds: [0, 59]
  };
  const choices = {
    selectorType: ['css', 'cssPath', 'xpath', 'outerHTML'],
    enterMode: ['auto', 'keys', 'button', 'none'], scope: ['active', 'first'],
    confirmationMode: ['dispatch', 'field-cleared', 'selector'], durationMode: ['wall', 'active']
  };
  const strLimits = { selector: 10000, fallbacks: 30000, text: 20000,
    urlContains: 2000, blockedSelector: 5000, sendButtonSelector: 5000, confirmationSelector: 5000 };

  function normalize(raw, { strict = true } = {}) {
    const data = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
    const cfg = {};
    const errors = [];
    for (const key of CONFIG_KEYS) {
      let v = Object.prototype.hasOwnProperty.call(data, key) ? data[key] : DEFAULTS[key];
      if (bools.has(key)) {
        if (typeof v !== 'boolean') errors.push(key + ': esperado booleano');
        cfg[key] = typeof v === 'boolean' ? v : DEFAULTS[key];
      } else if (Object.prototype.hasOwnProperty.call(nums, key)) {
        const [min, max] = nums[key];
        const n = typeof v === 'number' ? v : (typeof v === 'string' && v.trim() !== '' ? Number(v) : NaN);
        if (!Number.isFinite(n) || n < min || n > max) errors.push(key + ': valor fora de [' + min + ', ' + max + ']');
        cfg[key] = Number.isFinite(n) && n >= min && n <= max ? n : DEFAULTS[key];
      } else {
        if (typeof v !== 'string' || v.length > (strLimits[key] || 500)) errors.push(key + ': texto inválido');
        cfg[key] = typeof v === 'string' && v.length <= (strLimits[key] || 500) ? v : DEFAULTS[key];
        if (choices[key] && !choices[key].includes(cfg[key])) {
          errors.push(key + ': opção inválida'); cfg[key] = DEFAULTS[key];
        }
      }
    }
    if (cfg.jitterMinSec > cfg.jitterMaxSec) errors.push('jitter: mínimo maior que máximo');
    if (cfg.minutes * 60 + cfg.seconds + (cfg.jitterEnabled ? cfg.jitterMinSec : 0) < 30)
      errors.push('intervalo mínimo de 30 segundos');
    if (cfg.durationEnabled && durationMs(cfg) <= 0) errors.push('duração deve ser positiva');
    if (cfg.confirmationMode === 'selector' && !cfg.confirmationSelector.trim())
      errors.push('confirmationSelector obrigatório no modo seletor');
    if (!cfg.selector.trim() && !cfg.fallbacks.trim()) errors.push('ao menos um localizador obrigatório');
    if (cfg.enterMode !== 'none' && !cfg.text.trim() && !cfg.dryRun) errors.push('texto do envio vazio');
    return { config: cfg, errors: strict ? errors : [] };
  }
  function durationMs(c) {
    return ((Number(c.durationHours) || 0) * 3600 + (Number(c.durationMinutes) || 0) * 60 + (Number(c.durationSeconds) || 0)) * 1000;
  }
  function nextDelayMs(c, rng = Math.random) {
    const min = c.jitterEnabled ? c.jitterMinSec : 0;
    const max = c.jitterEnabled ? c.jitterMaxSec : 0;
    const jitter = min + Math.floor(rng() * (max - min + 1));
    return { milliseconds: Math.max(30000, (c.minutes * 60 + c.seconds + jitter) * 1000), jitterSec: jitter };
  }
  root.APC_SHARED = Object.freeze({ DEFAULTS, CONFIG_KEYS, normalize, durationMs, nextDelayMs });
})(globalThis);
