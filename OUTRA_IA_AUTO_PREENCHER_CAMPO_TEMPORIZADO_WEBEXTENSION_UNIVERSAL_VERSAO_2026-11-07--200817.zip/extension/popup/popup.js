'use strict';
const api=typeof browser!=='undefined'&&browser.runtime?browser:chrome;
const state=document.getElementById('state');
const message=document.getElementById('message');
let last;
function when(t) {return t?new Date(t).toLocaleString('pt-BR'):'—';}
function remain(ms) {const s=Math.max(0,Math.ceil(ms/1000));return `${Math.floor(s/3600)}h ${String(Math.floor((s%3600)/60)).padStart(2,'0')}m ${String(s%60).padStart(2,'0')}s`;}
async function refresh() {
  const data=await api.storage.local.get(['apcSession','enabled','lastResult','nextRun','log',
    'maxCyclesEnabled','maxCycles','durationEnabled','durationMode','durationHours','durationMinutes','durationSeconds']);
  last=data;const s=data.apcSession;
  const elapsed=s?.startedAt ? (data.durationMode==='active' ?
    (s.activeElapsedMs||0)+(s.activeSince?Date.now()-s.activeSince:0):Date.now()-s.startedAt):0;
  const duration=((data.durationHours||0)*3600+(data.durationMinutes||0)*60+(data.durationSeconds||0))*1000;
  state.textContent=[`Automação: ${data.enabled?'ATIVADA':'PAUSADA'}`,
    `Estado: ${s?.status||'não vinculada'}`,
    `Aba: ${s?.tabId??'—'} | Origem: ${s?.origin||'—'}`,
    `Ciclos: ${s?.completedCycles??0}${data.maxCyclesEnabled?' / '+data.maxCycles:''}`,
    `Tentativas: ${s?.attemptedCycles??0} | Recargas: ${s?.reloads??0}`,
    `Início: ${when(s?.startedAt)}`,
    data.durationEnabled?`Tempo restante (${data.durationMode==='active'?'ativo':'corrido'}): ${remain(duration-elapsed)}`:null,
    `Próximo ciclo: ${s?.nextDueAt?when(s.nextDueAt)+' ('+remain(s.nextDueAt-Date.now())+')':'—'}`,
    `Último campo pronto: ${when(s?.lastReadyAt)}`,
    `Último resultado: ${data.lastResult||'—'}`,
    s?.endReason?`Ocorrência: ${s.endReason}`:null].filter(Boolean).join('\n');
  const log=Array.isArray(data.log)?data.log.slice(-5):[];
  document.getElementById('logs').textContent=log.map(e=>`${new Date(e.t).toLocaleTimeString('pt-BR')} [${e.l}] ${e.m}`).join('\n')||'—';
  document.getElementById('bind').disabled=!!data.enabled;
  document.getElementById('enable').disabled=!!data.enabled || !s?.tabId || ['completed','uncertain'].includes(s?.status);
  document.getElementById('disable').disabled=!data.enabled;
  document.getElementById('run').disabled=!data.enabled || s?.status!=='running';
  document.getElementById('reset').disabled=!!data.enabled || !s?.tabId;
}
async function ask(type,props={}) {
  message.textContent='Executando…';
  try {
    const res=await api.runtime.sendMessage({type,...props});
    message.textContent=res?.ok?'Concluído: '+(res.detail||res.reason||'comando aceito'):'Atenção: '+(res?.reason||'comando não executado');
  } catch (e) {message.textContent=String(e?.message||e);}
  await refresh();
}
document.getElementById('bind').addEventListener('click',()=>ask('APC_BIND_TARGET'));
document.getElementById('enable').addEventListener('click',()=>ask('APC_SET_ENABLED',{enabled:true}));
document.getElementById('disable').addEventListener('click',()=>ask('APC_SET_ENABLED',{enabled:false}));
document.getElementById('run').addEventListener('click',()=>ask('APC_RUN_NOW'));
document.getElementById('check').addEventListener('click',()=>ask('APC_CHECK_NOW'));
document.getElementById('reset').addEventListener('click',()=>{
  if (confirm('Zerar contadores e ignorar o estado anterior? Um envio incerto pode já ter sido efetuado.'))
    ask('APC_RESET_SESSION');
});
document.getElementById('options').addEventListener('click',()=>api.runtime.openOptionsPage());
refresh().catch(e=>{message.textContent=String(e);});
setInterval(()=>refresh().catch(()=>{}),3000);
