/* APC v4 - single source for Firefox MV3 event page and Chromium MV3 service worker.
   All critical state transitions are serialized and persisted in storage.local. */
'use strict';
if (typeof importScripts === 'function' && !globalThis.APC_SHARED) importScripts('config.js');
const api = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome;
const SH = globalThis.APC_SHARED;
const CYCLE_ALARM = 'apc-v4-cycle';
const WATCH_ALARM = 'apc-v4-watchdog';
const LIMIT_ALARM = 'apc-v4-duration';
const LOG_MAX = 500;
let chain = Promise.resolve();
const queue = (fn) => {
  const task = chain.then(fn, fn);
  chain = task.catch(() => {});
  return task;
};
const now = () => Date.now();

async function config() {
  const stored = await api.storage.local.get(SH.CONFIG_KEYS);
  const merged = {...SH.DEFAULTS};
  for (const k of SH.CONFIG_KEYS) if (stored[k] !== undefined) merged[k] = stored[k];
  return SH.normalize(merged,{strict:false}).config;
}
async function session() { return (await api.storage.local.get('apcSession')).apcSession || null; }
async function save(s) { await api.storage.local.set({apcSession:s,nextRun:s?.nextDueAt||null}); }
async function log(level, message) {
  try {
    const {log:arr} = await api.storage.local.get('log');
    const list=Array.isArray(arr)?arr:[];
    list.push({t:now(),s:'supervisor',l:level,m:String(message).slice(0,480)});
    if (list.length>LOG_MAX) list.splice(0,list.length-LOG_MAX);
    await api.storage.local.set({log:list});
  } catch (_) { /* diagnostics must not stop execution */ }
}
async function notify(cfg,title,message) {
  if (!cfg.notifyOnFail) return;
  try { await api.notifications.create('',{type:'basic',iconUrl:api.runtime.getURL('icons/icon48.png'),title,message}); }
  catch (_) {}
}
async function badge(cfg,s) {
  let text='';
  if (cfg.enabled && s && ['running','recovering'].includes(s.status)) text=s.status==='recovering'?'FIX':'ON';
  else if (s?.status==='uncertain') text='?';
  else if (s?.status==='completed') text='FIN';
  try {
    await api.action.setBadgeBackgroundColor({color:s?.status==='uncertain'?'#b42318':s?.status==='recovering'?'#b45309':'#247c43'});
    await api.action.setBadgeText({text});
  } catch (_) {}
}
function activeUsed(s,t=now()) {
  return (s.activeElapsedMs||0) + (s.activeSince ? Math.max(0,t-s.activeSince):0);
}
function setActive(s,active,t=now()) {
  if (s.activeSince) s.activeElapsedMs=activeUsed(s,t);
  s.activeSince=active?t:null;
}
function leftTime(s,c,t=now()) {
  if (!c.durationEnabled || !s.startedAt) return Infinity;
  const duration=SH.durationMs(c);
  return c.durationMode==='active' ? duration-activeUsed(s,t) : duration-(t-s.startedAt);
}
function limitReached(s,c,t=now()) {
  if (c.maxCyclesEnabled && s.completedCycles>=c.maxCycles) return 'limite de ciclos atingido';
  if (c.durationEnabled && leftTime(s,c,t)<=0) return 'limite de duração atingido';
  return null;
}
async function timers(c,s) {
  for (const name of [CYCLE_ALARM,LIMIT_ALARM]) await api.alarms.clear(name);
  const active=!!(c.enabled && s && ['running','recovering'].includes(s.status));
  const existing=await api.alarms.get(WATCH_ALARM);
  if (active && c.watchdogEnabled) {
    if (!existing || Math.abs((existing.periodInMinutes||0)-c.watchdogMinutes)>0.0001)
      api.alarms.create(WATCH_ALARM,{periodInMinutes:c.watchdogMinutes});
  } else if (existing) await api.alarms.clear(WATCH_ALARM);
  if (active && s.status==='running' && Number.isFinite(s.nextDueAt))
    api.alarms.create(CYCLE_ALARM,{when:Math.max(now()+30000,s.nextDueAt)});
  if (active && c.durationEnabled && Number.isFinite(leftTime(s,c)))
    api.alarms.create(LIMIT_ALARM,{when:Math.max(now()+30000,now()+leftTime(s,c))});
  await badge(c,s);
}
async function status(message,successful) {
  await api.storage.local.set({lastRun:now(),lastResult:(successful?'RESULTADO — ':'FALHA — ')+message});
}
function freshBound(tab) {
  let u;
  try {u=new URL(tab.url);} catch (_) {throw new Error('URL da aba indisponível');}
  if (!['http:','https:'].includes(u.protocol)) throw new Error('Selecione uma aba HTTP ou HTTPS');
  return {status:'idle',tabId:tab.id,origin:u.origin,targetUrl:u.href,startedAt:null,
    completedCycles:0,attemptedCycles:0,nextDueAt:null,pendingCycle:null,
    activeElapsedMs:0,activeSince:null,failures:0,reloads:0,retryAt:null,
    lastReadyAt:null,lastHealthAt:null,lastNavigationAt:null,endedAt:null,endReason:null};
}
async function pause(s,c,reason,uncertain=false) {
  setActive(s,false);
  s.status=uncertain?'uncertain':'paused'; s.endReason=reason;
  s.nextDueAt=null; s.endedAt=now();
  await api.storage.local.set({enabled:false}); c.enabled=false;
  await save(s); await timers(c,s);
  await log(uncertain?'ERROR':'WARN',reason);
  await status(reason,false);
  await notify(c,'Auto Preencher Campo',reason);
  return {ok:false,reason};
}
async function finishIfDue(s,c) {
  const reason=limitReached(s,c);
  if (!reason) return false;
  setActive(s,false); s.status='completed'; s.endReason=reason; s.nextDueAt=null; s.endedAt=now();
  await api.storage.local.set({enabled:false}); c.enabled=false;
  await save(s); await timers(c,s);
  await log('INFO',reason+'; concluídos: '+s.completedCycles);
  await status(reason,true);
  return true;
}
async function scheduleNext(s,c) {
  const delay=SH.nextDelayMs(c);
  s.nextDueAt=now()+delay.milliseconds;
  await save(s);
  await timers(c,s);
  await log('INFO',`próximo ciclo em ${Math.round(delay.milliseconds/1000)}s; jitter ${delay.jitterSec}s`);
}
async function sendWithTimeout(tabId,data,ms) {
  let timer;
  try {
    return await Promise.race([
      api.tabs.sendMessage(tabId,data),
      new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('tempo máximo de resposta excedido')),ms);})
    ]);
  } finally {if (timer) clearTimeout(timer);}
}
async function tabHealth(s,c) {
  let tab;
  try {tab=await api.tabs.get(s.tabId);} catch (_) {return {ready:false,lost:true,reason:'aba vinculada foi fechada'};}
  const url=tab.url||'';
  let origin;
  try {origin=new URL(url).origin;} catch (_) {origin='';}
  const internalCrash=/^(chrome-error:\/\/|about:tabcrashed|about:neterror)/i.test(url);
  if (origin!==s.origin && !internalCrash)
    return {ready:false,foreign:true,reason:'aba navegou para outra origem; nenhuma recarga automática'};
  if (c.urlContains && !url.toLowerCase().includes(c.urlContains.trim().toLowerCase()) && !internalCrash)
    return {ready:false,foreign:true,reason:'URL não satisfaz o filtro configurado'};
  if (tab.status==='loading' && s.lastNavigationAt && now()-s.lastNavigationAt<45000)
    return {ready:false,loading:true,reason:'navegação em andamento'};
  if (tab.discarded) return {ready:false,reason:'aba descartada pelo navegador'};
  if (internalCrash) return {ready:false,reason:'página de erro do navegador'};
  try {
    const response=await sendWithTimeout(tab.id,{type:'APC_PING',settings:c,expectedOrigin:s.origin},c.healthTimeoutMs);
    return response?.ready ? {ready:true,reason:'campo operacional'} :
      {ready:false,terminal:!!response?.terminal,reason:response?.reason||'campo indisponível'};
  } catch (e) {return {ready:false,reason:'script de conteúdo inacessível: '+String(e?.message||e)};}
}
async function reloadSafe(s,c) {
  if (s.reloads>=c.maxReloads) return pause(s,c,'limite de recargas atingido; intervenção necessária');
  const t=await api.tabs.get(s.tabId).catch(()=>null);
  if (!t) return pause(s,c,'aba vinculada desapareceu');
  let origin=''; try {origin=new URL(t.url).origin;} catch (_) {}
  const recoverable=/^(chrome-error:\/\/|about:tabcrashed|about:neterror)/i.test(t.url||'');
  if (origin!==s.origin && !recoverable) return pause(s,c,'origem da aba alterada; recarga bloqueada');
  if (t.url?.startsWith('about:certerror')) return pause(s,c,'erro de certificado exige intervenção manual');
  s.reloads+=1; s.failures=0; s.status='recovering'; setActive(s,false);
  s.retryAt=now()+c.recoveryBackoffSec*1000*Math.pow(2,s.reloads-1);
  await save(s); await timers(c,s);
  await log('WARN',`recarga ${s.reloads}/${c.maxReloads}; nova avaliação após ${Math.round((s.retryAt-now())/1000)}s`);
  try {
    if (recoverable) await api.tabs.update(s.tabId,{url:s.targetUrl});
    else await api.tabs.reload(s.tabId);
  } catch (e) {await log('ERROR','falha no pedido de recarga: '+String(e?.message||e));}
  return {ok:false,recovering:true,reason:'recarga solicitada'};
}
async function failedHealth(s,c,reason) {
  s.lastHealthAt=now(); s.failures+=1;
  await save(s);
  await log('WARN',`saúde ${s.failures}/${c.recoveryFailures}: ${reason}`);
  if (!c.watchdogEnabled) {
    // Without a watchdog, periodic cycles still retry before a new dispatch.
    s.nextDueAt=now()+SH.nextDelayMs(c).milliseconds;
    await save(s);await timers(c,s);
    return {ok:false,reason};
  }
  if (c.maxReloads===0) return {ok:false,reason};
  if (s.status==='recovering' && now() < (s.retryAt||0)) return {ok:false,recovering:true,reason};
  if (s.failures>=c.recoveryFailures || s.status==='recovering') return reloadSafe(s,c);
  return {ok:false,reason};
}
async function runCycle(s,c,source) {
  if (s.status!=='running' || s.pendingCycle) return {ok:false,reason:'estado não executável'};
  if (await finishIfDue(s,c)) return {ok:false,reason:'limite atingido'};
  const h=await tabHealth(s,c);
  if (h.lost || h.foreign) return pause(s,c,h.reason);
  if (!h.ready) {
    if (h.loading) return {ok:false,reason:h.reason};
    if (h.terminal) return pause(s,c,h.reason);
    return failedHealth(s,c,h.reason);
  }
  s.failures=0; s.lastHealthAt=now(); s.lastReadyAt=now();
  const cycleId=`${s.startedAt}-${s.attemptedCycles+1}-${now()}`;
  s.attemptedCycles+=1;
  // Persist BEFORE dispatch: an unacknowledged command must never be resent automatically.
  s.pendingCycle={id:cycleId,startedAt:now(),source,possibleSend:true};
  await save(s);
  await log('INFO',`ciclo ${s.attemptedCycles} iniciado (${source}); contador confirmado ${s.completedCycles}`);
  let r;
  try {
    r=await sendWithTimeout(s.tabId,{type:'APC_FILL',cycleId,
      settings:c,expectedOrigin:s.origin},Math.max(12000,c.healthTimeoutMs,c.confirmationTimeoutMs+4000));
  } catch (e) {
    return pause(s,c,'ENVIO INCERTO: conexão perdida durante o ciclo '+cycleId+' ('+String(e?.message||e)+')',true);
  }
  if (!r || typeof r.ok!=='boolean') return pause(s,c,'ENVIO INCERTO: resposta inválida',true);
  if (!r.ok) {
    if (r.maybeDispatched) return pause(s,c,'ENVIO INCERTO: '+r.reason,true);
    if (r.terminal) return pause(s,c,r.reason||'bloqueio do site');
    s.pendingCycle=null;
    await status(r.reason||'falha anterior ao envio',false);
    await log('WARN','ciclo sem disparo: '+String(r.reason));
    return failedHealth(s,c,r.reason||'falha anterior ao envio');
  }
  s.pendingCycle=null;
  s.completedCycles+=1;
  s.lastHealthAt=now(); s.lastReadyAt=now(); s.failures=0;
  const detail=(r.dryRun?'SIMULAÇÃO — ':r.confirmed?'CONFIRMADO NA INTERFACE — ':'DISPARADO SEM CONFIRMAÇÃO REMOTA — ')+r.description;
  await status(detail,true);
  await log('INFO',`ciclo ${s.completedCycles}: ${detail}`);
  await save(s);
  if (await finishIfDue(s,c)) return {ok:true,completed:true,detail};
  await scheduleNext(s,c);
  return {ok:true,detail,completedCycles:s.completedCycles};
}
async function monitor(source,{runDue=true}={}) {
  const c=await config(),s=await session();
  if (!c.enabled || !s || !['running','recovering'].includes(s.status)) return {ok:false,reason:'sessão não ativa'};
  if (s.pendingCycle) return pause(s,c,'ENVIO INCERTO: operação pendente recuperada após interrupção',true);
  if (await finishIfDue(s,c)) return {ok:false,reason:'prazo ou ciclos esgotados'};
  const h=await tabHealth(s,c);
  if (h.lost || h.foreign) return pause(s,c,h.reason);
  if (h.loading) return {ok:false,reason:h.reason};
  if (!h.ready) {if (h.terminal) return pause(s,c,h.reason);return failedHealth(s,c,h.reason);}
  const wasRecovering=s.status==='recovering';
  s.failures=0; s.reloads=0; s.retryAt=null; s.lastHealthAt=now(); s.lastReadyAt=now();
  if (wasRecovering) {s.status='running';setActive(s,true);await log('INFO','aba recuperada; campo operacional');}
  await save(s); await timers(c,s);
  if (runDue && s.nextDueAt!==null && now()>=s.nextDueAt) return runCycle(s,c,source);
  return {ok:true,healthy:true,reason:'aba operacional'};
}
async function bootstrap(reason) {
  const stored=await api.storage.local.get(['apcV4Initialized','enabled','apcSession']);
  if (!stored.apcV4Initialized) {
    const existing=await api.storage.local.get(SH.CONFIG_KEYS);
    const patch={apcV4Initialized:true,enabled:false,apcSession:null,
      lastResult:'Atualização v4: automação pausada; vincule novamente a aba-alvo.'};
    for (const k of SH.CONFIG_KEYS) if (existing[k]===undefined) patch[k]=SH.DEFAULTS[k];
    await api.storage.local.set(patch);
    await log('INFO','migração segura v3→v4: automação desativada até vinculação explícita');
  }
  const c=await config(),s=await session();
  // On service-worker/browser restart, the previous in-memory active interval
  // cannot be assumed to have elapsed while the browser was closed.
  // Approximate active time from the last observed heartbeat, cap at two
  // watchdog periods; wall-clock mode remains exact across shutdown.
  if (c.enabled && s?.status==='running' && s.activeSince) {
    const heartbeat=s.lastHealthAt||s.activeSince;
    const maxGap=Math.max(60000,c.watchdogMinutes*120000);
    const accruedUntil=Math.min(now(),heartbeat+maxGap);
    s.activeElapsedMs=(s.activeElapsedMs||0)+Math.max(0,accruedUntil-s.activeSince);
    s.activeSince=now();
    await save(s);
  }
  if (c.enabled && s?.pendingCycle) return pause(s,c,'ENVIO INCERTO: sessão reaberta com envio pendente',true);
  await timers(c,s);
  if (c.enabled && s && ['running','recovering'].includes(s.status)) {
    if (await finishIfDue(s,c)) return;
    // Avoid an unsolicited duplicate: only run when the persisted due time has arrived.
    if (s.nextDueAt!==null && s.nextDueAt<=now()) return monitor('retomada '+reason);
  }
}
async function setEnabled(enable) {
  const c=await config(); let s=await session();
  if (!enable) {
    await api.storage.local.set({enabled:false}); c.enabled=false;
    if (s && ['running','recovering'].includes(s.status)) {
      setActive(s,false); s.status='paused';s.endReason='pausa manual'; await save(s);
    }
    await timers(c,s);await log('INFO','automação pausada');return {ok:true,session:s};
  }
  if (!s?.tabId || !s.origin) throw new Error('Vincule uma aba-alvo antes de ativar.');
  if (s.status==='uncertain') throw new Error('Envio incerto: resolva ou reinicie expressamente a sessão antes de ativar.');
  if (s.status==='completed') throw new Error('Limite já alcançado: reinicie a sessão para continuar.');
  const t=now();
  if (!s.startedAt) {
    s.startedAt=t; s.completedCycles=0;s.attemptedCycles=0;s.activeElapsedMs=0;
    s.nextDueAt=c.runOnEnable?t:t+SH.nextDelayMs(c).milliseconds;
  } else if (s.nextDueAt===null) s.nextDueAt=t+SH.nextDelayMs(c).milliseconds;
  s.status='running';setActive(s,true,t);s.endReason=null;s.endedAt=null;
  await api.storage.local.set({enabled:true}); c.enabled=true; await save(s);
  if (await finishIfDue(s,c)) return {ok:false,reason:'prazo ou ciclos atingidos'};
  await timers(c,s); await log('INFO','sessão habilitada para aba #'+s.tabId);
  if (s.nextDueAt<=now()) return monitor('ativação');
  return {ok:true,session:s};
}
async function saveSettings(request) {
  const previous=await config();
  const incoming={...previous,...request};
  const checked=SH.normalize(incoming);
  if (checked.errors.length) throw new Error(checked.errors.join('; '));
  const c=checked.config;
  const wantEnable=c.enabled;
  if (wantEnable && !previous.enabled && !(await session())?.tabId)
    throw new Error('Antes de ativar, use "Vincular aba atual" no popup.');
  // Enabling/pausing is managed by setEnabled; avoid partial side effects.
  await api.storage.local.set({...c,enabled:previous.enabled});
  if (wantEnable!==previous.enabled) return setEnabled(wantEnable);
  const s=await session();
  if (s && c.enabled && await finishIfDue(s,c)) return {ok:true,reason:'limite atingido pela nova configuração'};
  await timers(c,s);
  await log('INFO','configurações validadas e salvas');
  return {ok:true};
}
async function bindCurrent() {
  const c=await config();
  if (c.enabled) throw new Error('Pause a automação antes de vincular outra aba.');
  const ts=await api.tabs.query({active:true,currentWindow:true});
  if (!ts.length) throw new Error('Nenhuma aba ativa localizada.');
  const s=freshBound(ts[0]);
  if (c.urlContains && !s.targetUrl.toLowerCase().includes(c.urlContains.trim().toLowerCase()))
    throw new Error('A aba não satisfaz o filtro "URL deve conter".');
  await save(s); await timers(c,s); await log('INFO','aba vinculada #'+s.tabId+'; origem '+s.origin);
  return {ok:true,tabId:s.tabId,origin:s.origin};
}
async function resetSession() {
  const c=await config();if (c.enabled) throw new Error('Pause antes de reiniciar a sessão.');
  const old=await session();
  if (!old?.tabId) throw new Error('Não há aba vinculada.');
  const tab=await api.tabs.get(old.tabId);
  const fresh=freshBound(tab);
  if (fresh.origin!==old.origin) throw new Error('Origem modificada; vincule a aba novamente.');
  await save(fresh);await timers(c,fresh);await log('INFO','sessão explicitamente reiniciada');
  return {ok:true};
}
async function listProfiles() {
  const {apcProfiles}=await api.storage.local.get('apcProfiles');
  return Object.keys(apcProfiles||{}).sort();
}
async function saveProfile() {
  const s=await session();
  if (!s?.origin) throw new Error('Vincule a aba antes de salvar um perfil.');
  const c=await config();
  const {apcProfiles:existing}=await api.storage.local.get('apcProfiles');
  const profiles=existing&&typeof existing==='object'&&!Array.isArray(existing)?existing:{};
  if (!profiles[s.origin] && Object.keys(profiles).length>=30) throw new Error('Limite de 30 perfis atingido.');
  const {enabled,...settings}=c;
  profiles[s.origin]={settings,savedAt:now()};
  await api.storage.local.set({apcProfiles:profiles});
  await log('INFO','perfil salvo para '+s.origin);
  return {ok:true,origin:s.origin};
}
async function loadProfile(origin) {
  const c=await config(),s=await session();
  if (c.enabled) throw new Error('Pause antes de carregar um perfil.');
  if (!s || s.origin!==origin) throw new Error('Vincule primeiro uma aba da origem do perfil selecionado.');
  const {apcProfiles}=await api.storage.local.get('apcProfiles');
  if (!apcProfiles?.[origin]) throw new Error('Perfil não encontrado.');
  const checked=SH.normalize({...SH.DEFAULTS,...apcProfiles[origin].settings,enabled:false});
  if (checked.errors.length) throw new Error(checked.errors.join('; '));
  await api.storage.local.set(checked.config);
  await timers(checked.config,s);
  await log('INFO','perfil carregado para '+origin);
  return {ok:true};
}
async function deleteProfile(origin) {
  const c=await config();if (c.enabled) throw new Error('Pause antes de excluir um perfil.');
  const {apcProfiles:existing}=await api.storage.local.get('apcProfiles');
  const profiles=existing&&typeof existing==='object'?existing:{};
  if (!Object.prototype.hasOwnProperty.call(profiles,origin)) throw new Error('Perfil não encontrado.');
  delete profiles[origin];
  await api.storage.local.set({apcProfiles:profiles});
  await log('INFO','perfil excluído para '+origin);
  return {ok:true};
}

async function handleMessage(m,sender) {
  if (!m || typeof m.type!=='string') return {ok:false,reason:'mensagem inválida'};
  if (m.type==='APC_PAGE_HEALTH') {
    // Notification from content script is merely a hint, not proof of readiness.
    const s=await session(),c=await config();
    if (!c.enabled || !s || sender.tab?.id!==s.tabId) return {ok:false};
    if (m.ready && s.status==='recovering') return monitor('observação DOM');
    return {ok:true};
  }
  if (sender.tab) throw new Error('Operação de controle não autorizada a partir de página.');
  switch (m.type) {
    case 'APC_GET_STATUS': return {ok:true,settings:await config(),session:await session()};
    case 'APC_LIST_PROFILES': return {ok:true,origins:await listProfiles()};
    case 'APC_SAVE_PROFILE': return saveProfile();
    case 'APC_LOAD_PROFILE': return loadProfile(m.origin);
    case 'APC_DELETE_PROFILE': return deleteProfile(m.origin);
    case 'APC_SAVE_SETTINGS': return saveSettings(m.settings);
    case 'APC_BIND_TARGET': return bindCurrent();
    case 'APC_SET_ENABLED': return setEnabled(!!m.enabled);
    case 'APC_RESET_SESSION': return resetSession();
    case 'APC_CHECK_NOW': return monitor('verificação manual',{runDue:false});
    case 'APC_RUN_NOW': {
      const c=await config(),s=await session();
      if (!c.enabled || !s || s.status!=='running') throw new Error('Ative a sessão vinculada antes do envio manual.');
      return runCycle(s,c,'manual');
    }
    default: return {ok:false,reason:'mensagem desconhecida'};
  }
}
api.runtime.onInstalled.addListener(()=>{void queue(()=>bootstrap('instalação')).catch(e=>log('ERROR',String(e)));});
api.runtime.onStartup.addListener(()=>{void queue(()=>bootstrap('inicialização')).catch(e=>log('ERROR',String(e)));});
api.alarms.onAlarm.addListener(a=>{if (![CYCLE_ALARM,WATCH_ALARM,LIMIT_ALARM].includes(a.name)) return;
  void queue(()=>monitor('alarme '+a.name)).catch(e=>log('ERROR',String(e?.message||e)));
});
api.tabs.onUpdated.addListener((id,changed)=>{
  if (changed.status!=='complete' && changed.status!=='loading') return;
  void queue(async()=>{
    const s=await session(); if (!s || s.tabId!==id) return;
    if (changed.status==='loading') {s.lastNavigationAt=now();await save(s);return;}
    await monitor('página carregada',{runDue:true});
  }).catch(()=>{});
});
api.tabs.onRemoved.addListener(tabId=>{
  void queue(async()=>{
    const c=await config(),s=await session();if (!c.enabled || !s || s.tabId!==tabId) return;
    await pause(s,c,'aba vinculada foi fechada');
  }).catch(()=>{});
});
api.runtime.onMessage.addListener((m,sender,sendResponse)=>{
  if (!m?.type?.startsWith('APC_')) return false;
  queue(()=>handleMessage(m,sender)).then(sendResponse,e=>sendResponse({ok:false,reason:String(e?.message||e)}));
  return true; // compatible asynchronous response in Firefox and Chromium
});
// Reconcile alarms after service-worker restart. Listeners are registered synchronously above.
void queue(()=>bootstrap('carregamento do supervisor')).catch(e=>log('ERROR',String(e?.message||e)));
