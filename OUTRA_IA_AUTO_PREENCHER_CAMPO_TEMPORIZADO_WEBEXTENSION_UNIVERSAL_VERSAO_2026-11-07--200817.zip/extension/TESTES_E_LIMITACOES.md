# Relatório de execução e limitações — v4.0.0

## Testes realizados no ambiente de construção

| Validação | Resultado |
|---|---|
| `node --check` para os cinco JavaScript | PASSOU |
| Parser JSON do manifesto e existência dos recursos referenciados | PASSOU |
| Chaves de configuração correspondem aos controles em `options.html` | PASSOU |
| Testes determinísticos da máquina de estados do background (`tests/test-supervisor.cjs`) | PASSOU |
| Limite de dois ciclos, contador persistente e encerramento | PASSOU |
| Falhas consecutivas, comando de recarga e retorno ao estado operacional | PASSOU (APIs simuladas) |
| Envio de resultado incerto, suspensão e prevenção de repetição automática | PASSOU (APIs simuladas) |
| Duração absoluta expirada e reinicialização simulada de worker pendente | PASSOU |
| Perfis por origem: salvar, carregar e apagar sem ativar | PASSOU |
| Execução do `content.js` no DOM de um Chromium 144 real | PASSOU |
| Seleção do campo, clique, evidência de confirmação por seletor | PASSOU |
| Impedir disparo duplicado com mesmo `cycleId`, simulação sem envio | PASSOU |
| Eventos sintéticos de Enter sem confirmação são considerados incertos | PASSOU |
| Campo removido e bloqueio CSS visível deixam a página inapta | PASSOU |
| Empacotamento pelo comando Chromium `--pack-extension` | PASSOU (não equivale à instalação e execução) |

## Sem comprovação de execução integral

- **Firefox:** indisponível para ensaio real neste ambiente; a compatibilidade do manifesto é fundamentada na MDN e na inspeção do código.
- **Chrome/Chromium com extensão carregada e service worker:** o ensaio headless automatizado não exibiu o worker, e a alternativa com interface virtual não foi conclusiva. Não houve validação ponta a ponta do carregamento da extensão no ambiente real do usuário.
- **Sites reais**, especialmente ChatGPT e outros aplicativos SPA: não foram utilizadas contas do usuário; o teste DOM ocorreu exclusivamente em página de ensaio local, sem envio externo.
- **Falha real de processo de renderização (crash):** a recuperação é implementada por APIs documentadas, mas o evento completo não foi reproduzido com um crash de aba real neste ambiente.
- **Garantia remota de entrega:** inexiste mecanismo genericamente aplicável a qualquer página. A classificação do resultado é explícita conforme o método selecionado.

## Procedimento de aceitação recomendado no computador do usuário

1. Instalar a árvore `extension/` temporariamente nos dois navegadores, inspecionar erros de manifesto, worker/event page e scripts.
2. Escolher uma aba de teste inofensiva, vincular e executar `dryRun` (verificar ausência de envio).
3. Desabilitar `dryRun`, usar um texto de teste e um seletor de confirmação próprio do aplicativo; conferir contadores e ausência de duplicidade.
4. Testar encerramento por 2 ciclos e duração de 1 minuto, separadamente e em conjunto.
5. Simular campo ausente/desabilitado e verificar recuperação controlada e logs.
6. Simular indisponibilidade transitória da página e conferir recarga, vínculo e retomada.
7. Verificar caso `uncertain`: deve pausar, não disparar nova tentativa e exigir decisão manual.
8. Reabrir navegador com sessão ativa, conferir estado e timers persistidos.
9. Testar Firefox, Chrome e, opcionalmente, Edge, Brave e Opera, separadamente.

Ações automáticas de recuperação estão sujeitas a limites dos navegadores, rede, políticas de conteúdo, permissões e estados de autenticação. Esta versão **não oferece garantia de disponibilidade ou entrega exatamente uma vez**.
