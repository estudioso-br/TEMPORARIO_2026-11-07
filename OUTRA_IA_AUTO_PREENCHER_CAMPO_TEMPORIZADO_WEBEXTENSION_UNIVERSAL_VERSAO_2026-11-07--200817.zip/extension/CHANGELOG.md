# Histórico de alterações

## v4.0.0 — 2026-11-07

- Eliminados diretórios `firefox` e `chrome` duplicados. `manifest.json` MV3 único, com fallback `background.scripts`/`background.service_worker`.
- Carga compartilhada de `config.js`, validação rigorosa e importação de configurações.
- Aba explicitamente vinculada e bloqueio por origem; prevenção de mudança acidental de alvo.
- Supervisor por alarmes, verificação do campo e botão, recuperação por recarga limitada, retorno ao ciclo pendente.
- Estado persistente, fila de operações e bloqueio conservador para envios de resultado incerto.
- Distinção entre disparo de envio e sinais configuráveis de confirmação na página.
- Jitter e localizadores primários/de reserva preservados; `auto` prioriza botão de envio.
- Limites independentes por ciclos e duração (corrida / ativa aproximada), parada no primeiro atingido.
- Perfis por origem, modo de simulação, controles de pausa, retomada, reinício de sessão e supervisão manual.
- Logs locais exportáveis, seletores de bloqueio e testes automatizados de supervisor e DOM.

## Alteração incompatível de comportamento

- A atualização pausa a execução existente e obriga nova vinculação da aba.
- `scope` da v3 é legado; `runOnLoad` só executa um ciclo que já esteja vencido.
- No modo automático, o clique é priorizado sobre Enter sintético. Sem confirmação, o histórico não declara entrega remota.
