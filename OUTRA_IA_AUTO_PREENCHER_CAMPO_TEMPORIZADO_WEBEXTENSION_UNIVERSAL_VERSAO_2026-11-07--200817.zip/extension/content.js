/* Executes only in the tab selected and authorized by background.js. */
(() => {
  'use strict';
  if (globalThis.__APC_V4_CONTENT__) return;
  globalThis.__APC_V4_CONTENT__ = true;
  const api = typeof browser !== 'undefined' && browser.runtime ? browser : chrome;
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const aliases = { css:'css', 'seletor-css':'css', csspath:'css', 'css-path':'css', 'caminho-css':'css',
    xpath:'xpath', 'xpath-curto':'xpath', 'xpath-longo':'xpath', 'xpath-short':'xpath', 'xpath-long':'xpath',
    outerhtml:'outerHTML', 'html-externo':'outerHTML' };
  let inFlight = null;
  const history = new Map();
  let observer = null;
  let lastReady = false;
  let debounce = 0;

  function locateOne(type, text) {
    const s = String(text || '').trim();
    if (!s) return null;
    const t = aliases[String(type).toLowerCase()] || 'css';
    try {
      if (t === 'xpath') return document.evaluate(s, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
      if (t === 'outerHTML') {
        // outerHTML is inherently fragile: limit the search to prevent page stalls.
        const wanted = s.replace(/\s+/g, ' ').trim();
        const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_ELEMENT);
        let count = 0, n = walker.currentNode;
        while (n && count++ < 3000) {
          if (n.outerHTML && n.outerHTML.length < 14000 && n.outerHTML.replace(/\s+/g, ' ').trim() === wanted) return n;
          n = walker.nextNode();
        }
        return null;
      }
      return document.querySelector(s);
    } catch (_) { return null; }
  }
  function attempts(cfg) {
    const ret = [{type:cfg.selectorType, sel:cfg.selector, label:'primário'}];
    for (const [i, line] of String(cfg.fallbacks || '').split(/\r?\n/).entries()) {
      const trimmed = line.trim(); if (!trimmed) continue;
      const idx = trimmed.indexOf('|');
      ret.push(idx < 0 ? {type:'css',sel:trimmed,label:`reserva ${i+1}`} :
        {type:trimmed.slice(0,idx).trim(),sel:trimmed.slice(idx+1).trim(),label:`reserva ${i+1}`});
    }
    return ret.filter(x => x.sel && x.sel.trim());
  }
  function editable(el) {
    if (!(el instanceof Element)) return null;
    if (el.matches('textarea, input') || el.isContentEditable) return el;
    return el.querySelector('[contenteditable="true"],textarea,input');
  }
  function visible(el) {
    if (!el || !el.isConnected || !el.getClientRects().length) return false;
    const css = getComputedStyle(el);
    return css.display !== 'none' && css.visibility !== 'hidden' && css.visibility !== 'collapse';
  }
  function usable(el) {
    if (!el || !visible(el)) return false;
    if (el.matches('[disabled],[readonly],[aria-disabled="true"], [inert]')) return false;
    if (el.closest('[inert]')) return false;
    return el.isContentEditable || (el.matches('textarea,input') && !el.readOnly && !el.disabled);
  }
  function findEditable(cfg) {
    for (const at of attempts(cfg)) {
      const e = editable(locateOne(at.type, at.sel));
      if (usable(e)) return {element:e, locator:at.label};
    }
    return null;
  }
  function sendButton(el, cfg) {
    if (cfg.sendButtonSelector && cfg.sendButtonSelector.trim()) {
      try {
        const button = document.querySelector(cfg.sendButtonSelector);
        return button && visible(button) && !button.disabled && button.getAttribute('aria-disabled') !== 'true' ? button : null;
      } catch (_) { return null; }
    }
    const root = el.closest('form') || el.closest('[class*="composer" i]') || document;
    return Array.from(root.querySelectorAll('button')).find(b => visible(b) && !b.disabled &&
      b.getAttribute('aria-disabled') !== 'true' &&
      (b.type === 'submit' || /enviar|send|submit/i.test((b.getAttribute('aria-label') || '') + ' ' +
      (b.getAttribute('title') || '') + ' ' + (b.dataset?.testid || '')))) || null;
  }
  function health(cfg) {
    if (cfg.blockedSelector && cfg.blockedSelector.trim()) {
      try {
        if (Array.from(document.querySelectorAll(cfg.blockedSelector)).some(visible))
          return {ready:false,terminal:true,reason:'bloqueio configurado detectado (login/CAPTCHA/aviso)'};
      } catch (_) {return {ready:false,terminal:true,reason:'seletor de bloqueio inválido'};}
    }
    const match = findEditable(cfg);
    if (!match) return {ready:false, reason:'campo editável visível e habilitado não encontrado'};
    if (cfg.enterMode === 'button' && !sendButton(match.element,cfg))
      return {ready:false,reason:'botão de envio indisponível'};
    return {ready:true,reason:'campo disponível',locator:match.locator,
      buttonAvailable:!!sendButton(match.element,cfg)};
  }
  function fill(el, text) {
    el.focus();
    if (el.isContentEditable) {
      const selection = window.getSelection();
      const range = document.createRange(); range.selectNodeContents(el);
      selection.removeAllRanges(); selection.addRange(range);
      let inserted = false;
      try { document.execCommand('delete',false,null); inserted = document.execCommand('insertText',false,text); }
      catch (_) { /* supported fallback below */ }
      if (!inserted || el.textContent.trim() !== text.trim()) {
        el.textContent = text;
        el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:text}));
      }
    } else {
      const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto,'value').set.call(el,text);
      el.dispatchEvent(new Event('input',{bubbles:true}));
      el.dispatchEvent(new Event('change',{bubbles:true}));
    }
    return (el.isContentEditable ? el.textContent : el.value).trim() === text.trim();
  }
  function keyEnter(el) {
    const props={key:'Enter',code:'Enter',bubbles:true,cancelable:true,composed:true,keyCode:13,which:13};
    for (const type of ['keydown','keypress','keyup']) el.dispatchEvent(new KeyboardEvent(type,props));
    // Synthetic keyboard events are untrusted and MAY be ignored by the website.
  }
  function countConfirm(selector) {
    try { return document.querySelectorAll(selector).length; } catch (_) { return -1; }
  }
  async function confirmAfter(cfg, el, before) {
    const deadline=Date.now()+cfg.confirmationTimeoutMs;
    do {
      if (cfg.confirmationMode === 'selector' && countConfirm(cfg.confirmationSelector) > before)
        return {confirmed:true,description:'novo elemento de confirmação detectado'};
      if (cfg.confirmationMode === 'field-cleared' &&
        (!el.isConnected || !(el.isContentEditable ? el.textContent : el.value).trim()))
        return {confirmed:true,description:'campo esvaziado (indício de aceitação, NÃO prova de entrega)'};
      await sleep(150);
    } while (Date.now() < deadline);
    return {confirmed:false,description:'confirmação não detectada no prazo'};
  }
  async function run(cfg, cycleId) {
    if (inFlight) return {ok:false,maybeDispatched:true,reason:'execução concorrente na página'};
    if (history.has(cycleId)) return history.get(cycleId);
    inFlight = cycleId;
    let mayHaveSent=false;
    let result;
    try {
      const initial=health(cfg);
      if (initial.terminal) return {ok:false,maybeDispatched:false,reason:initial.reason,terminal:true};
      let found;
      for (let i=0; i<=cfg.retries; i++) {
        found=findEditable(cfg); if (found) break;
        if (i<cfg.retries) await sleep(cfg.retryDelayMs);
      }
      if (!found) result={ok:false,maybeDispatched:false,reason:'campo não encontrado ou não editável'};
      else if (cfg.enterMode==='button' && !sendButton(found.element,cfg))
        result={ok:false,maybeDispatched:false,reason:'botão de envio indisponível'};
      else if (cfg.dryRun) result={ok:true,confirmed:true,dryRun:true,description:`Simulação: ${found.locator}; envio NÃO realizado`};
      else if (!fill(found.element,String(cfg.text))) result={ok:false,maybeDispatched:false,reason:'texto não persistiu no campo'};
      else if (cfg.enterMode==='none') result={ok:true,confirmed:true,description:'preenchimento sem envio, conforme configuração'};
      else {
        const before=cfg.confirmationMode==='selector'?countConfirm(cfg.confirmationSelector):0;
        if (cfg.confirmationMode==='selector' && before<0) result={ok:false,maybeDispatched:false,reason:'seletor de confirmação inválido'};
        else {
          const button = cfg.enterMode==='button'||cfg.enterMode==='auto' ? sendButton(found.element,cfg) : null;
          if (cfg.enterMode==='button' && !button) result={ok:false,maybeDispatched:false,reason:'botão não localizado'};
          else {
            mayHaveSent=true; // the browser may close between this step and the response
            if (button) button.click(); else keyEnter(found.element);
            const method = button ? 'clique no botão' : 'eventos sintéticos de Enter';
            if (cfg.confirmationMode==='dispatch') result={ok:true,confirmed:false,dispatched:true,
              description:`${method} disparado; aceitação remota NÃO comprovada`};
            else {
              const confirmed=await confirmAfter(cfg,found.element,before);
              result=confirmed.confirmed ? {ok:true,confirmed:true,dispatched:true,
                description:`${method}; ${confirmed.description}`} :
                {ok:false,maybeDispatched:true,reason:`${method}; ${confirmed.description}`};
            }
          }
        }
      }
    } catch (e) { result={ok:false,maybeDispatched:mayHaveSent,reason:'erro durante execução: '+String(e?.message||e)}; }
    finally { inFlight=null; }
    history.set(cycleId,result);
    if (history.size>30) history.delete(history.keys().next().value);
    return result;
  }
  function observeAuthorized() {
    api.storage.local.get(['enabled','apcSession']).then(s => {
      if (!s.enabled || !s.apcSession?.origin || s.apcSession.origin!==location.origin) return;
      if (observer) return;
      function changed() {
        if (debounce) clearTimeout(debounce);
        debounce=setTimeout(async()=>{
          try {
            const cfg=(await api.storage.local.get(['selector','selectorType','fallbacks','enterMode','sendButtonSelector','blockedSelector']));
            const h=health(cfg);
            if (h.ready===lastReady) return;
            lastReady=h.ready;
            await api.runtime.sendMessage({type:'APC_PAGE_HEALTH',ready:h.ready});
          } catch (_) {}
        },600);
      }
      observer=new MutationObserver(changed);
      observer.observe(document.documentElement,{childList:true,subtree:true,attributes:true,
        attributeFilter:['contenteditable','disabled','aria-disabled','style','class']});
      changed();
    }).catch(()=>{});
  }
  api.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
    if (!msg || !['APC_PING','APC_FILL'].includes(msg.type)) return false;
    (async()=>{
      if (!msg.settings || msg.expectedOrigin !== location.origin)
        return {ok:false,ready:false,maybeDispatched:false,reason:'origem inesperada'};
      if (msg.type==='APC_PING') return health(msg.settings);
      if (!msg.cycleId || typeof msg.cycleId!=='string') return {ok:false,maybeDispatched:false,reason:'ciclo inválido'};
      return run(msg.settings,msg.cycleId);
    })().then(sendResponse,e=>sendResponse({ok:false,maybeDispatched:true,reason:String(e?.message||e)}));
    return true;
  });
  observeAuthorized();
})();
