'use strict';
const api = typeof browser !== 'undefined' && browser.runtime ? browser : chrome;
const {DEFAULTS,CONFIG_KEYS,normalize} = globalThis.APC_SHARED;
const KEYS = CONFIG_KEYS;
const msgEl = document.getElementById('msg');
let messageTimer;
function flash(t,ok=true) {
  msgEl.textContent=t;msgEl.style.color=ok?'#1a7f37':'#b00020';
  if (messageTimer) clearTimeout(messageTimer);
  messageTimer=setTimeout(()=>msgEl.textContent='',12000);
}
async function send(type,more={}) {
  const res=await api.runtime.sendMessage({type,...more});
  if (!res?.ok) throw new Error(res?.reason||'Falha desconhecida');
  return res;
}
function display(c) {
  for (const k of KEYS) {
    const el=document.getElementById(k);if (!el) continue;
    const v=c[k]===undefined?DEFAULTS[k]:c[k];
    if (el.type==='checkbox') el.checked=!!v;
    else el.value=v;
  }
}
async function load() {
  const state=await api.storage.local.get(KEYS);
  display({...DEFAULTS,...state});await refreshLog();
}
function collect() {
  const data={};
  for (const k of KEYS) {
    const el=document.getElementById(k);if (!el) continue;
    if (el.type==='checkbox') data[k]=el.checked;
    else if (el.type==='number') data[k]=el.value.trim()===''?NaN:Number(el.value);
    else data[k]=el.value;
  }
  return data;
}
function checked() {
  const res=normalize(collect());
  if (res.errors.length) throw new Error(res.errors.join('; '));
  return res.config;
}
async function saveCfg() {return send('APC_SAVE_SETTINGS',{settings:checked()});}
async function action(fn,success) {
  try {await fn();flash(success);await refreshLog();} catch(e){flash(String(e?.message||e),false);}
}
document.getElementById('save').addEventListener('click',()=>action(saveCfg,'Configurações validadas e salvas.'));
document.getElementById('testNow').addEventListener('click',async()=>{
  try {
    await saveCfg();const result=await api.runtime.sendMessage({type:'APC_RUN_NOW'});
    flash('Resultado: '+(result?.detail||result?.reason||'sem detalhes'),!!result?.ok);
    await refreshLog();
  } catch(e){flash(String(e?.message||e),false);}
});
document.getElementById('saveAsDefault').addEventListener('click',()=>action(async()=>{
  const customDefaults=checked(); await api.storage.local.set({customDefaults});
},'Padrão personalizado salvo.'));
document.getElementById('restoreCustom').addEventListener('click',()=>action(async()=>{
  const {customDefaults}=await api.storage.local.get('customDefaults');
  if (!customDefaults) throw new Error('Não há padrão personalizado.');
  const c=normalize({...DEFAULTS,...customDefaults});
  if(c.errors.length) throw new Error(c.errors.join('; '));
  await send('APC_SAVE_SETTINGS',{settings:c.config}); display(c.config);
},'Padrão personalizado restaurado.'));
document.getElementById('restoreFactory').addEventListener('click',()=>action(async()=>{
  await api.storage.local.remove('customDefaults');
  await send('APC_SAVE_SETTINGS',{settings:DEFAULTS});display(DEFAULTS);
},'Padrão de fábrica restaurado (sem reiniciar contadores).'));
function exportText(name,txt,type) {
  const blob=new Blob([txt],{type});const u=URL.createObjectURL(blob);
  const link=document.createElement('a');link.href=u;link.download=name;link.click();
  setTimeout(()=>URL.revokeObjectURL(u),2000);
}
async function refreshProfiles() {
  const res=await send('APC_LIST_PROFILES');
  const list=document.getElementById('profileList');
  const selected=list.value;
  list.replaceChildren();
  const empty=document.createElement('option');empty.value='';empty.textContent='— perfis —';list.append(empty);
  for (const origin of res.origins||[]) {
    const opt=document.createElement('option');opt.value=origin;opt.textContent=origin;list.append(opt);
  }
  list.value=selected||'';
}
document.getElementById('saveProfile').addEventListener('click',()=>action(async()=>{
  await saveCfg();await send('APC_SAVE_PROFILE');await refreshProfiles();
},'Perfil da aba vinculada salvo.'));
document.getElementById('loadProfile').addEventListener('click',()=>action(async()=>{
  const origin=document.getElementById('profileList').value;
  if (!origin) throw new Error('Selecione um perfil.');
  await send('APC_LOAD_PROFILE',{origin});await load();
},'Perfil carregado sem ativar a automação.'));
document.getElementById('deleteProfile').addEventListener('click',()=>action(async()=>{
  const origin=document.getElementById('profileList').value;
  if (!origin) throw new Error('Selecione um perfil.');
  if (!confirm('Excluir definitivamente o perfil '+origin+'?')) return;
  await send('APC_DELETE_PROFILE',{origin});await refreshProfiles();
},'Operação de exclusão concluída.'));
document.getElementById('refreshProfiles').addEventListener('click',()=>action(refreshProfiles,'Lista de perfis atualizada.'));
document.getElementById('exportCfg').addEventListener('click',()=>action(async()=>{
  exportText('APC_configuracoes_v4.json',JSON.stringify(checked(),null,2),'application/json');
},'Configurações exportadas.'));
document.getElementById('importCfgBtn').addEventListener('click',()=>document.getElementById('importCfgFile').click());
document.getElementById('importCfgFile').addEventListener('change',ev=>action(async()=>{
  const file=ev.target.files?.[0];if(!file) return;
  try {
    if(file.size>250000) throw new Error('Arquivo muito grande.');
    const json=JSON.parse(await file.text());
    if(!json || typeof json!=='object' || Array.isArray(json)) throw new Error('JSON inválido.');
    const c=normalize({...DEFAULTS,...json});
    if(c.errors.length) throw new Error(c.errors.join('; '));
    await send('APC_SAVE_SETTINGS',{settings:c.config});display(c.config);
  } finally {ev.target.value='';}
},'Configurações importadas e validadas.'));
function format(e) {
  const d=new Date(e.t);
  return d.toLocaleString('pt-BR')+'.'+String(d.getMilliseconds()).padStart(3,'0')+
    ' ['+String(e.l).padEnd(5)+'] ('+e.s+') '+e.m;
}
async function refreshLog() {
  const {log=[]}=await api.storage.local.get('log');
  const view=document.getElementById('logView');
  const bottom=view.scrollTop+view.clientHeight>=view.scrollHeight-30;
  view.value=Array.isArray(log)?log.map(format).join('\n'):'';
  if(bottom)view.scrollTop=view.scrollHeight;
}
document.getElementById('refreshLog').addEventListener('click',refreshLog);
document.getElementById('clearLog').addEventListener('click',()=>action(async()=>{
  await api.storage.local.set({log:[]});await refreshLog();
},'Log limpo.'));
document.getElementById('exportLog').addEventListener('click',()=>{
  exportText('APC_log_v4.txt',document.getElementById('logView').value||'(log vazio)','text/plain');
});
setInterval(()=>{if(document.getElementById('autoRefresh').checked)refreshLog().catch(()=>{});},2000);
load().then(refreshProfiles).catch(e=>flash(String(e),false));
