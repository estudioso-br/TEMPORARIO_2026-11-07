/* APC v5 — configuração compartilhada e sem dependências.
   Carregado por: background (event page do Firefox via scripts[]; service worker
   do Chrome via importScripts), popup e opções (via <script src="../config.js">).
   O content script usa apenas chaves avulsas do storage e não precisa deste arquivo. */
(function (root) {
  'use strict';

  const DEFAULTS = Object.freeze({
    enabled: false, minutes: 37, seconds: 14,
    jitterEnabled: false, jitterMinSec: 0, jitterMaxSec: 300,
    selectorType: 'css', selector: '[aria-label="Pergunte ao ChatGPT"]',
    fallbacks: 'css|[contenteditable="true"][aria-multiline="true"]\ncss|div[role="textbox"]\ncss|.ProseMirror\nxpath-curto|//div[@contenteditable="true" and @role="textbox"]',
    buttonSelector: '', text: 'GOSTEI. OBRIGADO', enterMode: 'auto',
    urlContains: '',
    retries: 3, retryDelayMs: 1500, runOnEnable: true, runOnLoad: false,
    debugMode: true, notifyOnFail: true, notifyRecovery: true,
    dryRun: false, clearBefore: true, enterDelayMs: 0,
    confirmationMode: 'dispatch', confirmationSelector: '', confirmationTimeoutMs: 5000,
    watchdogEnabled: true, watchdogMinutes: 1, healthTimeoutMs: 8000,
    recoveryFailures: 2, maxReloads: 3, recoveryBackoffSec: 30,
    maxCyclesEnabled: false, maxCycles: 5,
    durationEnabled: false, durationHours: 3, durationMinutes: 30, durationSeconds: 0,
    durationMode: 'wall',
    lastRun: null, lastResult: null, nextRun: null
  });

  const CONFIG_KEYS = Object.freeze(Object.keys(DEFAULTS).filter(
    k => !['lastRun', 'lastResult', 'nextRun'].includes(k)
  ));

  const bools = new Set(CONFIG_KEYS.filter(k => typeof DEFAULTS[k] === 'boolean'));

  const nums = {
    minutes: [0, 10080], seconds: [0, 59],
    jitterMinSec: [0, 3600], jitterMaxSec: [0, 3600],
    retries: [0, 20], retryDelayMs: [200, 30000], enterDelayMs: [0, 5000],
    confirmationTimeoutMs: [300, 30000],
    watchdogMinutes: [0.5, 60], healthTimeoutMs: [1000, 30000],
    recoveryFailures: [1, 10], maxReloads: [0, 10], recoveryBackoffSec: [10, 3600],
    maxCycles: [1, 1000000],
    durationHours: [0, 87600], durationMinutes: [0, 59], durationSeconds: [0, 59]
  };

  const choices = {
    selectorType: ['css', 'cssPath', 'xpath', 'outerHTML'],
    enterMode: ['auto', 'keys', 'button', 'none'],
    confirmationMode: ['dispatch', 'field-cleared', 'selector'],
    durationMode: ['wall', 'active']
  };

  const strLimits = {
    selector: 10000, fallbacks: 30000, buttonSelector: 5000,
    confirmationSelector: 5000, text: 20000, urlContains: 2000
  };

  function durationMs(c) {
    return ((Number(c.durationHours) || 0) * 3600 +
            (Number(c.durationMinutes) || 0) * 60 +
            (Number(c.durationSeconds) || 0)) * 1000;
  }

  function nextDelayMs(c, rng) {
    rng = rng || Math.random;
    const lo = c.jitterEnabled ? (Number(c.jitterMinSec) || 0) : 0;
    const hi = c.jitterEnabled ? (Number(c.jitterMaxSec) || 0) : 0;
    const jitter = lo + Math.floor(rng() * (hi - lo + 1));
    const base = (Number(c.minutes) || 0) * 60 + (Number(c.seconds) || 0);
    return { milliseconds: Math.max(30000, (base + jitter) * 1000), jitterSec: jitter };
  }

  /* Normaliza e valida. Em strict=true devolve erros (para salvar na UI);
     em strict=false aplica os padrões sem interromper o background. */
  function normalize(raw, opts) {
    const strict = !opts || opts.strict !== false;
    const data = (raw && typeof raw === 'object' && !Array.isArray(raw)) ? raw : {};
    const cfg = {};
    const errors = [];
    for (const key of CONFIG_KEYS) {
      let v = Object.prototype.hasOwnProperty.call(data, key) ? data[key] : DEFAULTS[key];
      if (bools.has(key)) {
        cfg[key] = (typeof v === 'boolean') ? v : DEFAULTS[key];
        if (typeof v !== 'boolean') errors.push(key + ': esperado booleano');
      } else if (Object.prototype.hasOwnProperty.call(nums, key)) {
        const [min, max] = nums[key];
        const n = (typeof v === 'number') ? v : (typeof v === 'string' && v.trim() !== '' ? Number(v) : NaN);
        if (!Number.isFinite(n) || n < min || n > max) errors.push(key + ': valor fora de [' + min + ', ' + max + ']');
        cfg[key] = (Number.isFinite(n) && n >= min && n <= max) ? n : DEFAULTS[key];
      } else {
        if (typeof v !== 'string' || v.length > (strLimits[key] || 500)) errors.push(key + ': texto inválido');
        cfg[key] = (typeof v === 'string' && v.length <= (strLimits[key] || 500)) ? v : DEFAULTS[key];
        if (choices[key] && !choices[key].includes(cfg[key])) {
          errors.push(key + ': opção inválida');
          cfg[key] = DEFAULTS[key];
        }
      }
    }
    if (cfg.jitterMinSec > cfg.jitterMaxSec) errors.push('jitter: mínimo maior que máximo');
    if (cfg.minutes * 60 + cfg.seconds + (cfg.jitterEnabled ? cfg.jitterMinSec : 0) < 30)
      errors.push('intervalo mínimo de 30 segundos (limitação de alarmes do navegador)');
    if (cfg.durationEnabled && durationMs(cfg) <= 0) errors.push('duração deve ser maior que zero');
    if (cfg.confirmationMode === 'selector' && !cfg.confirmationSelector.trim())
      errors.push('confirmationSelector é obrigatório no modo "seletor"');
    if (!cfg.selector.trim() && !cfg.fallbacks.trim() && !cfg.buttonSelector.trim())
      errors.push('informe ao menos um localizador (primário ou reserva)');
    if (cfg.enterMode !== 'none' && !cfg.text.trim() && !cfg.dryRun)
      errors.push('texto do envio vazio (ou ative o modo simulação)');
    return { config: cfg, errors: strict ? errors : [] };
  }

  root.APC_SHARED = Object.freeze({ DEFAULTS, CONFIG_KEYS, normalize, durationMs, nextDelayMs });
})(globalThis);
