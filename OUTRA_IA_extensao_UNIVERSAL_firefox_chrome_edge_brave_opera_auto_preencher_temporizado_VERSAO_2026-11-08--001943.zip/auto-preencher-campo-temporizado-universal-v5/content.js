/* APC v5 — content script (injetado em TODOS os frames: all_frames: true).
   Executa no Firefox (namespace browser) e Chromium (namespace chrome).
   Responsabilidades:
   - Motor de localização: CSS simples, caminho CSS (com sanitização), XPath
     (com conversão automática para CSS como reserva), HTML externo, piercing
     explícito de Shadow DOM aberto com ">>> " (estilo Selenium) e piercing
     automático recursivo; no Firefox tenta também shadow ROOT FECHADO via
     wrappedJSObject (visão Xray).
   - Sonda (APC_PROBE): cada frame responde se o campo está presente/editável;
     o supervisor escolhe o frame e roteia o preenchimento por frameId.
   - Preenchimento + envio (Enter sintético / botão) + confirmação opcional.
   - Seletor na página (picker): o usuário clica no campo e no botão e a
     extensão gera selector/fallbacks automaticamente.
   - Observador de campo: se o campo sumir após um envio bem-sucedido, avisa
     o supervisor (APC_PAGE_HEALTH) para acionar a recuperação.
*/
(function () {
  if (window.__apcContentLoaded) return;
  window.__apcContentLoaded = true;

  const api = (typeof browser !== 'undefined' && browser && browser.runtime) ? browser : chrome;
  const SRC = location.hostname || (window.top === window ? 'frame0' : 'iframe');
  const LOG_KEY = 'log';
  const LOG_MAX = 500;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const FF = Object.prototype.hasOwnProperty.call(document.documentElement || {}, 'wrappedJSObject') ||
             (typeof window.wrappedJSObject !== 'undefined');

  const CFG_KEYS = ['selectorType','selector','fallbacks','buttonSelector','text','enterMode',
    'retries','retryDelayMs','debugMode','dryRun','clearBefore','enterDelayMs',
    'confirmationMode','confirmationSelector','confirmationTimeoutMs','urlContains','enabled','runOnLoad'];

  async function alog(lvl, msg) {
    try {
      const cur = await api.storage.local.get(LOG_KEY);
      const log = Array.isArray(cur[LOG_KEY]) ? cur[LOG_KEY] : [];
      log.push({ t: Date.now(), s: SRC, l: lvl, m: String(msg).slice(0, 600) });
      if (log.length > LOG_MAX) log.splice(0, log.length - LOG_MAX);
      await api.storage.local.set({ [LOG_KEY]: log });
    } catch (_) {}
  }

  /* ============ utilidades CSS (sanitização de caminhos quebrados) ============ */

  function splitTop(str) { // separa por espaços fora de [] ()
    const out = []; let cur = '', d = 0;
    for (const c of String(str)) {
      if (c === '[' || c === '(') d++;
      if (c === ']' || c === ')') d = Math.max(0, d - 1);
      if (/\s/.test(c) && d === 0) { if (cur) out.push(cur); cur = ''; } else cur += c;
    }
    if (cur) out.push(cur);
    return out;
  }
  function splitDots(tok) { // separa por "." fora de [] ()
    const out = []; let cur = '', d = 0;
    for (const c of String(tok)) {
      if (c === '[' || c === '(') d++;
      if (c === ']' || c === ')') d = Math.max(0, d - 1);
      if (c === '.' && d === 0) { out.push(cur); cur = ''; } else cur += c;
    }
    out.push(cur);
    return out;
  }
  function validSel(s) {
    try { document.createDocumentFragment().querySelector(s); return true; } catch (_) { return false; }
  }
  // Remove partes inválidas (classes Tailwind "[--x:y]", "group/x", "@max-x") de caminhos copiados do DevTools.
  function sanitizePath(path) {
    return splitTop(String(path).trim()).map((t) => {
      if (t === '>' || t === '+' || t === '~') return t;
      let out = '';
      splitDots(t).forEach((p, i) => {
        if (!p) return;
        const piece = i === 0 ? p : '.' + p;
        if (validSel(piece)) out += piece;
      });
      return out;
    }).filter(Boolean).join(' ');
  }

  /* ============ piercing de Shadow DOM ============ */

  // Divide "a >>> b >>> c" respeitando aspas e colchetes.
  function splitPierced(sel) {
    const parts = []; let cur = '', q = null, depth = 0;
    const s = String(sel);
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (q) { cur += c; if (c === q && s[i - 1] !== '\\') q = null; continue; }
      if (c === '"' || c === "'") { q = c; cur += c; continue; }
      if (c === '[' || c === '(') depth++;
      if (c === ']' || c === ')') depth = Math.max(0, depth - 1);
      if (depth === 0 && c === '>' && s[i + 1] === '>' && s[i + 2] === '>') {
        parts.push(cur.trim()); cur = ''; i += 2; continue;
      }
      cur += c;
    }
    parts.push(cur.trim());
    return parts.filter(p => p.length);
  }

  // Retorna o shadow root se acessível (aberto; ou fechado via Xray no Firefox).
  function accessibleShadowRoot(el) {
    if (!el) return null;
    if (el.shadowRoot) return el.shadowRoot;
    try {
      if (el.wrappedJSObject && el.wrappedJSObject.shadowRoot) return el.wrappedJSObject.shadowRoot;
    } catch (_) {}
    return null;
  }

  function deepQueryAll(root, sel, out, depth, maxDepth) {
    depth = depth || 0; maxDepth = maxDepth || 12;
    let list = [];
    try { list = Array.from(root.querySelectorAll(sel)); } catch (_) {}
    for (const el of list) out.push({ el, depth });
    if (depth >= maxDepth) return;
    let all = [];
    try { all = Array.from(root.querySelectorAll('*')); } catch (_) { return; }
    for (const el of all) {
      const sr = accessibleShadowRoot(el);
      if (sr) deepQueryAll(sr, sel, out, depth + 1, maxDepth);
    }
  }

  // Resolve "a >>> b >>> c" atravessando shadow roots (abertos; fechados no Firefox).
  function locateByPiercedSteps(sel) {
    const segs = splitPierced(sel);
    if (segs.length < 2) return null;
    let root = document, el = null;
    for (let i = 0; i < segs.length; i++) {
      let found = null;
      try { found = root.querySelector(segs[i]); } catch (_) { return null; }
      if (!found && i === 0) { // tolerância a caminhos quebrados no primeiro segmento
        try { found = root.querySelector(sanitizePath(segs[i])); } catch (_) {}
      }
      if (!found) return null;
      el = found;
      root = (i < segs.length - 1) ? accessibleShadowRoot(el) : null;
      if (i < segs.length - 1 && !root) return null;
    }
    return el;
  }

  /* ============ XPath → CSS (conversão best-effort para reservas) ============ */

  function xpathToCss(xp) {
    const s = String(xp || '').trim();
    const out = [];
    // //tag[@a="v"] / //*[@a="v"] — predicados simples, com and
    const m = s.match(/^\/\/([a-zA-Z*][\w-]*|\*)\[(.+)\]$/);
    if (m) {
      const tag = m[1] === '*' ? '' : m[1].toLowerCase();
      const preds = m[2].split(/\s+and\s+/i).map(p => p.trim());
      const attrs = [];
      let ok = true;
      for (const p of preds) {
        let mm = p.match(/^@([\w-]+)\s*=\s*["']([^"']*)["']$/);
        if (mm) { attrs.push('[' + mm[1] + '="' + mm[2].replace(/"/g, '') + '"]'); continue; }
        mm = p.match(/^contains\(@([\w-]+)\s*,\s*["']([^"']*)["']\)$/i);
        if (mm) { attrs.push('[' + mm[1] + '*="' + mm[2].replace(/"/g, '') + '"]'); continue; }
        mm = p.match(/^starts-with\(@([\w-]+)\s*,\s*["']([^"']*)["']\)$/i);
        if (mm) { attrs.push('[' + mm[1] + '^="' + mm[2].replace(/"/g, '') + '"]'); continue; }
        ok = false; break; // text() e outros: não conversível
      }
      if (ok && attrs.length) out.push((tag || '*') + attrs.join(''));
    }
    return out;
  }

  /* ============ localização ============ */

  const TYPE_ALIASES = {
    'css': 'css', 'seletor-css': 'css',
    'csspath': 'cssPath', 'css-path': 'cssPath', 'caminho-css': 'cssPath',
    'xpath': 'xpath', 'xpath-curto': 'xpath', 'xpath-short': 'xpath', 'xpath-longo': 'xpath', 'xpath-long': 'xpath',
    'outerhtml': 'outerHTML', 'html-externo': 'outerHTML'
  };

  function parseLine(line) {
    const raw = (line || '').trim();
    if (!raw) return null;
    const i = raw.indexOf('|');
    if (i < 0) return { type: 'css', sel: raw, label: 'css(sem prefixo)' };
    const head = raw.slice(0, i).trim().toLowerCase();
    const type = TYPE_ALIASES[head] || 'css';
    return { type, sel: raw.slice(i + 1).trim(), label: head };
  }

  function locateOne(type, sel) {
    const s = (sel || '').trim();
    if (!s) return null;
    switch (type) {
      case 'xpath': {
        try {
          const r = document.evaluate(s, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
          return r.singleNodeValue;
        } catch (_) { return null; }
      }
      case 'outerHTML': {
        const target = s.replace(/\s+/g, ' ').trim();
        const walker = document.createTreeWalker(document, NodeFilter.SHOW_ELEMENT);
        let n = walker.currentNode;
        while (n) {
          if (n.outerHTML && n.outerHTML.replace(/\s+/g, ' ').trim() === target) return n;
          n = walker.nextNode();
        }
        return null;
      }
      case 'cssPath': {
        for (const cand of [s, sanitizePath(s)]) {
          try {
            const el = document.querySelector(cand);
            if (el) return el;
            // último recurso: cauda do caminho (últimos 3 tokens)
            const toks = splitTop(sanitizePath(cand));
            if (toks.length > 1) {
              const tail = document.querySelector(toks.slice(-3).join(' ')) || document.querySelector(toks.slice(-1).join(' '));
              if (tail) return tail;
            }
          } catch (_) {}
        }
        return null;
      }
      case 'css':
      default: {
        if (s.includes('>>>')) return locateByPiercedSteps(s);
        try {
          const direct = document.querySelector(s);
          if (direct) return direct;
        } catch (_) { return null; }
        // piercing automático recursivo (shadow DOM aberto e, no Firefox, fechado)
        const hits = [];
        deepQueryAll(document, s, hits, 0, 12);
        if (hits.length) hits.sort((a, b) => a.depth - b.depth);
        return hits.length ? hits[0].el : null;
      }
    }
  }

  function buildAttempts(cfg) {
    const tries = [];
    const main = (cfg.selector || '').trim();
    if (main) tries.push({ type: cfg.selectorType || 'css', sel: main, label: 'PRIMÁRIO(' + (cfg.selectorType || 'css') + ')' });
    String(cfg.fallbacks || '').split('\n').forEach((line, idx) => {
      const p = parseLine(line);
      if (p && p.sel) tries.push({ type: p.type, sel: p.sel, label: 'reserva#' + (idx + 1) + '(' + p.label + ')' });
    });
    // Reserva automática: converte XPath primário/de reserva para CSS (quando possível).
    for (const t of tries.slice()) {
      if (t.type !== 'xpath') continue;
      for (const css of xpathToCss(t.sel)) {
        tries.push({ type: 'css', sel: css, label: 'auto(xpath→css)' });
      }
    }
    return tries;
  }

  async function locateAll(cfg) {
    const tries = buildAttempts(cfg);
    for (const t of tries) {
      const el = locateOne(t.type, t.sel);
      if (cfg.debugMode) {
        await alog('DEBUG', 'Tentativa [' + t.label + '] ' + (t.sel.length > 90 ? t.sel.slice(0, 90) + '…' : t.sel) +
          ' => ' + (el ? 'ENCONTRADO' : 'não encontrado') + '.');
      }
      if (el) {
        let depth = 0, cur = el;
        while (cur && cur !== document) {
          const root = cur.getRootNode();
          if (root instanceof ShadowRoot) { depth++; cur = root.host; } else break;
        }
        const closed = !el.getRootNode().host && el.shadowRoot === null && el.wrappedJSObject && el.wrappedJSObject.shadowRoot ? true : false;
        return { el, used: t.label, sel: t.sel, shadowDepth: depth, viaClosedFF: closed && !el.shadowRoot };
      }
    }
    return null;
  }

  /* ============ disponibilidade do campo ============ */

  function pickEditable(el) {
    if (!el) return null;
    if (el.isContentEditable || el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') return el;
    return el.querySelector && el.querySelector("[contenteditable='true'], [contenteditable=''], [contenteditable='plaintext-only'], textarea, input:not([type='hidden']):not([type='checkbox']):not([type='radio']):not([type='button']):not([type='submit'])");
  }

  function isUsable(el) {
    if (!el) return false;
    try {
      if (el.disabled || el.readOnly) return false;
      if (el.getAttribute && el.getAttribute('aria-disabled') === 'true') return false;
      if (!el.getClientRects().length) return false;
      const st = getComputedStyle(el);
      if (st.visibility === 'hidden' || st.display === 'none') return false;
    } catch (_) { return false; }
    return true;
  }

  function describe(el) {
    if (!el) return '(nulo)';
    const parts = ['<' + el.tagName.toLowerCase() + '>'];
    if (el.id) parts.push('#' + el.id);
    const al = el.getAttribute && el.getAttribute('aria-label');
    if (al) parts.push('aria-label="' + al + '"');
    if (el.isContentEditable) parts.push('contenteditable');
    const cls = (el.className && typeof el.className === 'string') ? el.className.trim().split(/\s+/).slice(0, 3).join('.') : '';
    if (cls) parts.push('.' + cls);
    return parts.join(' ');
  }

  /* ============ preenchimento e envio ============ */

  function fillContentEditable(el, text, clearBefore) {
    el.focus();
    const selWin = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(el);
    if (!clearBefore) range.collapse(false);
    selWin.removeAllRanges();
    selWin.addRange(range);
    if (clearBefore) document.execCommand('delete', false, null);
    const ok = document.execCommand('insertText', false, text);
    if (!ok) {
      if (clearBefore) el.textContent = '';
      el.textContent += text;
      el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
    }
  }

  function fillInput(el, text) {
    el.focus();
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    desc.set.call(el, text);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function pressEnter(el) {
    const opts = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true, composed: true };
    el.dispatchEvent(new KeyboardEvent('keydown', opts));
    el.dispatchEvent(new KeyboardEvent('keypress', opts));
    el.dispatchEvent(new KeyboardEvent('keyup', opts));
    el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertParagraph' }));
  }

  function clickSendButton(el, cfg) {
    // 1º: botão configurado (picker ou manual), com piercing de shadow
    const sel = (cfg.buttonSelector || '').trim();
    if (sel) {
      const b = locateOne('css', sel);
      if (b && !b.disabled) { b.click(); return b; }
    }
    // 2º: heurística clássica
    const root = el.closest("form") || el.closest("[class*='composer' i]") || el.closest('[class*="chat"] i') || document;
    const buttons = Array.from(root.querySelectorAll('button'));
    const cand = buttons.find((b) =>
      !b.disabled &&
      (b.type === 'submit' ||
        /enviar|send|submit/i.test(b.getAttribute('aria-label') || '') ||
        /send|enviar/i.test((b.dataset && (b.dataset.testid || b.dataset.test)) || ''))
    );
    if (cand) { cand.click(); return cand; }
    return null;
  }

  function fieldText(el) {
    return el.isContentEditable ? el.textContent : (el.value || '');
  }

  async function confirmDispatch(target, cfg) {
    const mode = cfg.confirmationMode || 'dispatch';
    if (mode === 'dispatch') return { confirmed: false };
    const timeout = Math.max(300, Number(cfg.confirmationTimeoutMs) || 5000);
    const t0 = Date.now();
    if (mode === 'field-cleared') {
      while (Date.now() - t0 < timeout) {
        await sleep(250);
        if (fieldText(target).trim() === '') return { confirmed: true, how: 'campo esvaziado pela página' };
      }
      return { ambiguous: true, how: 'campo não esvaziou dentro de ' + timeout + ' ms' };
    }
    if (mode === 'selector') {
      while (Date.now() - t0 < timeout) {
        await sleep(250);
        const el = locateOne('css', cfg.confirmationSelector || '');
        if (el) return { confirmed: true, how: 'seletor de confirmação apareceu' };
      }
      return { ambiguous: true, how: 'seletor de confirmação não apareceu em ' + timeout + ' ms' };
    }
    return { confirmed: false };
  }

  async function submitByMode(target, cfg) {
    const mode = cfg.enterMode || 'auto';
    if (Number(cfg.enterDelayMs) > 0) await sleep(Number(cfg.enterDelayMs));
    if (mode === 'none') return { submitted: false, method: 'none' };
    if (mode === 'keys' || mode === 'auto') pressEnter(target);
    if (mode === 'keys') return { submitted: true, method: 'keys' };
    if (mode === 'button') {
      const b = clickSendButton(target, cfg);
      return { submitted: !!b, method: 'button' + (b ? '' : ' (não achou: ' + ((cfg.buttonSelector || 'heurística') ) + ')') };
    }
    await sleep(400);
    const rest = fieldText(target).trim();
    if (rest.length > 0) {
      const b = clickSendButton(target, cfg);
      return { submitted: !!b, method: 'auto(fallback botão: ' + (b ? describe(b) : 'não achou botão') + ')' };
    }
    return { submitted: true, method: 'auto(teclas)' };
  }

  /* ============ execução do ciclo ============ */

  async function run(cfg) {
    const t0 = Date.now();
    try {
      await alog('INFO', 'Início do preenchimento em ' + location.href + (window.top === window ? ' (frame principal)' : ' (iframe)'));
      const retries = Math.max(0, Number(cfg.retries) || 0);
      let found = null;
      for (let i = 0; i <= retries; i++) {
        found = await locateAll(cfg);
        if (found) break;
        if (i < retries) {
          if (cfg.debugMode) await alog('DEBUG', 'Nada encontrado na rodada ' + (i + 1) + '; nova tentativa em ' + (Number(cfg.retryDelayMs) || 1500) + ' ms.');
          await sleep(Number(cfg.retryDelayMs) || 1500);
        }
      }
      if (!found) {
        await alog('WARN', 'Elemento NÃO localizado após ' + (retries + 1) + ' rodada(s), em nenhum seletor (primário/reserva/auto), neste frame.');
        return { ok: false, reason: 'elemento não encontrado na página' };
      }
      const shadowInfo = found.shadowDepth ? (' | shadow=' + found.shadowDepth + ' nível(is)' + (found.viaClosedFF ? ' [fechado via Xray/Firefox]' : '')) : '';
      await alog('INFO', 'Elemento localizado via [' + found.used + ']: ' + describe(found.el) + shadowInfo);
      try { found.el.scrollIntoView({ block: 'center' }); } catch (_) {}

      const target = pickEditable(found.el);
      if (!target) {
        await alog('ERROR', 'O elemento ' + describe(found.el) + ' não é editável nem contém input/textarea/contenteditable.');
        return { ok: false, reason: 'elemento localizado não é editável' };
      }
      if (!isUsable(target)) {
        await alog('ERROR', 'O campo ' + describe(target) + ' está desabilitado, oculto ou bloqueado (disabled/readonly/aria-disabled/invisível).');
        return { ok: false, terminal: true, reason: 'campo indisponível (desabilitado ou invisível)' };
      }
      if (target !== found.el && cfg.debugMode) await alog('DEBUG', 'Campo editável interno: ' + describe(target));

      if (cfg.dryRun) {
        await alog('INFO', 'SIMULAÇÃO (dryRun): campo pronto; nada foi preenchido nem enviado | duração ' + (Date.now() - t0) + ' ms.');
        return { ok: true, dryRun: true, description: 'campo pronto em ' + describe(target) + shadowInfo + ' (simulação, nada enviado)' };
      }

      const text = String(cfg.text || '');
      if (target.isContentEditable) fillContentEditable(target, text, cfg.clearBefore !== false);
      else fillInput(target, text);

      const conteudo = fieldText(target);
      if (conteudo.trim() !== text.trim()) {
        await alog('ERROR', "Verificação pós-preenchimento FALHOU: campo contém '" + conteudo.slice(0, 80) + "' (esperado '" + text.slice(0, 80) + "').");
        return { ok: false, reason: 'texto não permaneceu no campo após inserção' };
      }
      await alog('INFO', 'Texto inserido e verificado (' + text.length + ' caracteres).');

      const sub = await submitByMode(target, cfg);
      await alog(sub.submitted ? 'INFO' : 'WARN', "Envio modo '" + (cfg.enterMode || 'auto') + "' (" + sub.method + ') => ' + (sub.submitted ? 'disparado' : 'NÃO disparado'));
      if (!sub.submitted) return { ok: false, reason: 'não foi possível disparar o envio (modo ' + (cfg.enterMode || 'auto') + ')' };

      const conf = await confirmDispatch(target, cfg);
      if (conf.ambiguous) {
        await alog('ERROR', 'ENVIO AMBÍGUO: ' + conf.how);
        return { ok: false, maybeDispatched: true, reason: conf.how };
      }
      await alog('INFO', conf.confirmed ? ('Envio CONFIRMADO na interface (' + conf.how + ').') : 'Envio disparado (sem confirmação remota).');
      await alog('INFO', 'Preenchimento concluído com sucesso | duração ' + (Date.now() - t0) + ' ms.');
      startFieldWatch(target, cfg);
      return { ok: true, confirmed: conf.confirmed, description: describe(target) + shadowInfo + ' via [' + found.used + ']' };
    } catch (e) {
      await alog('ERROR', 'Exceção durante execução: ' + (e && e.message));
      return { ok: false, reason: String(e && e.message) };
    }
  }

  /* ============ observador de campo (pós-envio) ============ */

  let watchTimer = null, watchLostStreak = 0, watchTarget = null, watchCfg = null;

  function startFieldWatch(target, cfg) {
    watchTarget = target; watchCfg = cfg; watchLostStreak = 0;
    if (watchTimer) return;
    watchTimer = setInterval(async () => {
      try {
        if (!watchCfg || !watchCfg.enabled !== false) { /* continua vigiando */ }
        const s = await api.storage.local.get(['enabled']);
        if (!s.enabled) return;
        const stillThere = (watchTarget && watchTarget.isConnected && isUsable(watchTarget)) ||
                           !!(await locateAll(watchCfg));
        if (stillThere) { watchLostStreak = 0; return; }
        watchLostStreak++;
        if (watchLostStreak >= 2) {
          await alog('WARN', 'Campo alvo desapareceu/bloqueou após o envio — avisando o supervisor.');
          api.runtime.sendMessage({ type: 'APC_PAGE_HEALTH', ready: false, reason: 'campo alvo desapareceu do frame' }).catch(() => {});
          stopFieldWatch();
        }
      } catch (_) { stopFieldWatch(); }
    }, 15000);
  }
  function stopFieldWatch() {
    if (watchTimer) { clearInterval(watchTimer); watchTimer = null; }
    watchLostStreak = 0;
  }

  /* ============ sonda (descoberta de frame + saúde) ============ */

  let lastProbeState = '';

  async function probeNow() {
    const cfg = await api.storage.local.get(['selectorType', 'selector', 'fallbacks', 'debugMode']);
    const merged = Object.assign({ selectorType: 'css', selector: '', fallbacks: '', debugMode: false }, cfg);
    const found = await locateAll({ ...merged, debugMode: false }); // sonda silenciosa
    const target = found ? pickEditable(found.el) : null;
    const editable = !!target && isUsable(target);
    const state = (found ? '1' : '0') + (editable ? 'e' : '');
    if (state !== lastProbeState) {
      lastProbeState = state;
      if (merged.debugMode) {
        await alog('DEBUG', found ? ('Sonda: campo ENCONTRADO neste frame via [' + found.used + ']' + (editable ? ' (editável)' : ' (não editável)'))
                                  : 'Sonda: campo não encontrado neste frame.');
      }
    }
    return {
      type: 'APC_PROBE_REPORT',
      present: !!found,
      editable,
      used: found ? found.used : '',
      shadowDepth: found ? found.shadowDepth : 0,
      frameUrl: location.href,
      href: location.href
    };
  }

  /* ============ diagnóstico do frame principal ============ */

  async function diagnoseFrame() {
    let shadowOpen = 0, shadowClosed = 0, iframeCount = 0;
    try { iframeCount = document.querySelectorAll('iframe,frame').length; } catch (_) {}
    const walk = (root, depth) => {
      if (depth > 12) return;
      let all = [];
      try { all = Array.from(root.querySelectorAll('*')); } catch (_) { return; }
      for (const el of all) {
        if (el.shadowRoot) { shadowOpen++; walk(el.shadowRoot, depth + 1); }
        else if (FF && el.wrappedJSObject) {
          try { if (el.wrappedJSObject.shadowRoot) shadowClosed++; } catch (_) {}
        }
      }
    };
    walk(document, 0);
    return {
      ok: true,
      shadowOpen,
      shadowClosed,
      closedNote: FF ? 'fechados acessáveis via Xray (Firefox)' : 'fechados INACESSÍVEIS no Chromium (ver README)',
      iframeCount
    };
  }

  /* ============ seletor na página (picker) ============ */

  let picker = null; // {mode, banner, hi, onMouseMove, onClick, onKey}

  function segFor(el) {
    const tag = el.tagName.toLowerCase();
    const scope = el.parentElement || el.getRootNode() || document;
    const cand = [];
    if (el.id && el.id.length <= 80) cand.push('#' + (window.CSS && CSS.escape ? CSS.escape(el.id) : el.id));
    for (const a of ['data-testid', 'data-test', 'name', 'aria-label', 'title', 'placeholder']) {
      const v = el.getAttribute && el.getAttribute(a);
      if (v && v.length <= 120) cand.push(tag + '[' + a + '="' + v.replace(/"/g, '') + '"]');
    }
    const cls = (typeof el.className === 'string' && el.className.trim())
      ? el.className.trim().split(/\s+/).filter(c => c.length < 40 && !c.includes(':') && !c.includes('/') && !c.startsWith('@')).slice(0, 2) : [];
    if (cls.length) cand.push(tag + '.' + cls.map(c => (window.CSS && CSS.escape ? CSS.escape(c) : c)).join('.'));
    cand.push(tag);
    for (const c of cand) {
      try { if (scope.querySelector(c) === el) return c; } catch (_) {}
    }
    const parent = el.parentElement;
    if (parent) {
      let n = 0, idx = 0;
      for (const sib of parent.children) if (sib.tagName === el.tagName) { n++; if (sib === el) idx = n; }
      if (idx > 0) return tag + ':nth-of-type(' + idx + ')';
    }
    return tag;
  }

  function pathInRoot(el) {
    const parts = [];
    let cur = el;
    while (cur) {
      parts.unshift(segFor(cur));
      if (!cur.parentElement) break;
      cur = cur.parentElement;
    }
    return parts.join(' > ');
  }

  // Cadeia com ">>>" quando o elemento vive dentro de shadow roots.
  function genPiercedChain(el) {
    const segs = [];
    let cur = el;
    let guard = 0;
    while (cur && guard++ < 15) {
      const root = cur.getRootNode();
      if (root instanceof ShadowRoot) {
        segs.unshift(pathInRoot(cur));
        cur = root.host;
      } else {
        segs.unshift(pathInRoot(cur));
        break;
      }
    }
    return segs.join(' >>> ');
  }

  function uniqueInDoc(css) {
    try { return document.querySelectorAll(css).length === 1; } catch (_) { return false; }
  }

  function genXPath(el) {
    for (const a of ['data-testid', 'aria-label', 'name', 'id', 'title', 'placeholder']) {
      const v = el.getAttribute && el.getAttribute(a);
      if (v && v.length <= 120) {
        const xp = '//' + el.tagName.toLowerCase() + '[@' + a + '="' + v.replace(/"/g, '') + '"]';
        try {
          const snap = document.evaluate(xp, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
          if (snap.snapshotLength === 1) return xp;
        } catch (_) {}
      }
    }
    return '';
  }

  function buildPickResult(el) {
    const primary = genPiercedChain(el);
    const fallbacks = [];
    const minimal = (() => {
      for (const c of [
        el.id ? '#' + (window.CSS && CSS.escape ? CSS.escape(el.id) : el.id) : '',
        ...(['data-testid', 'data-test', 'name', 'aria-label', 'title', 'placeholder'].map(a => {
          const v = el.getAttribute && el.getAttribute(a);
          return v && v.length <= 120 ? el.tagName.toLowerCase() + '[' + a + '="' + v.replace(/"/g, '') + '"]' : '';
        }))
      ]) { if (c && uniqueInDoc(c)) return c; }
      return '';
    })();
    if (minimal && minimal !== primary) fallbacks.push('css|' + minimal);
    const xp = genXPath(el);
    if (xp) fallbacks.push('xpath-curto|' + xp);
    return { primary, fallbacks };
  }

  function disarmPicker() {
    if (!picker) return;
    window.removeEventListener('mousemove', picker.onMouseMove, true);
    window.removeEventListener('click', picker.onClick, true);
    window.removeEventListener('keydown', picker.onKey, true);
    if (picker.banner) picker.banner.remove();
    if (picker.hi) picker.hi.remove();
    picker = null;
  }

  function armPicker(phase) {
    disarmPicker();
    const banner = document.createElement('div');
    banner.textContent = phase === 'button'
      ? 'APC (2/2): clique no BOTÃO de envio — Esc pula esta fase'
      : 'APC (1/2): clique no CAMPO a preencher — Esc cancela';
    banner.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#1f6feb;color:#fff;font:13px system-ui;padding:8px 12px;text-align:center;pointer-events:none;';
    const hi = document.createElement('div');
    hi.style.cssText = 'position:fixed;z-index:2147483646;pointer-events:none;border:2px solid #e0245e;background:rgba(224,36,94,.15);display:none;';
    document.documentElement.appendChild(banner);
    document.documentElement.appendChild(hi);

    const onMouseMove = (ev) => {
      const el = document.elementFromPoint(ev.clientX, ev.clientY);
      if (!el || banner.contains(el) || hi === el) { hi.style.display = 'none'; return; }
      const r = el.getBoundingClientRect();
      hi.style.display = 'block';
      hi.style.left = r.left + 'px'; hi.style.top = r.top + 'px';
      hi.style.width = r.width + 'px'; hi.style.height = r.height + 'px';
    };
    const finish = () => {
      disarmPicker();
      api.runtime.sendMessage({ type: 'APC_PICK_RESULT', phase: 'button', buttonSelector: '', frameUrl: location.href }).catch(() => {});
    };
    const onClick = (ev) => {
      ev.preventDefault(); ev.stopPropagation();
      const el = document.elementFromPoint(ev.clientX, ev.clientY);
      if (!el || banner.contains(el)) return;
      const res = buildPickResult(el);
      if (picker && picker.mode === 'field') {
        api.runtime.sendMessage({
          type: 'APC_PICK_RESULT', phase: 'field',
          selector: res.primary, fallbacks: res.fallbacks, frameUrl: location.href
        }).catch(() => {});
        alog('INFO', 'PICK: campo apontado → ' + res.primary.slice(0, 160) + (res.fallbacks.length ? ' +' + res.fallbacks.length + ' reserva(s)' : ''));
        armPicker('button'); // fase 2 local
      } else {
        api.runtime.sendMessage({
          type: 'APC_PICK_RESULT', phase: 'button',
          buttonSelector: res.primary, frameUrl: location.href
        }).catch(() => {});
        alog('INFO', 'PICK: botão apontado → ' + res.primary.slice(0, 160));
        disarmPicker();
      }
    };
    const onKey = (ev) => {
      if (ev.key !== 'Escape') return;
      ev.preventDefault(); ev.stopPropagation();
      if (picker && picker.mode === 'field') {
        api.runtime.sendMessage({ type: 'APC_PICK_CANCEL' }).catch(() => {});
        disarmPicker();
      } else finish();
    };
    picker = { mode: phase, banner, hi, onMouseMove, onClick, onKey };
    window.addEventListener('mousemove', onMouseMove, true);
    window.addEventListener('click', onClick, true);
    window.addEventListener('keydown', onKey, true);
  }

  /* ============ listener de mensagens ============ */

  api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || typeof msg.type !== 'string') return false;
    if (msg.type === 'APC_FILL') {
      (async () => {
        const cfg = await api.storage.local.get(CFG_KEYS);
        const merged = Object.assign({
          selectorType: 'css', selector: '', fallbacks: '', buttonSelector: '',
          text: '', enterMode: 'auto', retries: 3, retryDelayMs: 1500, debugMode: false,
          dryRun: false, clearBefore: true, enterDelayMs: 0,
          confirmationMode: 'dispatch', confirmationSelector: '', confirmationTimeoutMs: 5000
        }, cfg);
        const r = await run(merged);
        sendResponse(r);
      })();
      return true;
    }
    if (msg.type === 'APC_PROBE') {
      void probeNow().then(rep => api.runtime.sendMessage(rep).catch(() => {}));
      return false; // resposta vai por APC_PROBE_REPORT (difusão para todos os frames)
    }
    if (msg.type === 'APC_RUN_DIAGNOSE') {
      diagnoseFrame().then(sendResponse).catch(() => sendResponse({ ok: false }));
      return true;
    }
    if (msg.type === 'APC_PICK_START') { armPicker(msg.phase === 'button' ? 'button' : 'field'); return false; }
    if (msg.type === 'APC_PICK_CANCEL') { disarmPicker(); return false; }
    return false;
  });

  /* ============ gatilho runOnLoad (apenas frame principal) ============ */

  (async () => {
    try {
      if (window.top !== window) return;
      const s = await api.storage.local.get(['enabled', 'runOnLoad', 'urlContains']);
      if (!s.enabled || !s.runOnLoad) return;
      const f = (s.urlContains || '').trim();
      if (f && !f.startsWith('/')) {
        if (!location.href.toLowerCase().includes(f.toLowerCase())) return;
      } else if (f.startsWith('/')) {
        const m = f.match(/^\/(.+)\/([a-z]*)$/i);
        if (m) { try { if (!new RegExp(m[1], m[2]).test(location.href)) return; } catch (_) { return; } }
      }
      await sleep(1500);
      await alog('INFO', 'Gatilho runOnLoad: página carregada, solicitando execução ao supervisor.');
      api.runtime.sendMessage({ type: 'APC_RUN_NOW' }).catch(() => {});
    } catch (_) {}
  })();
})();
