/* APC v5 — supervisor de aba (background).
   Fonte única para Firefox MV3 (event page, via background.scripts) e
   Chromium MV3 (service worker). Todas as transições de estado críticas são
   serializadas em uma fila de promessas e persistidas em storage.local.

   Responsabilidades:
   - Sessão vinculada a uma aba/origem (bind), contadores e limites.
   - Sonda por frames: difunde APC_PROBE a todos os frames, coleta relatórios
     (APC_PROBE_REPORT com frameId) e roteia o preenchimento ao frame correto.
   - Vigia (watchdog): verifica saúde periodicamente; crash/erro/aba descartada
     → recarregar → verificar campo → retomar o ciclo (com backoff e limites).
   - Semântica anti-duplicidade: o ciclo é persistido ANTES do disparo; se a
     conexão cair no meio, a sessão entra em "ENVIO INCERTO" e exige decisão
     manual em vez de reenviar por conta própria.
   - Seletor na página (picker): recebe o elemento escolhido pelo usuário e
     grava selector/fallbacks/buttonSelector automaticamente.
*/
'use strict';
if (typeof importScripts === 'function' && !globalThis.APC_SHARED) importScripts('config.js');

const api = (typeof browser !== 'undefined' && browser && browser.runtime) ? browser : chrome;
const SH = globalThis.APC_SHARED;

const CYCLE_ALARM = 'apc-v5-cycle';
const WATCH_ALARM = 'apc-v5-watchdog';
const LIMIT_ALARM = 'apc-v5-duration';
const PROBE_WINDOW_MS = 1500;
const LOG_MAX = 500;
const VERSION = '5.0.0';

let chain = Promise.resolve();
const queue = (fn) => { const t = chain.then(fn, fn); chain = t.catch(() => {}); return t; };
const now = () => Date.now();

/* ---------------- infraestrutura: config, sessão, log, notificação ---------------- */

async function config() {
  const stored = await api.storage.local.get(SH.CONFIG_KEYS);
  const merged = Object.assign({}, SH.DEFAULTS);
  for (const k of SH.CONFIG_KEYS) if (stored[k] !== undefined) merged[k] = stored[k];
  return SH.normalize(merged, { strict: false }).config;
}
async function session() { return (await api.storage.local.get('apcSession')).apcSession || null; }
async function save(s) { await api.storage.local.set({ apcSession: s, nextRun: (s && s.nextDueAt) || null }); }

async function log(level, message) {
  try {
    const { log: arr } = await api.storage.local.get('log');
    const list = Array.isArray(arr) ? arr : [];
    list.push({ t: now(), s: 'supervisor', l: level, m: String(message).slice(0, 480) });
    if (list.length > LOG_MAX) list.splice(0, list.length - LOG_MAX);
    await api.storage.local.set({ log: list });
  } catch (_) { /* diagnóstico não pode interromper a execução */ }
}

async function notify(cfg, title, message, recovery) {
  const on = recovery ? cfg.notifyRecovery : cfg.notifyOnFail;
  if (!on) return;
  try {
    await api.notifications.create('', {
      type: 'basic',
      iconUrl: api.runtime.getURL('icons/icon48.png'),
      title, message
    });
  } catch (_) {}
}

async function setStatus(message, successful) {
  await api.storage.local.set({
    lastRun: now(),
    lastResult: (successful ? 'RESULTADO — ' : 'FALHA — ') + message
  });
}

async function badge(c, s) {
  let text = '', color = '#247c43';
  if (c.enabled && s && (s.status === 'running' || s.status === 'recovering')) {
    text = s.status === 'recovering' ? 'FIX' : 'ON';
    color = s.status === 'recovering' ? '#b45309' : '#247c43';
  } else if (s && s.status === 'uncertain') { text = '?'; color = '#b42318'; }
  else if (s && s.status === 'completed') { text = 'FIN'; color = '#1f6feb'; }
  try {
    await api.action.setBadgeBackgroundColor({ color });
    await api.action.setBadgeText({ text });
  } catch (_) {}
}

/* ---------------- limites: ciclos e duração (wall/active) ---------------- */

function activeUsed(s, t) { return (s.activeElapsedMs || 0) + (s.activeSince ? Math.max(0, (t || now()) - s.activeSince) : 0); }
function setActive(s, active, t) {
  if (s.activeSince) s.activeElapsedMs = activeUsed(s, t);
  s.activeSince = active ? (t || now()) : null;
}
function leftTime(s, c, t) {
  if (!c.durationEnabled || !s.startedAt) return Infinity;
  const duration = SH.durationMs(c);
  return c.durationMode === 'active' ? duration - activeUsed(s, t) : duration - ((t || now()) - s.startedAt);
}
function limitReached(s, c, t) {
  if (c.maxCyclesEnabled && s.completedCycles >= c.maxCycles) return 'limite de ciclos atingido (' + c.maxCycles + ')';
  if (c.durationEnabled && leftTime(s, c, t) <= 0) {
    const d = SH.durationMs(c);
    const txt = Math.floor(d / 3600000) + 'h' + Math.floor((d % 3600000) / 60000) + 'm' + Math.round((d % 60000) / 1000) + 's';
    return 'limite de duração atingido (' + txt + (c.durationMode === 'active' ? ', tempo ativo' : ', tempo de relógio') + ')';
  }
  return null;
}
async function finishIfDue(s, c) {
  const reason = limitReached(s, c);
  if (!reason) return false;
  setActive(s, false);
  s.status = 'completed'; s.endReason = reason; s.nextDueAt = null; s.endedAt = now();
  await api.storage.local.set({ enabled: false });
  c.enabled = false;
  await save(s); await timers(c, s);
  await log('INFO', reason + '; ciclos concluídos: ' + s.completedCycles + ' (tentados: ' + s.attemptedCycles + ').');
  await setStatus(reason + ' — automação encerrada normalmente.', true);
  await notify(c, 'Auto Preencher Campo', reason + '. Automação encerrada.', true);
  return true;
}
async function scheduleNext(s, c) {
  const delay = SH.nextDelayMs(c);
  s.nextDueAt = now() + delay.milliseconds;
  await save(s); await timers(c, s);
  await log('INFO', 'próximo ciclo em ' + Math.round(delay.milliseconds / 1000) + 's (jitter ' + delay.jitterSec + 's).');
}

/* ---------------- alarmes ---------------- */

async function timers(c, s) {
  for (const name of [CYCLE_ALARM, LIMIT_ALARM]) await api.alarms.clear(name);
  const active = !!(c.enabled && s && (s.status === 'running' || s.status === 'recovering'));
  const existing = await api.alarms.get(WATCH_ALARM);
  if (active && c.watchdogEnabled) {
    if (!existing || Math.abs((existing.periodInMinutes || 0) - c.watchdogMinutes) > 0.0001)
      api.alarms.create(WATCH_ALARM, { periodInMinutes: c.watchdogMinutes });
  } else if (existing) await api.alarms.clear(WATCH_ALARM);
  if (active && s.status === 'running' && Number.isFinite(s.nextDueAt))
    api.alarms.create(CYCLE_ALARM, { when: Math.max(now() + 30000, s.nextDueAt) });
  if (active && c.durationEnabled && Number.isFinite(leftTime(s, c)))
    api.alarms.create(LIMIT_ALARM, { when: Math.max(now() + 30000, now() + leftTime(s, c)) });
  await badge(c, s);
}

/* ---------------- sonda de frames (descoberta + saúde) ---------------- */

function collectProbe(tabId, windowMs) {
  return new Promise((resolve) => {
    const reports = [];
    let done = false;
    const onMsg = (m, sender) => {
      if (!m || m.type !== 'APC_PROBE_REPORT' || !sender.tab || sender.tab.id !== tabId) return;
      reports.push(Object.assign({}, m, { frameId: (sender.frameId !== undefined) ? sender.frameId : 0 }));
    };
    api.runtime.onMessage.addListener(onMsg);
    try {
      const p = api.tabs.sendMessage(tabId, { type: 'APC_PROBE' });
      if (p && typeof p.catch === 'function') p.catch(() => {});
    } catch (_) {}
    setTimeout(() => {
      if (done) return;
      done = true;
      try { api.runtime.onMessage.removeListener(onMsg); } catch (_) {}
      resolve(reports);
    }, windowMs || PROBE_WINDOW_MS);
  });
}

function probeAndChoose(s, reports) {
  const ready = reports.filter(r => r.present && r.editable);
  if (!ready.length) return { ready: false, reports };
  const sticky = ready.find(r => r.frameId === s.lastFrameId);
  const chosen = sticky || ready.find(r => r.frameId === 0) || ready[0];
  return { ready: true, reports, chosen };
}

function matchesUrlFilter(url, c) {
  const f = (c.urlContains || '').trim();
  if (!f) return true;
  const m = f.match(/^\/(.+)\/([a-z]*)$/i);
  if (m) { try { return new RegExp(m[1], m[2]).test(url); } catch (_) { return false; } }
  return url.toLowerCase().includes(f.toLowerCase());
}

async function tabHealth(s, c) {
  let tab;
  try { tab = await api.tabs.get(s.tabId); } catch (_) { return { ready: false, lost: true, reason: 'aba vinculada foi fechada' }; }
  const url = tab.url || '';
  let origin = ''; try { origin = new URL(url).origin; } catch (_) {}
  const internalCrash = /^(chrome-error:\/\/|about:neterror|about:tabcrashed|about:certerror)/i.test(url);
  if (origin !== s.origin && !internalCrash)
    return { ready: false, foreign: true, reason: 'aba navegou para outra origem; nenhuma recarga automática' };
  if (c.urlContains && !matchesUrlFilter(url, c) && !internalCrash)
    return { ready: false, foreign: true, reason: 'URL não satisfaz o filtro configurado' };
  if (tab.status === 'loading' && s.lastNavigationAt && now() - s.lastNavigationAt < 45000)
    return { ready: false, loading: true, reason: 'navegação em andamento' };
  if (tab.discarded) return { ready: false, reason: 'aba descartada pelo navegador' };
  if (internalCrash) return { ready: false, reason: 'página de erro do navegador' };
  const p = probeAndChoose(s, await collectProbe(s.tabId));
  if (!p.ready) {
    const n = p.reports.length;
    return { ready: false, reason: 'campo indisponível (' + (n ? n + ' frame(s) responderam sem campo pronto' : 'nenhum frame respondeu à sonda') + ')' };
  }
  return { ready: true, reason: 'campo operacional no frame #' + p.chosen.frameId, chosen: p.chosen };
}

function sendWithTimeout(tabId, data, ms, frameId) {
  let timer;
  const opts = (frameId !== undefined && frameId !== null) ? { frameId } : undefined;
  return Promise.race([
    opts ? api.tabs.sendMessage(tabId, data, opts) : api.tabs.sendMessage(tabId, data),
    new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('tempo máximo de resposta excedido')), ms); })
  ]).finally(() => { if (timer) clearTimeout(timer); });
}

/* ---------------- estados da sessão ---------------- */

function freshBound(tab) {
  let u;
  try { u = new URL(tab.url); } catch (_) { throw new Error('URL da aba indisponível'); }
  if (!['http:', 'https:'].includes(u.protocol)) throw new Error('Selecione uma aba http/https (páginas internas do navegador não aceitam scripts de conteúdo).');
  return {
    status: 'idle', tabId: tab.id, origin: u.origin, targetUrl: u.href,
    startedAt: null, completedCycles: 0, attemptedCycles: 0, nextDueAt: null,
    pendingCycle: null, activeElapsedMs: 0, activeSince: null,
    failures: 0, reloads: 0, retryAt: null, lastFrameId: null,
    lastReadyAt: null, lastHealthAt: null, lastNavigationAt: null,
    endedAt: null, endReason: null
  };
}

async function pause(s, c, reason, uncertain) {
  setActive(s, false);
  s.status = uncertain ? 'uncertain' : 'paused';
  s.endReason = reason; s.nextDueAt = null; s.endedAt = now();
  await api.storage.local.set({ enabled: false });
  c.enabled = false;
  await save(s); await timers(c, s);
  await log(uncertain ? 'ERROR' : 'WARN', reason);
  await setStatus(reason, false);
  await notify(c, 'Auto Preencher Campo', reason, false);
  return { ok: false, reason };
}

async function failedHealth(s, c, reason) {
  s.lastHealthAt = now(); s.failures += 1;
  await save(s);
  await log('WARN', 'saúde ' + s.failures + '/' + c.recoveryFailures + ': ' + reason);
  if (!c.watchdogEnabled) {
    s.nextDueAt = now() + SH.nextDelayMs(c).milliseconds;
    await save(s); await timers(c, s);
    return { ok: false, reason };
  }
  if (c.maxReloads === 0) return { ok: false, reason };
  if (s.status === 'recovering' && now() < (s.retryAt || 0)) return { ok: false, recovering: true, reason };
  if (s.failures >= c.recoveryFailures || s.status === 'recovering') return reloadSafe(s, c);
  return { ok: false, reason };
}

async function reloadSafe(s, c) {
  if (s.reloads >= c.maxReloads)
    return pause(s, c, 'limite de ' + c.maxReloads + ' recarregamentos atingido; intervenção manual necessária');
  const t = await api.tabs.get(s.tabId).catch(() => null);
  if (!t) return pause(s, c, 'aba vinculada desapareceu');
  let origin = ''; try { origin = new URL(t.url || '').origin; } catch (_) {}
  const recoverable = /^(chrome-error:\/\/|about:neterror|about:tabcrashed)/i.test(t.url || '');
  if (origin !== s.origin && !recoverable) return pause(s, c, 'origem da aba mudou; recarga bloqueada por segurança');
  if ((t.url || '').startsWith('about:certerror')) return pause(s, c, 'erro de certificado exige intervenção manual');
  s.reloads += 1; s.failures = 0; s.status = 'recovering'; setActive(s, false);
  s.retryAt = now() + c.recoveryBackoffSec * 1000 * Math.pow(2, s.reloads - 1);
  await save(s); await timers(c, s);
  await log('WARN', 'RECUPERAÇÃO ' + s.reloads + '/' + c.maxReloads + ': recarregando a aba; nova avaliação em ~' + Math.round((s.retryAt - now()) / 1000) + 's (backoff).');
  try {
    if (recoverable || t.discarded) await api.tabs.update(s.tabId, { url: s.targetUrl });
    else await api.tabs.reload(s.tabId, { bypassCache: true });
  } catch (e) { await log('ERROR', 'falha ao pedir recarga: ' + String(e && e.message || e)); }
  return { ok: false, recovering: true, reason: 'recarga solicitada' };
}

/* ---------------- ciclo ---------------- */

async function runCycle(s, c, source) {
  if (s.status !== 'running' || s.pendingCycle) return { ok: false, reason: 'estado não executável' };
  if (await finishIfDue(s, c)) return { ok: false, reason: 'limite atingido' };
  const h = await tabHealth(s, c);
  if (h.lost || h.foreign) return pause(s, c, h.reason);
  if (!h.ready) {
    if (h.loading) return { ok: false, reason: h.reason };
    return failedHealth(s, c, h.reason);
  }
  s.failures = 0; s.lastHealthAt = now(); s.lastReadyAt = now();
  s.lastFrameId = h.chosen ? h.chosen.frameId : null;
  const cycleId = s.startedAt + '-' + (s.attemptedCycles + 1) + '-' + now();
  s.attemptedCycles += 1;
  // Persiste ANTES de disparar: comando sem resposta nunca é reenviado automaticamente.
  s.pendingCycle = { id: cycleId, startedAt: now(), source, frameId: s.lastFrameId };
  await save(s);
  await log('INFO', 'ciclo ' + s.attemptedCycles + ' iniciado (' + source + ') no frame #' + s.lastFrameId + '; ciclos confirmados: ' + s.completedCycles + '.');
  let r;
  try {
    r = await sendWithTimeout(s.tabId, { type: 'APC_FILL', cycleId },
      Math.max(12000, c.healthTimeoutMs, c.confirmationTimeoutMs + 4000), s.lastFrameId);
  } catch (e) {
    return pause(s, c, 'ENVIO INCERTO: conexão perdida durante o ciclo ' + cycleId + ' (' + String(e && e.message || e) + '). Resolva manualmente ou reinicie a sessão.', true);
  }
  if (!r || typeof r.ok !== 'boolean') return pause(s, c, 'ENVIO INCERTO: resposta inválida do content script.', true);
  if (!r.ok) {
    if (r.maybeDispatched) return pause(s, c, 'ENVIO INCERTO: ' + (r.reason || 'resultado ambíguo após o disparo'), true);
    if (r.terminal) return pause(s, c, r.reason || 'bloqueio do site');
    s.pendingCycle = null;
    await setStatus(r.reason || 'falha anterior ao envio', false);
    await log('WARN', 'ciclo sem disparo: ' + String(r.reason));
    return failedHealth(s, c, r.reason || 'falha anterior ao envio');
  }
  s.pendingCycle = null;
  s.completedCycles += 1;
  s.lastHealthAt = now(); s.lastReadyAt = now(); s.failures = 0;
  const detail = (r.dryRun ? 'SIMULAÇÃO — ' : r.confirmed ? 'CONFIRMADO NA INTERFACE — ' : 'DISPARADO (sem confirmação remota) — ') + r.description;
  await setStatus(detail, true);
  await log('INFO', 'ciclo ' + s.completedCycles + ': ' + detail);
  await save(s);
  if (await finishIfDue(s, c)) return { ok: true, completed: true, detail };
  await scheduleNext(s, c);
  return { ok: true, detail, completedCycles: s.completedCycles };
}

/* ---------------- monitor (vigia + retomada) ---------------- */

async function monitor(source, opts) {
  const runDue = !opts || opts.runDue !== false;
  const c = await config(); const s = await session();
  if (!c.enabled || !s || !(s.status === 'running' || s.status === 'recovering')) return { ok: false, reason: 'sessão não ativa' };
  if (s.pendingCycle) return pause(s, c, 'ENVIO INCERTO: operação pendente recuperada após interrupção; resolva manualmente ou reinicie a sessão.', true);
  if (await finishIfDue(s, c)) return { ok: false, reason: 'limite atingido' };
  const h = await tabHealth(s, c);
  if (h.lost || h.foreign) return pause(s, c, h.reason);
  if (!h.ready) {
    if (h.loading) return { ok: false, reason: h.reason };
    return failedHealth(s, c, h.reason);
  }
  const wasRecovering = s.status === 'recovering';
  s.failures = 0; s.reloads = 0; s.retryAt = null;
  s.lastHealthAt = now(); s.lastReadyAt = now();
  s.lastFrameId = h.chosen ? h.chosen.frameId : null;
  if (wasRecovering) {
    s.status = 'running'; setActive(s, true);
    await log('INFO', 'aba recuperada e campo confirmado no frame #' + s.lastFrameId + ' — automatismo retomado.');
    await notify(c, 'Auto Preencher Campo', 'Aba recuperada com sucesso — automatismo retomado.', true);
  }
  await save(s); await timers(c, s);
  // Retomada com envio efetivo: se o ciclo venceu durante a falha, dispara agora.
  if (runDue && s.nextDueAt !== null && now() >= s.nextDueAt) return runCycle(s, c, source);
  return { ok: true, healthy: true, reason: h.reason };
}

/* ---------------- bootstrap / habilitação / vínculo ---------------- */

async function bootstrap(reason) {
  const stored = await api.storage.local.get(['apcV5Initialized', 'enabled', 'apcSession']);
  if (!stored.apcV5Initialized) {
    const existing = await api.storage.local.get(SH.CONFIG_KEYS);
    const patch = { apcV5Initialized: true, enabled: false, apcSession: null };
    for (const k of SH.CONFIG_KEYS) if (existing[k] === undefined) patch[k] = SH.DEFAULTS[k];
    patch.lastResult = 'Atualização v5.0.0: automação pausada; vincule novamente a aba-alvo no popup.';
    await api.storage.local.set(patch);
    await log('INFO', 'migração para v5.0.0 concluída: automação desativada até vinculação explícita da aba (segurança anti-duplicidade).');
  }
  const c = await config(); const s = await session();
  // Tempo "ativo" não pode assumir que decorreu com o navegador fechado;
  // credita no máximo dois períodos de vigia desde o último coração.
  if (c.enabled && s && s.status === 'running' && s.activeSince) {
    const heartbeat = s.lastHealthAt || s.activeSince;
    const maxGap = Math.max(60000, c.watchdogMinutes * 120000);
    const accruedUntil = Math.min(now(), heartbeat + maxGap);
    s.activeElapsedMs = (s.activeElapsedMs || 0) + Math.max(0, accruedUntil - s.activeSince);
    s.activeSince = now();
    await save(s);
  }
  if (c.enabled && s && s.pendingCycle)
    return pause(s, c, 'ENVIO INCERTO: sessão reaberta com envio pendente; resolva manualmente ou reinicie a sessão.', true);
  await timers(c, s);
  if (c.enabled && s && (s.status === 'running' || s.status === 'recovering')) {
    if (await finishIfDue(s, c)) return;
    // Sem reenvio não solicitado: só executa quando o prazo persistido venceu.
    if (s.nextDueAt !== null && s.nextDueAt <= now()) return monitor('retomada ' + reason);
  }
}

async function setEnabled(enable) {
  const c = await config(); let s = await session();
  if (!enable) {
    await api.storage.local.set({ enabled: false });
    c.enabled = false;
    if (s && (s.status === 'running' || s.status === 'recovering')) {
      setActive(s, false); s.status = 'paused'; s.endReason = 'pausa manual';
      await save(s);
    }
    await timers(c, s); await log('INFO', 'automação pausada.');
    return { ok: true, session: s };
  }
  if (!s || !s.tabId || !s.origin) throw new Error('Vincule uma aba-alvo antes de ativar (botão "Vincular aba atual").');
  if (s.status === 'uncertain') throw new Error('Envio incerto pendente: resolva manualmente ou reinicie a sessão antes de ativar.');
  if (s.status === 'completed') throw new Error('Limite já alcançado: reinicie a sessão para continuar.');
  const t = now();
  if (!s.startedAt) {
    s.startedAt = t; s.completedCycles = 0; s.attemptedCycles = 0;
    s.activeElapsedMs = 0; s.reloads = 0; s.failures = 0;
    s.nextDueAt = c.runOnEnable ? t : t + SH.nextDelayMs(c).milliseconds;
  } else if (s.nextDueAt === null) {
    s.nextDueAt = t + SH.nextDelayMs(c).milliseconds;
  }
  s.status = 'running'; setActive(s, true, t); s.endReason = null; s.endedAt = null;
  await api.storage.local.set({ enabled: true });
  c.enabled = true; await save(s);
  if (await finishIfDue(s, c)) return { ok: false, reason: 'prazo ou ciclos já atingidos' };
  await timers(c, s); await log('INFO', 'sessão habilitada para a aba #' + s.tabId + ' (' + s.origin + ').');
  if (s.nextDueAt <= now()) return monitor('ativação');
  return { ok: true, session: s };
}

async function bindCurrent() {
  const c = await config();
  if (c.enabled) throw new Error('Pause a automação antes de vincular outra aba.');
  const ts = await api.tabs.query({ active: true, currentWindow: true });
  if (!ts.length) throw new Error('Nenhuma aba ativa localizada.');
  const s = freshBound(ts[0]);
  if (c.urlContains && !matchesUrlFilter(s.targetUrl, c))
    throw new Error('A aba não satisfaz o filtro "URL deve conter".');
  await save(s); await timers(c, s);
  await log('INFO', 'aba vinculada #' + s.tabId + '; origem ' + s.origin + '.');
  return { ok: true, tabId: s.tabId, origin: s.origin };
}

async function resetSession() {
  const c = await config();
  if (c.enabled) throw new Error('Pause antes de reiniciar a sessão.');
  const old = await session();
  if (!old || !old.tabId) throw new Error('Não há aba vinculada.');
  const tab = await api.tabs.get(old.tabId);
  const fresh = freshBound(tab);
  if (fresh.origin !== old.origin) throw new Error('Origem modificada; vincule a aba novamente.');
  await save(fresh); await timers(c, fresh);
  await log('INFO', 'sessão explicitamente reiniciada (contadores zerados).');
  return { ok: true };
}

/* ---------------- configurações ---------------- */

async function saveSettings(request) {
  const previous = await config();
  const incoming = Object.assign({}, previous, request || {});
  const checked = SH.normalize(incoming);
  if (checked.errors.length) throw new Error(checked.errors.join('; '));
  const c = checked.config;
  const wantEnable = c.enabled;
  if (wantEnable && !previous.enabled && !((await session()) || {}).tabId)
    throw new Error('Antes de ativar, use "Vincular aba atual" no popup.');
  await api.storage.local.set(Object.assign({}, c, { enabled: previous.enabled }));
  if (wantEnable !== previous.enabled) return setEnabled(wantEnable);
  const s = await session();
  if (s && c.enabled && await finishIfDue(s, c)) return { ok: true, reason: 'limite atingido pela nova configuração' };
  await timers(c, s);
  await log('INFO', 'configurações validadas e salvas.');
  return { ok: true };
}

/* ---------------- perfis por origem ---------------- */

async function listProfiles() {
  const { apcProfiles } = await api.storage.local.get('apcProfiles');
  return Object.keys(apcProfiles || {}).sort();
}
async function saveProfile() {
  const s = await session();
  if (!s || !s.origin) throw new Error('Vincule a aba antes de salvar um perfil.');
  const c = await config();
  const { apcProfiles: existing } = await api.storage.local.get('apcProfiles');
  const profiles = (existing && typeof existing === 'object' && !Array.isArray(existing)) ? existing : {};
  if (!profiles[s.origin] && Object.keys(profiles).length >= 30) throw new Error('Limite de 30 perfis atingido.');
  const settings = {}; for (const k of SH.CONFIG_KEYS) settings[k] = c[k];
  profiles[s.origin] = { settings, savedAt: now() };
  await api.storage.local.set({ apcProfiles: profiles });
  await log('INFO', 'perfil salvo para ' + s.origin + '.');
  return { ok: true, origin: s.origin };
}
async function loadProfile(origin) {
  const c = await config(); const s = await session();
  if (c.enabled) throw new Error('Pause antes de carregar um perfil.');
  if (!s || s.origin !== origin) throw new Error('Vincule primeiro uma aba da origem do perfil.');
  const { apcProfiles } = await api.storage.local.get('apcProfiles');
  if (!apcProfiles || !apcProfiles[origin]) throw new Error('Perfil não encontrado.');
  const checked = SH.normalize(Object.assign({}, SH.DEFAULTS, apcProfiles[origin].settings, { enabled: false }));
  if (checked.errors.length) throw new Error('Perfil inválido: ' + checked.errors.join('; '));
  await api.storage.local.set(checked.config);
  await timers(checked.config, s);
  await log('INFO', 'perfil carregado para ' + origin + '.');
  return { ok: true };
}
async function deleteProfile(origin) {
  const c = await config();
  if (c.enabled) throw new Error('Pause antes de excluir um perfil.');
  const { apcProfiles: existing } = await api.storage.local.get('apcProfiles');
  const profiles = (existing && typeof existing === 'object') ? existing : {};
  if (!Object.prototype.hasOwnProperty.call(profiles, origin)) throw new Error('Perfil não encontrado.');
  delete profiles[origin];
  await api.storage.local.set({ apcProfiles: profiles });
  await log('INFO', 'perfil excluído: ' + origin + '.');
  return { ok: true };
}

/* ---------------- seletor na página (picker) e diagnóstico ---------------- */

async function pickStart(phase) {
  const ts = await api.tabs.query({ active: true, currentWindow: true });
  if (!ts.length) throw new Error('Nenhuma aba ativa localizada.');
  let proto = ''; try { proto = new URL(ts[0].url || '').protocol; } catch (_) {}
  if (!['http:', 'https:'].includes(proto))
    throw new Error('Abra uma página http(s) para selecionar o elemento (páginas internas não aceitam scripts de conteúdo).');
  try { await api.tabs.sendMessage(ts[0].id, { type: 'APC_PICK_START', phase }); } catch (_) {}
  const dica = phase === 'button'
    ? 'clique no BOTÃO de envio (Esc pula esta fase)'
    : 'clique no CAMPO a preencher (Esc cancela)';
  await log('INFO', 'Seletor na página armado (fase: ' + phase + ') na aba #' + ts[0].id + ' — ' + dica + '.');
  return { ok: true, tabId: ts[0].id };
}

async function pickCancel() {
  const ts = await api.tabs.query({ active: true, currentWindow: true });
  if (ts.length) { try { await api.tabs.sendMessage(ts[0].id, { type: 'APC_PICK_CANCEL' }); } catch (_) {} }
  await log('INFO', 'Seletor na página cancelado.');
  return { ok: true };
}

async function pickResult(m, sender) {
  const patch = {};
  if (m.phase === 'field') {
    if (m.selector) patch.selector = String(m.selector).slice(0, 10000);
    if (Array.isArray(m.fallbacks) && m.fallbacks.length)
      patch.fallbacks = m.fallbacks.slice(0, 6).map(x => String(x).slice(0, 1000)).join('\n');
    patch.selectorType = 'css';
  } else if (m.phase === 'button') {
    patch.buttonSelector = String(m.buttonSelector || '').slice(0, 5000);
  } else return { ok: false, reason: 'fase desconhecida' };
  const cur = await api.storage.local.get(SH.CONFIG_KEYS);
  const checked = SH.normalize(Object.assign({}, SH.DEFAULTS, cur, patch), { strict: false });
  await api.storage.local.set(patch);
  await log('INFO', 'PICK ' + (m.phase === 'field' ? 'do CAMPO' : 'do BOTÃO') + ' aplicado automaticamente a partir do frame #' +
    ((sender && sender.frameId !== undefined) ? sender.frameId : 0) + ' (' + String(m.frameUrl || '').slice(0, 140) + ').' +
    (m.phase === 'field' ? ' Primário: ' + String(m.selector || '').slice(0, 120) : ''));
  await notify(checked.config, 'Auto Preencher Campo',
    m.phase === 'field' ? 'Campo selecionado e configurado automaticamente.' : 'Botão de envio selecionado e configurado.',
    true);
  return { ok: true };
}

async function diagnose() {
  const s = await session();
  let tabId = s ? s.tabId : null;
  if (tabId === null) {
    const ts = await api.tabs.query({ active: true, currentWindow: true });
    tabId = ts.length ? ts[0].id : null;
  }
  if (tabId === null) throw new Error('Nenhuma aba disponível para diagnóstico.');
  const reports = await collectProbe(tabId, 1800);
  let top = null;
  try { top = await sendWithTimeout(tabId, { type: 'APC_RUN_DIAGNOSE' }, 5000); } catch (_) {}
  const lines = [];
  lines.push('frames que responderam à sonda: ' + reports.length + '.');
  for (const r of reports) {
    lines.push('frame #' + r.frameId + ' ' + String(r.frameUrl || '').slice(0, 100) + ' → ' +
      (r.present ? ('ENCONTRADO via [' + r.used + ']' + (r.shadowDepth ? ' | shadow=' + r.shadowDepth + ' níveis' : '') + (r.editable ? ' (editável)' : ' (NÃO editável)')) : 'campo não encontrado neste frame'));
  }
  if (!reports.length) lines.push('nenhum frame respondeu (crash, página interna do navegador ou script bloqueado).');
  if (top && top.ok) {
    lines.push('frame principal: hosts de shadow aberto=' + top.shadowOpen + ', fechado=' + top.shadowClosed +
      (top.closedNote ? ' (' + top.closedNote + ')' : '') + ', iframes=' + top.iframeCount + '.');
  }
  for (const l of lines) await log('INFO', '[diagnóstico] ' + l);
  return { ok: true, reports, top, lines };
}

/* ---------------- roteamento de mensagens ---------------- */

async function handleMessage(m, sender) {
  if (m.type === 'APC_PROBE_REPORT') return { ok: true }; // coletado pelo listener dinâmico da sonda
  if (m.type === 'APC_PAGE_HEALTH') {
    const s = await session(); const c = await config();
    if (!c.enabled || !s || !sender.tab || sender.tab.id !== s.tabId) return { ok: false };
    if (s.status === 'running' || s.status === 'recovering')
      return monitor('observação DOM', { runDue: false });
    return { ok: true };
  }
  if (m.type === 'APC_PICK_RESULT') return pickResult(m, sender);
  if (m.type === 'APC_RUN_NOW') {
    const c = await config(); const s = await session();
    if (sender.tab) { // gatilho runOnLoad: apenas do frame principal da aba vinculada
      if (!c.runOnLoad || !c.enabled || !s || sender.tab.id !== s.tabId || sender.frameId !== 0) return { ok: false };
      if (s.status !== 'running' || s.pendingCycle) return { ok: false };
      return runCycle(s, c, 'runOnLoad (página)');
    }
    if (!c.enabled || !s || s.status !== 'running')
      throw new Error('Vincule a aba e ative a sessão antes do envio manual.');
    return runCycle(s, c, 'manual');
  }
  if (sender.tab) throw new Error('Operação de controle não autorizada a partir de página.');
  switch (m.type) {
    case 'APC_GET_STATUS': return { ok: true, settings: await config(), session: await session(), version: VERSION };
    case 'APC_SAVE_SETTINGS': return saveSettings(m.settings);
    case 'APC_SET_ENABLED': return setEnabled(!!m.enabled);
    case 'APC_BIND_TARGET': return bindCurrent();
    case 'APC_RESET_SESSION': return resetSession();
    case 'APC_CHECK_NOW': return monitor('verificação manual', { runDue: false });
    case 'APC_LIST_PROFILES': return { ok: true, origins: await listProfiles() };
    case 'APC_SAVE_PROFILE': return saveProfile();
    case 'APC_LOAD_PROFILE': return loadProfile(m.origin);
    case 'APC_DELETE_PROFILE': return deleteProfile(m.origin);
    case 'APC_PICK_START': return pickStart(m.phase === 'button' ? 'button' : 'field');
    case 'APC_PICK_CANCEL': return pickCancel();
    case 'APC_DIAGNOSE': return diagnose();
    default: return { ok: false, reason: 'mensagem desconhecida' };
  }
}

/* ---------------- listeners registrados sincronamente (regra MV3) ---------------- */

api.runtime.onInstalled.addListener(() => { void queue(() => bootstrap('instalação')).catch(e => log('ERROR', String(e && e.message || e))); });
api.runtime.onStartup.addListener(() => { void queue(() => bootstrap('inicialização')).catch(e => log('ERROR', String(e && e.message || e))); });

api.alarms.onAlarm.addListener((a) => {
  if (![CYCLE_ALARM, WATCH_ALARM, LIMIT_ALARM].includes(a.name)) return;
  void queue(() => monitor('alarme ' + a.name)).catch(e => log('ERROR', String(e && e.message || e)));
});

api.tabs.onUpdated.addListener((id, changed) => {
  if (changed.status !== 'complete' && changed.status !== 'loading') return;
  void queue(async () => {
    const s = await session();
    if (!s || s.tabId !== id) return;
    if (changed.status === 'loading') { s.lastNavigationAt = now(); await save(s); return; }
    const c = await config();
    if (!c.enabled) return;
    if (s.status === 'running' || s.status === 'recovering')
      await monitor('página carregada', { runDue: false });
  }).catch(() => {});
});

api.tabs.onRemoved.addListener((tabId) => {
  void queue(async () => {
    const c = await config(); const s = await session();
    if (!c.enabled || !s || s.tabId !== tabId) return;
    await pause(s, c, 'aba vinculada foi fechada; automação interrompida.');
  }).catch(() => {});
});

api.runtime.onMessage.addListener((m, sender, sendResponse) => {
  if (!m || typeof m.type !== 'string' || !m.type.startsWith('APC_')) return false;
  queue(() => handleMessage(m, sender)).then(sendResponse, e => sendResponse({ ok: false, reason: String(e && e.message || e) }));
  return true; // resposta assíncrona compatível com Firefox e Chromium
});

/* Reconcilia alarmes/estado após o despertar do worker/event page. */
void queue(() => bootstrap('carregamento do supervisor')).catch(e => log('ERROR', String(e && e.message || e)));
