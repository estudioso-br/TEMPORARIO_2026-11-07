# Auto Preencher Campo Temporizado — v5.0.0

**Pacote universal: um único diretório (um único `manifest.json`) para Firefox, Chrome, Edge, Brave e Opera** — sem qualquer alteração entre navegadores.

## 1. Por que é verdadeiramente universal

O manifesto declara simultaneamente as duas formas de script de segundo plano do Manifest V3,
mecanismo oficialmente documentado pela MDN ("Cross-browser Manifest V3 background scripts"):

| Navegador | Chave usada | Requisito |
|---|---|---|
| Firefox | `background.scripts` (event page) | Firefox ≥ 121 (bug 1860304 corrigido/verificado no branch 121) |
| Chrome | `background.service_worker` | Chrome ≥ 121 (antes da 121, `background.scripts` em MV3 gerava **erro**; da 121 em diante, apenas aviso — Chrome for Developers) |
| Edge, Brave, Opera, Vivaldi (Chromium ≥ 121) | `background.service_worker` | igual ao Chrome |
| Safari (conversão via Xcode) | `background.scripts` por padrão | fora de escopo deste pacote; o mecanismo MDN prevê `preferred_environment` |

- `browser_specific_settings.gecko` (id, `strict_min_version: 121.0`, `data_collection_permissions.required: ["none"]`) é **ignorado pelo Chromium**. A declaração de dados é obrigatória na AMO para novas extensões desde 03/11/2025 — esta extensão **não coleta nem transmite dados** (tudo fica em `storage.local`).
- `minimum_chrome_version: "121"` impede instalação em Chromium antigo; o Firefox ignora a chave.
- Nota para a **Chrome Web Store**: o carregamento local funciona com as duas chaves, mas há registros de revisões da loja que recusaram pacotes contendo `background.scripts` em MV3. Se você publicar na CWS e receber recusa, remova a chave `scripts` do objeto `background` apenas na versão enviada à loja (a MDN confirma que o Chromium usa `service_worker`). Para uso local/empresarial e para a AMO, as duas chaves podem permanecer.

## 2. Instalação (o mesmo diretório em todos)

- **Firefox**: `about:debugging` → Este Firefox → "Carregar extensão temporária…" → selecione `manifest.json`. Permanente: assinar em addons.mozilla.org (`web-ext sign`) ou usar Developer Edition/Nightly com `xpinstall.signatures.required=false`.
- **Chrome**: `chrome://extensions` → Modo do desenvolvedor → "Carregar sem compactação" → a pasta.
- **Edge / Brave / Opera**: `edge://extensions` · `brave://extensions` · `opera://extensions` — mesmo procedimento do Chrome (avisos de chaves não reconhecidas são inofensivos).

**Migração v3→v5**: por segurança anti-duplicidade, a automação vem desativada após a atualização — vincule novamente a aba alvo no popup ("① Vincular aba atual").

## 3. Fluxo de uso (popup)

1. Abra a página alvo → popup → **① Vincular aba atual** (fixa aba + origem da sessão).
2. **② Selecionar campo na página** (opcional): a extensão arma um seletor visual; clique no campo e ela gera sozinha o seletor primário (com `>>>` se houver Shadow DOM) e as reservas. Na sequência, clique no **botão de envio** (ou Esc para pular) para preencher o `buttonSelector`.
3. **Ativar** o interruptor → com `runOnEnable` o primeiro ciclo dispara imediatamente e os seguintes seguem o intervalo com jitter.
4. Acompanhe no popup: fase da sessão, ciclos (x/limite), tempo restante, último frame confirmado e log.

## 4. Localização do elemento (motor v5)

| Tipo | Comportamento |
|---|---|
| `css` | CSS simples **com piercing automático** de Shadow DOM aberto (busca recursiva em todos os shadow roots). Suporta o combinador explícito `>>>` (estilo Selenium): `meu-app >>> .composer >>> textarea`. No **Firefox**, tenta também shadow roots **fechados** via `wrappedJSObject` (Xray). |
| `caminho-css` | Caminho copiado do DevTools, com **sanitização** de partes inválidas (classes Tailwind etc.) e fallback para a cauda do caminho. |
| `xpath` | XPath completo; além disso, XPath simples (`[@a="v"]`, `contains(@a,"v")`, `starts-with(@a,"v")`) é **convertido automaticamente para CSS** e testado como reserva extra `auto(xpath→css)`. |
| `outerhtml` | Casamento exato por `outerHTML` percorrendo a árvore. |

Reservas tipadas: um por linha no formato `tipo|valor` (`css`, `caminho-css`, `xpath-curto`, `xpath-longo`, `outerhtml`); linhas sem prefixo são CSS. O log registra qual localizador funcionou, a profundidade de shadow e o frame.

## 5. Frames e matriz de resiliência

O `content.js` é injetado em **todos os frames** (`all_frames: true`), inclusive iframes **cross-origin** (a injeção de content script não é bloqueada pela origem do frame nem pelo CSP da página). O supervisor difunde uma **sonda** (APC_PROBE) a todos os frames da aba vinculada; cada frame responde se o campo está presente/editável; o supervisor escolhe o frame (prefere o que funcionou no ciclo anterior, depois o frame principal), roteia o preenchimento por `frameId` e registra no log o frame e o caminho do elemento.

Coberto: campo no frame principal ✔ · campo em iframe (mesma origem) ✔ · campo em iframe cross-origin ✔ · campo em shadow DOM aberto (qualquer frame) ✔ · shadow fechado no Firefox ✔ · recuperação pós-crash/reload ✔.

## 6. Vigia da aba (watchdog) — crash/erro → recarregar → retomar

Periodicamente (padrão 1 min) o supervisor sonda a aba vinculada. Falhas consecutivas (padrão 2) disparam a recuperação: **recarregar a aba** (ou navegar de volta à URL alvo em páginas de erro/aba descartada) → aguardar carregamento → **sondar de novo até o campo estar presente e editável em qualquer frame** → retomar a sessão e **executar o ciclo pendente imediatamente** (efetivo envio e reinício do ciclo). Proteções: backoff exponencial entre recargas, limite de recarregamentos (padrão 3), bloqueio de recarga se a aba navegou para outra origem ou tem erro de certificado (exige intervenção manual), badge `FIX` durante a recuperação e notificação ao concluir.

## 7. Limites do automatismo

- **Ciclos**: parar após NN ciclos confirmados.
- **Duração**: parar após NN horas/minutos/segundos — contados **de relógio** (tempo total decorrido) ou **de tempo ativo** (desconta pausas/recuperações). O primeiro limite atingido encerra (badge `FIN` + notificação). Reativar zera os contadores.

## 8. Anti-duplicidade e confirmação de envio

Cada ciclo recebe um `cycleId` e é **persistido antes do disparo**; se a conexão cair no meio, a sessão entra em **ENVIO INCERTO** (badge `?`) e exige decisão manual — nunca reenvia por conta própria. Modos de confirmação: `disparo` (padrão), `campo esvaziou` (a página apagou o compositor — típico de chat) e `seletor apareceu`. Falha de confirmação ambígua também pausa em vez de duplicar. Há ainda `dryRun` (simulação: verifica localização/disponibilidade sem preencher nem enviar).

## 9. Perfis por site, padrões e log

Configuração completa por **origem** (perfis salvar/carregar/excluir), padrão personalizado + de fábrica, exportar/importar JSON, log contínuo de 500 eventos com diagnóstico de página (frames respondentes, hosts de shadow aberto/fechado, iframes).

## 10. CASOS IMPOSSÍVEIS (limites de projeto — leia antes de reportar falha)

1. **Shadow DOM fechado no Chromium (Chrome/Edge/Brave/Opera)**: impossível por design. O modo isolado do content script enxerga o DOM, mas `element.shadowRoot` retorna `null` para raízes fechadas e as propriedades JS da página não são visíveis entre mundos. Firefox: **resolvido** via Xray (`wrappedJSObject`). Alternativa teórica no Chromium seria a API `chrome.debugger` (anexa o DevTools à aba e exibe o banner "iniciou a depuração") — deliberadamente **não implementada** por custo de permissão/UX.
2. **`isTrusted`**: eventos sintéticos (Enter/botão despachados via JS) têm `isTrusted: false`; páginas que validam eventos confiáveis (anti-bot) podem recusar. Não há como gerar evento confiável sem entrada real do usuário. Mitigação: use a confirmação (`campo esvaziou` / `seletor`) para não fingir sucesso — resultado ambíguo pausa a sessão.
3. **Canvas**: campo desenhado em `<canvas>` (WebGL puro) não existe como elemento do DOM — nenhum seletor o encontra. Exceção: o canvas pode estar dentro de um wrapper editável; nesse caso aponte o wrapper com o picker.
4. **Páginas internas do navegador** (`about:`, `chrome://`, `edge://`, lojas): não aceitam scripts de conteúdo; o vigia registrará falha de sonda. Recarga automática dessas URLs é bloqueada de propósito.
5. **Crash de renderer**: após um crash real, o content script morre junto; a detecção é pela sonda (sem resposta) e a recuperação é feita pelo background recarregando a aba — o intervalo mínimo de percepção é o do vigia (alarmes do navegador têm granularidade de ~30 s).
6. **Seletor correto, elemento indisponível**: campo `disabled`/`readonly`/`aria-disabled` ou invisível (zero retângulos/`display:none`) é tratado como bloqueio do site: o ciclo não dispara e a sessão pausa com motivo explícito.

## 11. Checklist de aceitação recomendado

1. Carregar a pasta nos dois navegadores; conferir ausência de erros no service worker/event page.
2. Vincular aba; rodar com `dryRun` ligado (nada deve ser enviado).
3. Desligar `dryRun`, testar um ciclo manual ("Preencher e enviar AGORA").
4. Testar limites: 2 ciclos; duração de 1 minuto; limites combinados.
5. Simular quebra: fechar o campo (F12 → `el.remove()`), recarregar a aba manualmente, deixar a aba descartar.
6. Conferir no log: sonda por frames, frame escolhido, profundidade de shadow, recuperações e limites.

## 12. Limitações operacionais conhecidas

- Granularidade mínima de alarmes: ~30 s (timer e vigia).
- O intervalo entre ciclo/sonda sofre atrasos naturais de alarme; precisão de segundos não é garantida.
- O tempo "ativo" é aproximado após reinício do navegador (credita no máximo dois períodos de vigia).
- Alarmes não sobrevivem ao reinício do navegador no Firefox; o supervisor recria os agendamentos no boot a partir do estado persistido.
