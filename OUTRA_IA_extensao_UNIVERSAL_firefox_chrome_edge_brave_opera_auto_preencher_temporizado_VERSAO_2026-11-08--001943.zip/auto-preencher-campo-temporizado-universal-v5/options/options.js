const api = (typeof browser !== 'undefined' && browser && browser.runtime) ? browser : chrome;
const SH = globalThis.APC_SHARED;

const msgEl = document.getElementById('msg');
function flash(t, ok = true) {
  msgEl.textContent = t;
  msgEl.style.color = ok ? '#1a7f37' : '#b00020';
  setTimeout(() => (msgEl.textContent = ''), 6000);
}

async function send(msg) {
  try { return await api.runtime.sendMessage(msg); }
  catch (e) { return { ok: false, reason: String(e && e.message || e) }; }
}

async function load() {
  const r = await send({ type: 'APC_GET_STATUS' });
  const s = (r && r.settings) || SH.DEFAULTS;
  for (const k of SH.CONFIG_KEYS) {
    const el = document.getElementById(k);
    if (!el) continue;
    const v = (s[k] !== undefined && s[k] !== null) ? s[k] : SH.DEFAULTS[k];
    if (el.type === 'checkbox') el.checked = !!v;
    else el.value = v;
  }
  await refreshLog();
  await refreshProfiles();
}

function collect() {
  const patch = {};
  for (const k of SH.CONFIG_KEYS) {
    const el = document.getElementById(k);
    if (!el) continue;
    if (el.type === 'checkbox') patch[k] = el.checked;
    else if (el.type === 'number') patch[k] = Number(el.value) || 0;
    else patch[k] = el.value;
  }
  return patch;
}

document.getElementById('save').addEventListener('click', async () => {
  const r = await send({ type: 'APC_SAVE_SETTINGS', settings: collect() });
  flash(r && r.ok ? 'Configurações salvas ✔ (validadas)' : 'Erro: ' + (r && r.reason), r && r.ok);
});

/* --- vínculo, saúde, diagnóstico, picker --- */

document.getElementById('bindTab').addEventListener('click', async () => {
  const r = await send({ type: 'APC_BIND_TARGET' });
  flash(r && r.ok ? 'Aba #' + r.tabId + ' vinculada (' + r.origin + ')' : 'Erro: ' + (r && r.reason), r && r.ok);
});

document.getElementById('checkNow').addEventListener('click', async () => {
  const r = await send({ type: 'APC_CHECK_NOW' });
  flash(r && r.healthy ? 'Saúde OK: ' + r.reason : 'Sem saúde agora: ' + ((r && r.reason) || '?'), r && r.healthy);
  await refreshLog();
});

document.getElementById('diagnose').addEventListener('click', async () => {
  flash('Diagnosticando…');
  const r = await send({ type: 'APC_DIAGNOSE' });
  if (r && r.ok) {
    const view = document.getElementById('logView');
    view.value = (view.value ? view.value + '\n' : '') + r.lines.join('\n');
    flash('Diagnóstico concluído — veja as linhas [diagnóstico] no log.');
  } else flash('Erro no diagnóstico: ' + (r && r.reason), false);
});

document.getElementById('pickField').addEventListener('click', async () => {
  const r = await send({ type: 'APC_PICK_START', phase: 'field' });
  flash(r && r.ok ? 'Seletor armado: clique no campo na página (Esc cancela). Ao terminar, recarregue esta página.' : 'Erro: ' + (r && r.reason), r && r.ok);
});

document.getElementById('pickButton').addEventListener('click', async () => {
  const r = await send({ type: 'APC_PICK_START', phase: 'button' });
  flash(r && r.ok ? 'Seletor armado: clique no botão de envio na página (Esc pula). Ao terminar, recarregue esta página.' : 'Erro: ' + (r && r.reason), r && r.ok);
});

/* --- perfis --- */

async function refreshProfiles() {
  const r = await send({ type: 'APC_LIST_PROFILES' });
  const sel = document.getElementById('profileList');
  sel.innerHTML = '';
  for (const o of (r && r.origins) || []) {
    const opt = document.createElement('option');
    opt.value = o; opt.textContent = o;
    sel.appendChild(opt);
  }
}
document.getElementById('saveProfile').addEventListener('click', async () => {
  const r = await send({ type: 'APC_SAVE_PROFILE' });
  flash(r && r.ok ? 'Perfil salvo para ' + r.origin : 'Erro: ' + (r && r.reason), r && r.ok);
  await refreshProfiles();
});
document.getElementById('loadProfile').addEventListener('click', async () => {
  const origin = document.getElementById('profileList').value;
  if (!origin) { flash('Nenhum perfil selecionado.', false); return; }
  const r = await send({ type: 'APC_LOAD_PROFILE', origin });
  if (r && r.ok) { await load(); flash('Perfil carregado: ' + origin); }
  else flash('Erro: ' + (r && r.reason), false);
});
document.getElementById('deleteProfile').addEventListener('click', async () => {
  const origin = document.getElementById('profileList').value;
  if (!origin) { flash('Nenhum perfil selecionado.', false); return; }
  const r = await send({ type: 'APC_DELETE_PROFILE', origin });
  flash(r && r.ok ? 'Perfil excluído.' : 'Erro: ' + (r && r.reason), r && r.ok);
  await refreshProfiles();
});

/* --- padrões --- */

document.getElementById('saveAsDefault').addEventListener('click', async () => {
  await api.storage.local.set({ customDefaults: collect() });
  flash('Padrão personalizado registrado ✔');
});
document.getElementById('restoreCustom').addEventListener('click', async () => {
  const { customDefaults } = await api.storage.local.get('customDefaults');
  if (!customDefaults) { flash('Nenhum padrão personalizado salvo.', false); return; }
  const r = await send({ type: 'APC_SAVE_SETTINGS', settings: customDefaults });
  if (r && r.ok) { await load(); flash('Padrão personalizado restaurado ✔'); }
  else flash('Erro: ' + (r && r.reason), false);
});
document.getElementById('restoreFactory').addEventListener('click', async () => {
  const r = await send({ type: 'APC_SAVE_SETTINGS', settings: Object.assign({}, SH.DEFAULTS, { enabled: false }) });
  if (r && r.ok) { await load(); flash('Padrão de fábrica restaurado ✔'); }
  else flash('Erro: ' + (r && r.reason), false);
});

/* --- exportar / importar --- */

document.getElementById('exportCfg').addEventListener('click', async () => {
  const blob = new Blob([JSON.stringify(collect(), null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'auto_preencher_configuracoes.json';
  a.click();
  URL.revokeObjectURL(a.href);
});
document.getElementById('importCfgBtn').addEventListener('click', () => {
  document.getElementById('importCfgFile').click();
});
document.getElementById('importCfgFile').addEventListener('change', async (ev) => {
  const f = ev.target.files[0];
  if (!f) return;
  try {
    const data = JSON.parse(await f.text());
    const r = await send({ type: 'APC_SAVE_SETTINGS', settings: data });
    if (r && r.ok) { await load(); flash('Configurações importadas e validadas ✔'); }
    else flash('Configuração inválida: ' + (r && r.reason), false);
  } catch (e) {
    flash('Arquivo inválido: ' + e.message, false);
  }
  ev.target.value = '';
});

/* --- log --- */

function fmtLog(e) {
  const d = new Date(e.t);
  const stamp = d.toLocaleString('pt-BR') + '.' + String(d.getMilliseconds()).padStart(3, '0');
  return stamp + ' [' + String(e.l).padEnd(5) + '] (' + e.s + ') ' + e.m;
}
async function refreshLog() {
  const { log = [] } = await api.storage.local.get('log');
  const view = document.getElementById('logView');
  const wasAtBottom = view.scrollTop + view.clientHeight >= view.scrollHeight - 30;
  view.value = log.map(fmtLog).join('\n');
  if (wasAtBottom) view.scrollTop = view.scrollHeight;
}
document.getElementById('refreshLog').addEventListener('click', refreshLog);
document.getElementById('clearLog').addEventListener('click', async () => {
  await api.storage.local.set({ log: [] });
  await refreshLog();
  flash('Log limpo ✔');
});
document.getElementById('exportLog').addEventListener('click', async () => {
  const txt = document.getElementById('logView').value || '(log vazio)';
  const blob = new Blob([txt], { type: 'text/plain' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'auto_preencher_log_debug.txt';
  a.click();
  URL.revokeObjectURL(a.href);
});
setInterval(async () => {
  if (document.getElementById('autoRefresh').checked) await refreshLog();
}, 2000);

load();
