const api = (typeof browser !== 'undefined' && browser && browser.runtime) ? browser : chrome;
const enabledEl = document.getElementById('enabled');
const statusEl = document.getElementById('status');
const cdEl = document.getElementById('countdown');
const sessEl = document.getElementById('session');
const logEl = document.getElementById('logPreview');
let state = { settings: null, session: null };

function fmtTs(ms) { return ms ? new Date(ms).toLocaleTimeString('pt-BR') : 'nunca'; }
function fmtDur(ms) {
  if (!Number.isFinite(ms)) return '∞';
  let s = Math.max(0, Math.round(ms / 1000));
  const h = Math.floor(s / 3600); s -= h * 3600;
  const m = Math.floor(s / 60); s -= m * 60;
  return (h ? h + 'h ' : '') + String(m).padStart(2, '0') + 'm ' + String(s).padStart(2, '0') + 's';
}
function fmtRemaining(nextRun) {
  if (!nextRun) return null;
  return fmtDur(nextRun - Date.now());
}

const PHASES = {
  idle: 'Sem sessão — clique em “Vincular aba atual”.',
  paused: 'Pausada.',
  running: 'Em execução.',
  recovering: 'RECUPERANDO a aba (recarregar → verificar campo → retomar).',
  uncertain: 'ENVIO INCERTO — o resultado do último ciclo é desconhecido; resolva manualmente ou reinicie a sessão.',
  completed: 'Encerrada por limite.'
};

function renderSession() {
  const s = state.session, c = state.settings || {};
  if (!s) { sessEl.textContent = 'Sessão: (não vinculada)'; return; }
  let txt = 'Sessão: aba #' + s.tabId + ' · ' + (s.origin || '') + '\n';
  txt += 'Fase: ' + (PHASES[s.status] || s.status) + '\n';
  txt += 'Ciclos: ' + s.completedCycles + (c.maxCyclesEnabled ? ' / ' + c.maxCycles : '') + ' (tentados ' + s.attemptedCycles + ')\n';
  if (c.durationEnabled && s.startedAt) {
    let left;
    if (c.durationMode === 'active') {
      const used = (s.activeElapsedMs || 0) + (s.activeSince ? Math.max(0, Date.now() - s.activeSince) : 0);
      left = (c.durationHours * 3600 + c.durationMinutes * 60 + c.durationSeconds) * 1000 - used;
    } else {
      left = (c.durationHours * 3600 + c.durationMinutes * 60 + c.durationSeconds) * 1000 - (Date.now() - s.startedAt);
    }
    txt += 'Duração restante: ' + fmtDur(left) + (c.durationMode === 'active' ? ' (ativo)' : '') + '\n';
  }
  if (s.lastReadyAt) txt += 'Campo confirmado há ' + fmtDur(Date.now() - s.lastReadyAt) + ' (frame #' + (s.lastFrameId !== null && s.lastFrameId !== undefined ? s.lastFrameId : '?') + ')\n';
  if (s.pendingCycle) txt += '⚠ ciclo pendente sem resposta (' + s.pendingCycle.source + ')\n';
  if (s.endReason) txt += 'Motivo do fim: ' + s.endReason + '\n';
  sessEl.textContent = txt;
}

async function refresh() {
  try {
    state = await api.runtime.sendMessage({ type: 'APC_GET_STATUS' });
  } catch (e) { state = { settings: null, session: null }; }
  const c = state.settings || {};
  enabledEl.checked = !!c.enabled;
  statusEl.textContent = 'Última execução: ' + fmtTs(c.lastRun) + '\n' + (c.lastResult || '—');
  const { log } = await api.storage.local.get('log');
  const rows = Array.isArray(log) ? log.slice(-4) : [];
  logEl.textContent = rows.map((e) => new Date(e.t).toLocaleTimeString('pt-BR') + ' [' + e.l + '] ' + e.m).join('\n') || '(log vazio)';
  renderSession();
}

setInterval(() => {
  const c = state.settings || {};
  if (!c.enabled) { cdEl.textContent = 'Temporizador desativado.'; return; }
  const r = fmtRemaining(c.nextRun);
  cdEl.textContent = r !== null ? 'Próxima execução em ' + r : '';
}, 1000);

enabledEl.addEventListener('change', async () => {
  try { await api.runtime.sendMessage({ type: 'APC_SET_ENABLED', enabled: enabledEl.checked }); }
  catch (e) { statusEl.textContent = 'Erro: ' + (e && e.message); }
  await refresh();
});

document.getElementById('bindTab').addEventListener('click', async () => {
  try {
    const r = await api.runtime.sendMessage({ type: 'APC_BIND_TARGET' });
    statusEl.textContent = r.ok ? ('Aba #' + r.tabId + ' vinculada ✔') : ('Falha: ' + r.reason);
  } catch (e) { statusEl.textContent = 'Erro: ' + (e && e.message); }
  await refresh();
});

document.getElementById('pickField').addEventListener('click', async () => {
  try {
    const r = await api.runtime.sendMessage({ type: 'APC_PICK_START', phase: 'field' });
    statusEl.textContent = r.ok ? 'Seletor armado: clique no campo na página (Esc cancela).' : ('Falha: ' + r.reason);
    window.close();
  } catch (e) { statusEl.textContent = 'Erro: ' + (e && e.message); }
});

document.getElementById('pickButton').addEventListener('click', async () => {
  try {
    const r = await api.runtime.sendMessage({ type: 'APC_PICK_START', phase: 'button' });
    statusEl.textContent = r.ok ? 'Seletor armado: clique no botão de envio (Esc pula).' : ('Falha: ' + r.reason);
    window.close();
  } catch (e) { statusEl.textContent = 'Erro: ' + (e && e.message); }
});

document.getElementById('runNow').addEventListener('click', async () => {
  statusEl.textContent = 'Executando agora…';
  try {
    const r = await api.runtime.sendMessage({ type: 'APC_RUN_NOW' });
    if (r && r.ok) statusEl.textContent = 'Resultado: ' + (r.detail || 'ok');
    else if (r) statusEl.textContent = 'Não executou: ' + (r.reason || '?');
  } catch (e) { statusEl.textContent = 'Erro: ' + (e && e.message); }
  await refresh();
});

document.getElementById('openOptions').addEventListener('click', () => { api.runtime.openOptionsPage(); });

refresh();
setInterval(refresh, 3000);
