# Extensão Firefox — preenchimento periódico

Preenche uma aba escolhida, depois de cada intervalo. Padrão: 37 minutos e 14 segundos; texto `GOSTEI. OBRIGADO`; seletor `[contenteditable="true"].ProseMirror[role="textbox"]`; Enter. A extensão começa parada.

## Instalação temporária
1. Extraia todo o ZIP em uma pasta.
2. No Firefox, abra `about:debugging#/runtime/this-firefox`, clique em **Carregar extensão temporária** e selecione `manifest.json` na pasta extraída.
3. Abra a página desejada e clique no ícone da extensão. Confira os parâmetros e clique em **Iniciar nesta aba**.
4. Use **Parar** para interromper. A extensão temporária precisa ser carregada novamente após reiniciar o Firefox. O agendamento não sobrevive ao reinício do Firefox.

Para instalação permanente no Firefox comum é necessário distribuir uma extensão assinada pela Mozilla; este pacote contém código-fonte e não é assinado.

## Identificação
Escolha CSS para **Copiar seletor CSS** ou **Copiar caminho CSS**, XPath para **Copiar XPath**, ou HTML externo para **Copiar HTML externo**. O HTML externo é analisado somente como descrição de atributos, sem execução nem inserção de HTML: a extensão combina a tag e atributos de identificação disponíveis (id, aria-label, role, name, data-testid e contenteditable; na ausência destes, classes). A correspondência pode mudar com alterações da página. Se houver zero ou mais de uma correspondência, nenhuma alteração ocorre. Se o elemento selecionado for contêiner, deve conter exatamente um campo editável. Um seletor curto e específico costuma ser mais robusto do que um caminho absoluto.

## Funcionamento e limites
A extensão pede acesso aos sites porque o destino é configurável; atua apenas na aba explicitamente escolhida e para se a URL mudar ou a aba fechar. Os dados são guardados localmente. Não sobrescreve um campo com texto, nem atua em campo invisível ou desativado. Um campo ocupado faz aquela tentativa ser ignorada. O agendamento usa temporizador do navegador, sujeito a atrasos quando o computador dorme; não recupera execuções perdidas. Não há suporte a iframes ou shadow DOM.

O Enter é um evento sintético, que alguns sites podem ignorar. A mensagem de estado registra a tentativa, não confirma que o servidor recebeu a mensagem; teste manualmente com intervalo curto. Sites podem alterar o editor ou impor suas próprias restrições. Conteúdo já digitado pode permanecer se o site não aceitar Enter. A extensão não contorna bloqueios e não garante o envio durante geração de respostas.
