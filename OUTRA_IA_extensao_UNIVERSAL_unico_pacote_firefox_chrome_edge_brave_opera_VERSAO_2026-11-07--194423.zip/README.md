# Auto Preencher Campo Temporizado — v4.0.0
## PACOTE UNIVERSAL: um único diretório para Firefox, Chrome, Edge, Brave e Opera

Este pacote é verdadeiramente universal: **um único `manifest.json` e um único conjunto de
arquivos**, sem nenhuma alteração entre navegadores. O mecanismo é o documentado pela MDN
("Cross-browser Manifest V3 background scripts"): o manifesto declara simultaneamente
`background.scripts` (usado pelo Firefox, event page) e `background.service_worker`
(usado pelo Chrome e demais Chromium). Cada navegador ignora a chave que não usa:
- Firefox 121+: inicia o background page normalmente mesmo com `service_worker` presente (bug 1860304).
- Chrome 121+: ignora `background.scripts` em MV3 (antes da 121, recusava o carregamento).
- `browser_specific_settings` (id Gecko, versão mínima, data_collection_permissions) é ignorado pelo Chrome/Chromium.
- `minimum_chrome_version: "121"` protege contra instalação em Chrome antigo; Firefox ignora a chave.
- Edge, Brave, Opera e Vivaldi modernos são Chromium ≥121: usam `service_worker`, funciona igual ao Chrome.

Requisitos: Firefox ≥121 · Chrome/Edge/Brave/Opera com Chromium ≥121.

## Instalação (o mesmo diretório em todos)
- Firefox: `about:debugging` → Este Firefox → "Carregar extensão temporária…" → selecione `manifest.json`.
  Permanente: assinar em addons.mozilla.org / `web-ext sign`, ou Developer Edition/Nightly
  com `xpinstall.signatures.required=false`. O manifesto já inclui
  `data_collection_permissions.required: ["none"]` (obrigatório na AMO desde 03/11/2025;
  a extensão não coleta nem transmite dados — tudo fica em armazenamento local).
- Chrome: `chrome://extensions` → Modo do desenvolvedor → "Carregar sem compactação" → a pasta.
- Edge: `edge://extensions` · Brave: `brave://extensions` · Opera: `opera://extensions`
  (mesmo procedimento do Chrome; o aviso de chaves não reconhecidas é inofensivo).

## Novidades da v4 (sobre a v3)
1. **Pacote único universal** (acima).
2. **Vigia de saúde da aba (watchdog)**: pinga o content script da aba alvo em intervalo
   configurável (padrão 60 s). Se a página travar — crash (Firefox), erro de carregamento
   (Chrome), aba morta — o ping falha; após N falhas consecutivas (padrão 2) a extensão:
   recarrega a aba → aguarda o carregamento concluir (status "complete", timeout 30 s) →
   confirma que o content script voltou (novo ping) → (opcional) verifica se o campo alvo
   está presente e editável → **executa o envio imediato** e **reinicia o ciclo** do timer.
   Até 3 recarregamentos por incidente, com intervalo mínimo de 60 s entre incidentes
   (anti-loop). Todo o protocolo é registrado no log. Configurável: liga/desliga, intervalo,
   falhas antes de recarregar, auto-reload, máx. de reloads, verificação pós-reload.
3. **Limite de ciclos**: encerra o automatismo após NN execuções (configurável), com
   contador persistente e notificação.
4. **Limite de duração**: encerra após NN horas/min/seg de automatismo ativo; o prazo é
   persistido (sobrevive a reinício do navegador) e é verificado inclusive na abertura do
   navegador. Reativar o interruptor após encerramento por limite zera os contadores.
5. **Teste de localizador** ("sonda"): botão na página de opções testa primário + reservas
   na aba ativa SEM preencher nada, mostrando qual seletor encontrou e se é editável.
6. **Popup ampliado**: contagem regressiva, ciclos x/limite, tempo restante, estado de
   saúde da aba (OK/sem resposta/recuperada) e últimos eventos do log.

## Mantido da v3
Jitter aleatório com faixa configurável; reservas tipadas (css|caminho-css|xpath|
xpath-curto|xpath-longo|outerhtml); log contínuo em segundo plano (500 eventos, exportável);
padrões personalizados + fábrica; exportar/importar JSON; execução manual; runOnEnable;
runOnLoad; modos de envio; badge ON.

## Limites conhecidos
- Alarmes do navegador: granularidade mínima de ~30 s (aplica-se ao timer e ao vigia).
- Páginas internas (about:, chrome:, edge://, lojas de extensão) não aceitam content
  scripts: o vigia registrará falha de ping; auto-reload não deve ser usado para essas URLs.
- O vigia monitora a aba conforme o escopo configurado (ativa/primeira + filtro de URL):
  mantenha o filtro de URL preenchido para não vigiar a aba errada.
