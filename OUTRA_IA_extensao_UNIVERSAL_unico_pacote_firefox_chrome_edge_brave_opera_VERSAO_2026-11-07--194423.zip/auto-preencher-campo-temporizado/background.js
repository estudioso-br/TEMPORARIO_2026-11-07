const api = (typeof browser !== "undefined" && browser && browser.runtime) ? browser : chrome;
const ALARM = "apc-timer";
const WATCH = "apc-watchdog";
const LOG_KEY = "log";
const LOG_MAX = 500;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const DEFAULTS_FACTORY = {
  enabled: false,
  minutes: 37, seconds: 14,
  jitterEnabled: false, jitterMinSec: 0, jitterMaxSec: 300,
  selectorType: "css",
  selector: '[aria-label="Pergunte ao ChatGPT"]',
  fallbacks: 'css|[contenteditable="true"][aria-multiline="true"]\ncss|div[role="textbox"]\ncss|.ProseMirror\nxpath-curto|//div[@contenteditable="true" and @role="textbox"]',
  text: "GOSTEI. OBRIGADO",
  enterMode: "auto",
  scope: "active", urlContains: "",
  retries: 3, retryDelayMs: 1500,
  runOnEnable: true, runOnLoad: false,
  debugMode: true, notifyOnFail: true,
  watchdogEnabled: true, watchdogIntervalSec: 60, watchdogMisses: 2,
  autoReload: true, maxReloads: 3, verifyAfterReload: true,
  maxCyclesEnabled: false, maxCycles: 1000,
  durationEnabled: false, durH: 0, durM: 0, durS: 0,
  cyclesDone: 0, deadlineMs: null, disabledByLimit: "",
  wdMisses: 0, lastHealth: "", lastRecoveryAt: 0,
  lastRun: null, lastResult: null, nextRun: null
};

function baseMinutes(cfg) {
  return Math.max((Number(cfg.minutes) || 0) + (Number(cfg.seconds) || 0) / 60, 0);
}
function randInt(min, max) {
  min = Math.ceil(min); max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
function nextDelayMinutes(cfg) {
  const base = baseMinutes(cfg);
  let jitterSec = 0;
  if (cfg.jitterEnabled) {
    const lo = Math.max(0, Number(cfg.jitterMinSec) || 0);
    const hi = Math.max(lo, Number(cfg.jitterMaxSec) || 0);
    jitterSec = randInt(lo, hi);
  }
  return { total: Math.max(base + jitterSec / 60, 0.5), jitterSec };
}
function durationMs(cfg) {
  return ((Number(cfg.durH) || 0) * 3600 + (Number(cfg.durM) || 0) * 60 + (Number(cfg.durS) || 0)) * 1000;
}

async function getCfg() {
  const stored = await api.storage.local.get(Object.keys(DEFAULTS_FACTORY));
  const cfg = {};
  for (const k of Object.keys(DEFAULTS_FACTORY)) {
    cfg[k] = (stored[k] !== undefined && stored[k] !== null) ? stored[k] : DEFAULTS_FACTORY[k];
  }
  return cfg;
}

async function alog(lvl, msg) {
  try {
    const cur = await api.storage.local.get(LOG_KEY);
    const log = Array.isArray(cur[LOG_KEY]) ? cur[LOG_KEY] : [];
    log.push({ t: Date.now(), s: "bg", l: lvl, m: String(msg).slice(0, 600) });
    if (log.length > LOG_MAX) log.splice(0, log.length - LOG_MAX);
    await api.storage.local.set({ [LOG_KEY]: log });
  } catch (e) {}
}

async function setStatus(ok, reason) {
  await api.storage.local.set({
    lastRun: Date.now(),
    lastResult: ok ? "OK — campo preenchido e enviado" : ("FALHA — " + reason)
  });
}
async function setBadge(enabled) {
  try {
    await api.action.setBadgeBackgroundColor({ color: enabled ? "#1a7f37" : "#999999" });
    await api.action.setBadgeText({ text: enabled ? "ON" : "" });
  } catch (e) {}
}
async function notify(title, message) {
  try {
    await api.notifications.create("", { type: "basic", iconUrl: api.runtime.getURL("icons/icon48.png"), title, message });
  } catch (e) {}
}

async function ensureDeadline() {
  const cfg = await getCfg();
  if (cfg.enabled && cfg.durationEnabled && !cfg.deadlineMs) {
    const dl = Date.now() + durationMs(cfg);
    await api.storage.local.set({ deadlineMs: dl });
    await alog("INFO", "Prazo do automatismo definido: até " + new Date(dl).toLocaleString("pt-BR") + " (" + cfg.durH + "h" + cfg.durM + "m" + cfg.durS + "s).");
  }
}

async function schedule(origin) {
  await api.alarms.clear(ALARM);
  await api.alarms.clear(WATCH);
  const cfg = await getCfg();
  await setBadge(cfg.enabled);
  if (!cfg.enabled) {
    await api.storage.local.set({ nextRun: null });
    await alog("INFO", "Temporizador desativado (" + origin + ").");
    return;
  }
  const d = nextDelayMinutes(cfg);
  api.alarms.create(ALARM, { delayInMinutes: d.total });
  await api.storage.local.set({ nextRun: Date.now() + d.total * 60000 });
  await alog("INFO", "Timer (" + origin + "): base=" + cfg.minutes + "m" + cfg.seconds + "s" +
    (cfg.jitterEnabled ? "+aleatório(" + cfg.jitterMinSec + "–" + cfg.jitterMaxSec + "s)=" + d.jitterSec + "s" : "+jitter desligado") +
    " => próximo ciclo em " + (d.total * 60).toFixed(1) + "s.");
  if (cfg.watchdogEnabled) {
    const per = Math.max(0.5, (Number(cfg.watchdogIntervalSec) || 60) / 60);
    api.alarms.create(WATCH, { delayInMinutes: 0.5, periodInMinutes: per });
    await alog("DEBUG", "Vigia de saúde armado: verificação a cada " + (per * 60).toFixed(0) + "s, reload após " + cfg.watchdogMisses + " falha(s) consecutiva(s).");
  }
}

async function ping(tabId) {
  try {
    const r = await api.tabs.sendMessage(tabId, { type: "APC_PING" });
    return !!(r && r.ok);
  } catch (e) { return false; }
}
async function probe(tabId, cfg) {
  try {
    const r = await api.tabs.sendMessage(tabId, { type: "APC_PROBE", settings: cfg });
    return r || { found: false };
  } catch (e) { return { found: false, error: String(e && e.message) }; }
}
function waitComplete(tabId, timeoutMs) {
  return new Promise((resolve) => {
    const to = setTimeout(() => { api.tabs.onUpdated.removeListener(h); resolve(false); }, timeoutMs);
    function h(id, info) {
      if (id === tabId && info.status === "complete") {
        clearTimeout(to); api.tabs.onUpdated.removeListener(h); resolve(true);
      }
    }
    api.tabs.onUpdated.addListener(h);
  });
}

async function findTab(cfg) {
  let tabs;
  if (cfg.scope === "active") tabs = await api.tabs.query({ active: true, currentWindow: true });
  else tabs = await api.tabs.query({});
  const f = (cfg.urlContains || "").trim().toLowerCase();
  if (f) tabs = tabs.filter((t) => (t.url || "").toLowerCase().includes(f));
  return tabs[0] || null;
}

async function recovery(tab, cfg) {
  const now = Date.now();
  const st = await api.storage.local.get(["lastRecoveryAt"]);
  if (now - (st.lastRecoveryAt || 0) < 60000) {
    await alog("DEBUG", "Recuperação recente (<60s); aguardando próxima rodada do vigia.");
    return false;
  }
  await api.storage.local.set({ lastRecoveryAt: now });
  await alog("WARN", "Página sem resposta. Iniciando RECUPERAÇÃO: recarregar aba #" + tab.id + " (até " + cfg.maxReloads + " tentativa(s)).");
  for (let i = 1; i <= cfg.maxReloads; i++) {
    try { await api.tabs.reload(tab.id, { bypassCache: false }); }
    catch (e) { await alog("ERROR", "tabs.reload falhou (tentativa " + i + "): " + (e && e.message)); }
    const loaded = await waitComplete(tab.id, 30000);
    await alog("DEBUG", "Reload " + i + "/" + cfg.maxReloads + ": carregamento " + (loaded ? "concluído" : "TIMEOUT 30s") + ".");
    await sleep(2000);
    if (await ping(tab.id)) {
      await alog("INFO", "Aba recuperada após " + i + " reload(s).");
      await api.storage.local.set({ wdMisses: 0, lastHealth: "recuperada " + new Date().toLocaleTimeString("pt-BR") });
      if (cfg.verifyAfterReload) {
        const pr = await probe(tab.id, cfg);
        if (pr && pr.found) {
          await alog("INFO", "Verificação pós-reload: campo localizado via [" + pr.used + "]" + (pr.editable ? " (editável, pronto p/ Enter/clique)" : " (ATENÇÃO: não editável)") + ".");
        } else {
          await alog("WARN", "Verificação pós-reload: campo NÃO localizado" + (pr && pr.error ? " (erro: " + pr.error + ")" : "") + "; automatismo retomado será revalidado no próximo ciclo.");
          return false;
        }
      }
      await alog("INFO", "Retomando automatismo: envio imediato + reinício do ciclo.");
      await tick("recuperação pós-reload", { skipHealth: true });
      await schedule("rearme pós-recuperação");
      return true;
    }
    await alog("WARN", "Aba ainda sem resposta após reload " + i + ".");
  }
  await alog("ERROR", "RECUPERAÇÃO FALHOU após " + cfg.maxReloads + " reload(s). Verifique a página manualmente.");
  await api.storage.local.set({ lastHealth: "falha de recuperação " + new Date().toLocaleTimeString("pt-BR") });
  if (cfg.notifyOnFail) await notify("Auto Preencher Campo", "Aba não recuperou após " + cfg.maxReloads + " recarregamentos.");
  return false;
}

async function watchdogCheck() {
  const cfg = await getCfg();
  if (!cfg.enabled || !cfg.watchdogEnabled) return;
  const tab = await findTab(cfg);
  if (!tab) {
    if (cfg.debugMode) await alog("DEBUG", "Vigia: aba alvo não encontrada (escopo=" + cfg.scope + ").");
    await api.storage.local.set({ lastHealth: "sem aba alvo " + new Date().toLocaleTimeString("pt-BR") });
    return;
  }
  const ok = await ping(tab.id);
  if (ok) {
    await api.storage.local.set({ wdMisses: 0, lastHealth: "OK " + new Date().toLocaleTimeString("pt-BR") });
    if (cfg.debugMode) await alog("DEBUG", "Vigia: aba #" + tab.id + " respondeu ao ping.");
    return;
  }
  const cur = await api.storage.local.get(["wdMisses"]);
  const misses = (cur.wdMisses || 0) + 1;
  await api.storage.local.set({ wdMisses: misses, lastHealth: "sem resposta (" + misses + ") " + new Date().toLocaleTimeString("pt-BR") });
  await alog("WARN", "Vigia: aba #" + tab.id + " NÃO respondeu (" + misses + "/" + cfg.watchdogMisses + ") — possível crash, erro de carregamento ou página morta.");
  if (misses >= cfg.watchdogMisses) {
    if (!cfg.autoReload) {
      await alog("ERROR", "autoReload desligado: a aba segue travada e o automatismo está interrompido.");
      if (cfg.notifyOnFail) await notify("Auto Preencher Campo", "Aba travada; autoReload desligado.");
      return;
    }
    await recovery(tab, cfg);
  }
}

async function disableByLimit(reason) {
  await api.storage.local.set({ enabled: false, disabledByLimit: reason + " em " + new Date().toLocaleString("pt-BR") });
  await api.alarms.clear(ALARM);
  await api.alarms.clear(WATCH);
  await api.storage.local.set({ nextRun: null });
  await setBadge(false);
  await alog("WARN", "AUTOMATISMO ENCERRADO POR LIMITE: " + reason + ". (Reative na extensão para reiniciar os contadores.)");
  await notify("Auto Preencher Campo", "Automatismo encerrado: " + reason + ".");
}

async function tick(origin, opts) {
  opts = opts || {};
  const t0 = Date.now();
  const cfg = await getCfg();
  if (!cfg.enabled) {
    await alog("INFO", "Execução (" + origin + ") ignorada: extensão desativada.");
    return;
  }
  if (cfg.durationEnabled && cfg.deadlineMs && Date.now() >= cfg.deadlineMs) {
    await disableByLimit("tempo esgotado (" + cfg.durH + "h" + cfg.durM + "m" + cfg.durS + "s)");
    return;
  }
  if (cfg.maxCyclesEnabled && (cfg.cyclesDone || 0) >= cfg.maxCycles) {
    await disableByLimit("limite de ciclos atingido (" + cfg.cyclesDone + "/" + cfg.maxCycles + ")");
    return;
  }
  await alog("INFO", "--- Execução iniciada (origem=" + origin + ") | ciclo " + ((cfg.cyclesDone || 0) + 1) + (cfg.maxCyclesEnabled ? "/" + cfg.maxCycles : "") + " ---");
  const tab = await findTab(cfg);
  if (!tab) {
    await setStatus(false, "aba alvo não encontrada");
    await alog("WARN", "Aba alvo não encontrada (escopo=" + cfg.scope + ", filtro='" + (cfg.urlContains || "") + "').");
    if (cfg.notifyOnFail) await notify("Auto Preencher Campo", "Aba alvo não encontrada.");
    return;
  }
  if (cfg.debugMode) await alog("DEBUG", "Aba alvo: #" + tab.id + " | " + (tab.url || "(url indisponível)"));
  if (!opts.skipHealth && cfg.watchdogEnabled) {
    const alive = await ping(tab.id);
    if (!alive) {
      await alog("WARN", "Aba não respondeu ao ping pré-execução; acionando protocolo de recuperação.");
      const ok = await recovery(tab, cfg);
      if (!ok) await setStatus(false, "aba travada; recuperação falhou ou campo indisponível");
      return;
    }
  }
  try {
    const res = await api.tabs.sendMessage(tab.id, { type: "APC_FILL", settings: cfg });
    const ok = !!(res && res.ok);
    await setStatus(ok, (res && res.reason) || "erro desconhecido");
    await alog(ok ? "INFO" : "ERROR", "Resultado: " + (ok ? "sucesso" : (res && res.reason)) + " | duração total " + (Date.now() - t0) + " ms.");
    if (!ok && cfg.notifyOnFail) await notify("Auto Preencher Campo", String((res && res.reason) || "Falha desconhecida"));
  } catch (e) {
    await setStatus(false, "falha de comunicação: " + (e && e.message));
    await alog("ERROR", "Falha ao enviar mensagem à aba #" + tab.id + ": " + (e && e.message) + " | duração " + (Date.now() - t0) + " ms.");
    if (cfg.notifyOnFail) await notify("Auto Preencher Campo", "Não foi possível acessar a aba (página morta? vigia irá recarregar).");
  }
  const cycles = (cfg.cyclesDone || 0) + 1;
  await api.storage.local.set({ cyclesDone: cycles });
  const cfg2 = await getCfg();
  if (cfg2.maxCyclesEnabled && cycles >= cfg2.maxCycles) {
    await disableByLimit("limite de ciclos atingido (" + cycles + "/" + cfg2.maxCycles + ")");
    return;
  }
  if (cfg2.durationEnabled && cfg2.deadlineMs && Date.now() >= cfg2.deadlineMs) {
    await disableByLimit("tempo esgotado (" + cfg2.durH + "h" + cfg2.durM + "m" + cfg2.durS + "s)");
  }
}

api.alarms.onAlarm.addListener((a) => {
  if (a.name === ALARM) {
    void (async () => { await tick("alarme"); await schedule("rearme pós-ciclo"); })();
  } else if (a.name === WATCH) {
    void watchdogCheck();
  }
});

api.runtime.onInstalled.addListener(async () => {
  const cur = await api.storage.local.get(Object.keys(DEFAULTS_FACTORY));
  const patch = {};
  for (const k of Object.keys(DEFAULTS_FACTORY)) {
    if (cur[k] === undefined) patch[k] = DEFAULTS_FACTORY[k];
  }
  if (Object.keys(patch).length) await api.storage.local.set(patch);
  await ensureDeadline();
  await schedule("instalação");
  await alog("INFO", "Extensão instalada/atualizada (v4.0.0 — pacote universal + vigia de saúde + limites).");
});

api.runtime.onStartup.addListener(() => {
  void (async () => {
    const cfg = await getCfg();
    if (cfg.enabled && cfg.durationEnabled && cfg.deadlineMs && Date.now() >= cfg.deadlineMs) {
      await disableByLimit("tempo esgotado enquanto o navegador estava fechado");
      return;
    }
    await ensureDeadline();
    await schedule("início do navegador");
  })();
});

api.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  const camposTimer = ["enabled","minutes","seconds","jitterEnabled","jitterMinSec","jitterMaxSec","watchdogEnabled","watchdogIntervalSec","watchdogMisses","autoReload"];
  if (camposTimer.some((k) => changes[k])) void schedule("mudança de configuração");
  const camposDur = ["durationEnabled","durH","durM","durS"];
  if (camposDur.some((k) => changes[k])) {
    void (async () => {
      const cfg = await getCfg();
      if (cfg.enabled && cfg.durationEnabled) {
        const dl = Date.now() + durationMs(cfg);
        await api.storage.local.set({ deadlineMs: dl });
        await alog("INFO", "Prazo redefinido por mudança de configuração: até " + new Date(dl).toLocaleString("pt-BR") + ".");
      } else if (!cfg.durationEnabled) {
        await api.storage.local.set({ deadlineMs: null });
      }
    })();
  }
  if (changes.enabled && changes.enabled.newValue === true && changes.enabled.oldValue === false) {
    void (async () => {
      const st = await api.storage.local.get(["disabledByLimit"]);
      if (st.disabledByLimit) {
        await api.storage.local.set({ cyclesDone: 0, deadlineMs: null, disabledByLimit: "", wdMisses: 0 });
        await alog("INFO", "Reativação após encerramento por limite: contadores zerados. (Limite anterior: " + st.disabledByLimit + ")");
      }
      await ensureDeadline();
      const cfg = await getCfg();
      if (cfg.runOnEnable) {
        await alog("INFO", "Execução imediata por ativação (runOnEnable).");
        await tick("ativação");
      }
    })();
  }
  if (changes.enabled) void setBadge(!!changes.enabled.newValue);
});

api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "APC_RUN_NOW") {
    (async () => {
      await tick(sender && sender.tab ? "página(runOnLoad)" : "manual");
      sendResponse(await api.storage.local.get(["lastResult","lastRun","nextRun","cyclesDone","deadlineMs"]));
    })();
    return true;
  }
});
