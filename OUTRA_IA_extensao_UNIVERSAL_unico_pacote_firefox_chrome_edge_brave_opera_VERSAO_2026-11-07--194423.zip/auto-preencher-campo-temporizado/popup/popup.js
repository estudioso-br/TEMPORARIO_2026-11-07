const api = (typeof browser !== "undefined" && browser && browser.runtime) ? browser : chrome;
const enabledEl = document.getElementById("enabled");
const statusEl = document.getElementById("status");
const cdEl = document.getElementById("countdown");
const limitsEl = document.getElementById("limits");
const healthEl = document.getElementById("health");
const logEl = document.getElementById("logPreview");
let state = {};

function fmtTs(ms) { return ms ? new Date(ms).toLocaleString("pt-BR") : "nunca"; }
function fmtDur(ms) {
  if (ms <= 0) return "esgotado";
  let s = Math.round(ms / 1000);
  const h = Math.floor(s / 3600); s -= h * 3600;
  const m = Math.floor(s / 60); s -= m * 60;
  return String(h).padStart(2,"0") + ":" + String(m).padStart(2,"0") + ":" + String(s).padStart(2,"0");
}

async function refresh() {
  const s = await api.storage.local.get(["enabled","lastRun","lastResult","nextRun","log","cyclesDone","maxCycles","maxCyclesEnabled","deadlineMs","durationEnabled","disabledByLimit","lastHealth"]);
  state = s;
  enabledEl.checked = !!s.enabled;
  statusEl.textContent = "Última execução: " + fmtTs(s.lastRun) + "\n" + (s.lastResult || "—");
  const parts = [];
  if (s.maxCyclesEnabled) parts.push("Ciclos: " + (s.cyclesDone || 0) + "/" + s.maxCycles);
  if (s.durationEnabled && s.deadlineMs) parts.push("Tempo restante: " + fmtDur(s.deadlineMs - Date.now()));
  if (s.disabledByLimit) parts.push("ENCERRADO POR LIMITE: " + s.disabledByLimit);
  limitsEl.textContent = parts.join("\n");
  healthEl.textContent = s.lastHealth ? "Saúde da aba: " + s.lastHealth : "Saúde da aba: (vigia inativo)";
  healthEl.className = /^OK|^recuperada/.test(s.lastHealth || "") ? "ok" : ((s.lastHealth || "") ? "bad" : "");
  const log = Array.isArray(s.log) ? s.log.slice(-4) : [];
  logEl.textContent = log.map((e) => new Date(e.t).toLocaleTimeString("pt-BR") + " [" + e.l + "] " + e.m).join("\n") || "(log vazio)";
}

setInterval(() => {
  if (!state.enabled) { cdEl.textContent = "Temporizador desativado."; return; }
  if (state.nextRun) {
    let s = Math.max(0, Math.round((state.nextRun - Date.now()) / 1000));
    const h = Math.floor(s / 3600); s -= h * 3600;
    const m = Math.floor(s / 60); s -= m * 60;
    cdEl.textContent = "Próxima execução em " + (h ? h + "h " : "") + String(m).padStart(2,"0") + "m " + String(s).padStart(2,"0") + "s";
  } else cdEl.textContent = "";
  if (state.durationEnabled && state.deadlineMs) refresh();
}, 1000);

enabledEl.addEventListener("change", async () => {
  await api.storage.local.set({ enabled: enabledEl.checked });
  await refresh();
});
document.getElementById("runNow").addEventListener("click", async () => {
  statusEl.textContent = "Executando agora…";
  try { await api.runtime.sendMessage({ type: "APC_RUN_NOW" }); } catch (e) {}
  await refresh();
});
document.getElementById("openOptions").addEventListener("click", () => { api.runtime.openOptionsPage(); });
refresh();
setInterval(refresh, 5000);
