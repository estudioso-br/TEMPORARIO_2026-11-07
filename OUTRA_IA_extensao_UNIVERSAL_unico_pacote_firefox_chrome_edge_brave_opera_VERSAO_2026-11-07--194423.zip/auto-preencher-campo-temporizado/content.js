(function () {
  if (window.__apcContentLoaded) return;
  window.__apcContentLoaded = true;

  const api = (typeof browser !== "undefined" && browser && browser.runtime) ? browser : chrome;
  const SRC = location.hostname;
  const LOG_KEY = "log";
  const LOG_MAX = 500;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  const TYPE_ALIASES = {
    "css": "css", "seletor-css": "css",
    "csspath": "cssPath", "css-path": "cssPath", "caminho-css": "cssPath",
    "xpath": "xpath", "xpath-curto": "xpath", "xpath-short": "xpath",
    "xpath-longo": "xpath", "xpath-long": "xpath",
    "outerhtml": "outerHTML", "html-externo": "outerHTML"
  };

  function parseLine(line) {
    const raw = (line || "").trim();
    if (!raw) return null;
    const i = raw.indexOf("|");
    if (i < 0) return { type: "css", sel: raw, label: "css(sem prefixo)" };
    const head = raw.slice(0, i).trim().toLowerCase();
    return { type: TYPE_ALIASES[head] || "css", sel: raw.slice(i + 1).trim(), label: head };
  }

  async function alog(lvl, msg) {
    try {
      const cur = await api.storage.local.get(LOG_KEY);
      const log = Array.isArray(cur[LOG_KEY]) ? cur[LOG_KEY] : [];
      log.push({ t: Date.now(), s: SRC, l: lvl, m: String(msg).slice(0, 600) });
      if (log.length > LOG_MAX) log.splice(0, log.length - LOG_MAX);
      await api.storage.local.set({ [LOG_KEY]: log });
    } catch (e) {}
  }

  function locateOne(type, sel) {
    const s = (sel || "").trim();
    if (!s) return null;
    switch (type) {
      case "xpath": {
        try {
          const r = document.evaluate(s, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
          return r.singleNodeValue;
        } catch (e) { return null; }
      }
      case "outerHTML": {
        const target = s.replace(/\s+/g, " ").trim();
        const walker = document.createTreeWalker(document, NodeFilter.SHOW_ELEMENT);
        let n = walker.currentNode;
        while (n) {
          if (n.outerHTML && n.outerHTML.replace(/\s+/g, " ").trim() === target) return n;
          n = walker.nextNode();
        }
        return null;
      }
      case "css":
      case "cssPath":
      default: {
        try { return document.querySelector(s); } catch (e) { return null; }
      }
    }
  }

  function buildAttempts(cfg) {
    const tries = [];
    const main = (cfg.selector || "").trim();
    if (main) tries.push({ type: cfg.selectorType || "css", sel: main, label: "PRIMÁRIO(" + (cfg.selectorType || "css") + ")" });
    String(cfg.fallbacks || "").split("\n").forEach((line, idx) => {
      const p = parseLine(line);
      if (p && p.sel) tries.push({ type: p.type, sel: p.sel, label: "reserva#" + (idx + 1) + "(" + p.label + ")" });
    });
    return tries;
  }

  async function locateAll(cfg, quiet) {
    const tries = buildAttempts(cfg);
    for (const t of tries) {
      const el = locateOne(t.type, t.sel);
      if (cfg.debugMode && !quiet) await alog("DEBUG", "Tentativa [" + t.label + "] " + (t.sel.length > 90 ? t.sel.slice(0, 90) + "…" : t.sel) + " => " + (el ? "ENCONTRADO" : "não encontrado") + ".");
      if (el) return { el, used: t.label, sel: t.sel };
    }
    return null;
  }

  function pickEditable(el) {
    if (!el) return null;
    if (el.isContentEditable || el.tagName === "TEXTAREA" || el.tagName === "INPUT") return el;
    return el.querySelector && el.querySelector("[contenteditable='true'], textarea, input");
  }

  function describe(el) {
    if (!el) return "(nulo)";
    const parts = ["<" + el.tagName.toLowerCase() + ">"];
    if (el.id) parts.push("#" + el.id);
    const al = el.getAttribute && el.getAttribute("aria-label");
    if (al) parts.push('aria-label="' + al + '"');
    if (el.isContentEditable) parts.push("contenteditable");
    const cls = (el.className && typeof el.className === "string") ? el.className.trim().split(/\s+/).slice(0, 3).join(".") : "";
    if (cls) parts.push("." + cls);
    return parts.join(" ");
  }

  function fillContentEditable(el, text) {
    el.focus();
    const selWin = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(el);
    selWin.removeAllRanges();
    selWin.addRange(range);
    document.execCommand("delete", false, null);
    document.execCommand("insertText", false, text);
    if (!el.textContent.includes(text)) {
      const p = document.createElement("p");
      p.textContent = text;
      el.replaceChildren(p);
      el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    }
  }

  function fillInput(el, text) {
    el.focus();
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, "value");
    desc.set.call(el, text);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function pressEnter(el) {
    const opts = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true, composed: true };
    el.dispatchEvent(new KeyboardEvent("keydown", opts));
    el.dispatchEvent(new KeyboardEvent("keypress", opts));
    el.dispatchEvent(new KeyboardEvent("keyup", opts));
    el.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, cancelable: true, inputType: "insertParagraph" }));
  }

  function clickSendButton(el) {
    const root = el.closest("form") || el.closest("[class*='composer' i]") || document;
    const buttons = Array.from(root.querySelectorAll("button"));
    const cand = buttons.find((b) =>
      !b.disabled &&
      (b.type === "submit" ||
        /enviar|send|submit/i.test(b.getAttribute("aria-label") || "") ||
        /send/i.test((b.dataset && b.dataset.testid) || ""))
    );
    if (cand) { cand.click(); return cand; }
    return null;
  }

  async function submitByMode(target, cfg) {
    const mode = cfg.enterMode || "auto";
    if (mode === "none") return { submitted: false, method: "none" };
    if (mode === "keys" || mode === "auto") pressEnter(target);
    if (mode === "keys") return { submitted: true, method: "keys" };
    if (mode === "button") {
      const b = clickSendButton(target);
      return { submitted: !!b, method: "button" };
    }
    await sleep(400);
    const rest = (target.isContentEditable ? target.textContent : (target.value || "")).trim();
    if (rest.length > 0) {
      const b = clickSendButton(target);
      return { submitted: !!b, method: "auto(fallback botão: " + (b ? describe(b) : "não achou botão") + ")" };
    }
    return { submitted: true, method: "auto(teclas)" };
  }

  async function run(cfg) {
    const t0 = Date.now();
    try {
      await alog("INFO", "Início do preenchimento em " + location.href);
      const retries = Math.max(0, Number(cfg.retries) || 0);
      let found = null;
      for (let i = 0; i <= retries; i++) {
        found = await locateAll(cfg, false);
        if (found) break;
        if (i < retries) {
          if (cfg.debugMode) await alog("DEBUG", "Nada encontrado na rodada " + (i + 1) + "; nova tentativa em " + (Number(cfg.retryDelayMs) || 1500) + " ms.");
          await sleep(Number(cfg.retryDelayMs) || 1500);
        }
      }
      if (!found) {
        await alog("WARN", "Elemento NÃO localizado após " + (retries + 1) + " rodada(s); nenhum seletor (primário/reserva) encontrou o alvo.");
        return { ok: false, reason: "elemento não encontrado na página" };
      }
      await alog("INFO", "Elemento localizado via [" + found.used + "]: " + describe(found.el));
      try { found.el.scrollIntoView({ block: "center" }); } catch (e) {}

      const target = pickEditable(found.el);
      if (!target) {
        await alog("ERROR", "O elemento " + describe(found.el) + " não é editável nem contém input/textarea/contenteditable.");
        return { ok: false, reason: "elemento localizado não é editável" };
      }
      if (target !== found.el && cfg.debugMode) await alog("DEBUG", "Campo editável interno: " + describe(target));

      if (target.isContentEditable) fillContentEditable(target, cfg.text);
      else fillInput(target, cfg.text);

      const conteudo = target.isContentEditable ? target.textContent : (target.value || "");
      if (conteudo.trim() !== String(cfg.text || "").trim()) {
        await alog("ERROR", "Verificação pós-preenchimento FALHOU: campo contém '" + conteudo.slice(0, 80) + "'.");
        return { ok: false, reason: "texto não permaneceu no campo após inserção" };
      }
      await alog("INFO", "Texto inserido e verificado (" + String(cfg.text || "").length + " caracteres).");

      const sub = await submitByMode(target, cfg);
      await alog(sub.submitted ? "INFO" : "WARN", "Envio modo '" + (cfg.enterMode || "auto") + "' (" + sub.method + ") => " + (sub.submitted ? "disparado" : "NÃO disparado"));
      if (!sub.submitted) return { ok: false, reason: "não foi possível disparar o envio (modo " + (cfg.enterMode || "auto") + ")" };

      await alog("INFO", "Preenchimento concluído com sucesso | duração " + (Date.now() - t0) + " ms.");
      return { ok: true };
    } catch (e) {
      await alog("ERROR", "Exceção durante execução: " + (e && e.message));
      return { ok: false, reason: String(e && e.message) };
    }
  }

  api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.type) return;
    if (msg.type === "APC_PING") {
      sendResponse({ ok: true, ready: document.readyState, url: location.href });
      return;
    }
    if (msg.type === "APC_PROBE") {
      (async () => {
        const cfg = msg.settings || {};
        const found = await locateAll(cfg, true);
        const r = found
          ? { found: true, used: found.used, editable: !!pickEditable(found.el), desc: describe(found.el) }
          : { found: false };
        sendResponse(r);
      })();
      return true;
    }
    if (msg.type === "APC_FILL") {
      run(msg.settings).then(sendResponse);
      return true;
    }
  });

  (async () => {
    try {
      const s = await api.storage.local.get(["enabled", "runOnLoad", "urlContains"]);
      if (!s.enabled || !s.runOnLoad) return;
      const f = (s.urlContains || "").trim().toLowerCase();
      if (f && !location.href.toLowerCase().includes(f)) return;
      await sleep(1500);
      await alog("INFO", "Gatilho runOnLoad: página carregada, solicitando execução ao background.");
      api.runtime.sendMessage({ type: "APC_RUN_NOW" }).catch(() => {});
    } catch (e) {}
  })();
})();
