const api = (typeof browser !== "undefined" && browser && browser.runtime) ? browser : chrome;

const KEYS = ["enabled","minutes","seconds","jitterEnabled","jitterMinSec","jitterMaxSec","selectorType","selector","fallbacks","text","enterMode","scope","urlContains","retries","retryDelayMs","runOnEnable","runOnLoad","debugMode","notifyOnFail","watchdogEnabled","watchdogIntervalSec","watchdogMisses","autoReload","maxReloads","verifyAfterReload","maxCyclesEnabled","maxCycles","durationEnabled","durH","durM","durS"];

const FACTORY = {
  enabled: false, minutes: 37, seconds: 14,
  jitterEnabled: false, jitterMinSec: 0, jitterMaxSec: 300,
  selectorType: "css", selector: '[aria-label="Pergunte ao ChatGPT"]',
  fallbacks: 'css|[contenteditable="true"][aria-multiline="true"]\ncss|div[role="textbox"]\ncss|.ProseMirror\nxpath-curto|//div[@contenteditable="true" and @role="textbox"]',
  text: "GOSTEI. OBRIGADO", enterMode: "auto",
  scope: "active", urlContains: "",
  retries: 3, retryDelayMs: 1500,
  runOnEnable: true, runOnLoad: false,
  debugMode: true, notifyOnFail: true,
  watchdogEnabled: true, watchdogIntervalSec: 60, watchdogMisses: 2,
  autoReload: true, maxReloads: 3, verifyAfterReload: true,
  maxCyclesEnabled: false, maxCycles: 1000,
  durationEnabled: false, durH: 0, durM: 0, durS: 0
};

const msgEl = document.getElementById("msg");
function flash(t, ok = true) {
  msgEl.textContent = t;
  msgEl.style.color = ok ? "#1a7f37" : "#b00020";
  setTimeout(() => (msgEl.textContent = ""), 3500);
}

async function load() {
  const s = await api.storage.local.get(KEYS);
  for (const k of KEYS) {
    const el = document.getElementById(k);
    if (!el) continue;
    if (el.type === "checkbox") el.checked = (s[k] !== undefined) ? !!s[k] : !!FACTORY[k];
    else el.value = (s[k] !== undefined && s[k] !== null) ? s[k] : FACTORY[k];
  }
  await refreshCounters();
  await refreshLog();
}

function collect() {
  const patch = {};
  for (const k of KEYS) {
    const el = document.getElementById(k);
    if (!el) continue;
    if (el.type === "checkbox") patch[k] = el.checked;
    else if (el.type === "number") patch[k] = Number(el.value) || 0;
    else patch[k] = el.value;
  }
  return patch;
}

async function applySet(set) {
  for (const k of KEYS) {
    const v = (set[k] !== undefined) ? set[k] : FACTORY[k];
    const el = document.getElementById(k);
    if (!el) continue;
    if (el.type === "checkbox") el.checked = !!v;
    else el.value = v;
  }
}

async function refreshCounters() {
  const s = await api.storage.local.get(["cyclesDone","maxCycles","maxCyclesEnabled","deadlineMs","durationEnabled","disabledByLimit"]);
  const parts = [];
  parts.push("Ciclos executados: " + (s.cyclesDone || 0) + (s.maxCyclesEnabled ? " / limite " + s.maxCycles : " (sem limite)"));
  if (s.durationEnabled && s.deadlineMs) {
    const rest = Math.max(0, s.deadlineMs - Date.now());
    parts.push("Prazo: esgota em " + new Date(s.deadlineMs).toLocaleString("pt-BR") + " (restam " + Math.floor(rest/3600000) + "h" + Math.floor(rest/60000)%60 + "m)");
  } else {
    parts.push("Prazo: sem limite de duração");
  }
  if (s.disabledByLimit) parts.push("Último encerramento por limite: " + s.disabledByLimit);
  document.getElementById("counters").textContent = parts.join(" · ");
}

document.getElementById("save").addEventListener("click", async () => {
  await api.storage.local.set(collect());
  await refreshCounters();
  flash("Configurações salvas ✔ (permanentes)");
});

document.getElementById("testNow").addEventListener("click", async () => {
  await api.storage.local.set(collect());
  flash("Executando teste manual…");
  try { await api.runtime.sendMessage({ type: "APC_RUN_NOW" }); } catch (e) {}
  const s = await api.storage.local.get(["lastResult"]);
  flash("Resultado: " + (s.lastResult || "—"), !String(s.lastResult || "").startsWith("FALHA"));
  await refreshCounters();
  await refreshLog();
});

document.getElementById("probeBtn").addEventListener("click", async () => {
  const out = document.getElementById("probeResult");
  out.textContent = "testando…";
  out.style.color = "#444";
  try {
    const [tab] = await api.tabs.query({ active: true, currentWindow: true });
    if (!tab) { out.textContent = "sem aba ativa"; out.style.color = "#b00020"; return; }
    const r = await api.tabs.sendMessage(tab.id, { type: "APC_PROBE", settings: collect() });
    if (r && r.found) {
      out.textContent = "✔ encontrado via [" + r.used + "] " + (r.desc || "") + (r.editable ? " — editável" : " — NÃO editável");
      out.style.color = r.editable ? "#1a7f37" : "#b06000";
    } else {
      out.textContent = "✘ não encontrado com os localizadores atuais";
      out.style.color = "#b00020";
    }
  } catch (e) {
    out.textContent = "✘ falha: " + (e && e.message) + " (a aba ativa permite content scripts?)";
    out.style.color = "#b00020";
  }
});

document.getElementById("saveAsDefault").addEventListener("click", async () => {
  await api.storage.local.set({ customDefaults: collect() });
  flash("Padrão personalizado registrado ✔");
});
document.getElementById("restoreCustom").addEventListener("click", async () => {
  const { customDefaults } = await api.storage.local.get("customDefaults");
  if (!customDefaults) { flash("Nenhum padrão personalizado salvo.", false); return; }
  const patch = {};
  for (const k of KEYS) patch[k] = customDefaults[k] !== undefined ? customDefaults[k] : FACTORY[k];
  await api.storage.local.set(patch);
  await applySet(patch);
  flash("Padrão personalizado restaurado ✔");
});
document.getElementById("restoreFactory").addEventListener("click", async () => {
  await api.storage.local.remove("customDefaults");
  await api.storage.local.set(FACTORY);
  await applySet(FACTORY);
  flash("Padrão de fábrica restaurado ✔");
});

document.getElementById("resetCounters").addEventListener("click", async () => {
  await api.storage.local.set({ cyclesDone: 0, deadlineMs: null, disabledByLimit: "", wdMisses: 0 });
  await refreshCounters();
  flash("Contadores zerados ✔ (o prazo será recalculado na próxima ativação/execução)");
});

document.getElementById("exportCfg").addEventListener("click", async () => {
  const blob = new Blob([JSON.stringify(collect(), null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "auto_preencher_configuracoes.json";
  a.click();
  URL.revokeObjectURL(a.href);
});
document.getElementById("importCfgBtn").addEventListener("click", () => {
  document.getElementById("importCfgFile").click();
});
document.getElementById("importCfgFile").addEventListener("change", async (ev) => {
  const f = ev.target.files[0];
  if (!f) return;
  try {
    const data = JSON.parse(await f.text());
    const patch = {};
    for (const k of KEYS) if (data[k] !== undefined) patch[k] = data[k];
    await api.storage.local.set(patch);
    await applySet(patch);
    flash("Configurações importadas e salvas ✔");
  } catch (e) {
    flash("Arquivo inválido: " + e.message, false);
  }
  ev.target.value = "";
});

function fmtLog(e) {
  const d = new Date(e.t);
  return d.toLocaleString("pt-BR") + "." + String(d.getMilliseconds()).padStart(3, "0") +
    " [" + String(e.l).padEnd(5) + "] (" + e.s + ") " + e.m;
}
async function refreshLog() {
  const { log = [] } = await api.storage.local.get("log");
  const view = document.getElementById("logView");
  const wasAtBottom = view.scrollTop + view.clientHeight >= view.scrollHeight - 30;
  view.value = log.map(fmtLog).join("\n");
  if (wasAtBottom) view.scrollTop = view.scrollHeight;
}
document.getElementById("refreshLog").addEventListener("click", refreshLog);
document.getElementById("clearLog").addEventListener("click", async () => {
  await api.storage.local.set({ log: [] });
  await refreshLog();
  flash("Log limpo ✔");
});
document.getElementById("exportLog").addEventListener("click", async () => {
  const txt = document.getElementById("logView").value || "(log vazio)";
  const blob = new Blob([txt], { type: "text/plain" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "auto_preencher_log_debug.txt";
  a.click();
  URL.revokeObjectURL(a.href);
});
setInterval(async () => {
  if (document.getElementById("autoRefresh").checked) { await refreshLog(); await refreshCounters(); }
}, 2000);

load();
