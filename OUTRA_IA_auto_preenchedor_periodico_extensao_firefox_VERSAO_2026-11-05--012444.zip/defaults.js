/* Configuração padrão compartilhada por content script, popup e página de opções. */
var AP_DEFAULTS = {
  enabled: true,
  urlFilter: "chatgpt.com",          // vazio = todas as páginas; /regex/i = expressão regular; senão, trecho da URL
  minutes: 37,
  seconds: 14,
  selectorType: "css-selector",      // css-selector | css-path | xpath | outer-html
  target: ".ProseMirror",
  text: "Gostei. Obrigado",
  clearBefore: true,
  submitMode: "enter",               // enter | click | none
  submitSelector: "",                // usado quando submitMode = click
  enterDelayMs: 250,
  runOnLoad: false
};
