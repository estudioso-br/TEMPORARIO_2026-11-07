(function () {
  "use strict";
  var api = typeof browser !== "undefined" ? browser : chrome;
  var $ = function (id) { return document.getElementById(id); };

  function pad(n) { return String(n).padStart(2, "0"); }
  function fmt(ms) {
    var s = Math.max(0, Math.round(ms / 1000));
    return pad(Math.floor(s / 3600)) + ":" + pad(Math.floor(s % 3600 / 60)) + ":" + pad(s % 60);
  }
  function activeTab() { return api.tabs.query({ active: true, currentWindow: true }).then(function (t) { return t[0]; }); }
  function send(msg) {
    return activeTab().then(function (t) { return t ? api.tabs.sendMessage(t.id, msg) : null; }).catch(function () { return null; });
  }

  function refresh() {
    send({ type: "status" }).then(function (st) {
      if (!st) { $("cd").textContent = "--:--:--"; $("info").textContent = "Extensão inativa nesta aba (recarregue a página)."; return; }
      $("cd").textContent = st.enabled && st.urlOk ? fmt(st.nextAt - Date.now()) : "--:--:--";
      var parts = [];
      if (!st.urlOk) parts.push("URL desta aba não corresponde ao filtro.");
      if (st.lastRun) parts.push("Último: " + new Date(st.lastRun).toLocaleTimeString("pt-BR") + " — " + st.lastResult);
      $("info").textContent = parts.join(" ");
    });
  }

  api.storage.local.get("config").then(function (r) {
    var c = Object.assign({}, AP_DEFAULTS, r.config || {});
    $("enabled").checked = c.enabled;
  });
  $("enabled").addEventListener("change", function () {
    api.storage.local.get("config").then(function (r) {
      var c = Object.assign({}, AP_DEFAULTS, r.config || {});
      c.enabled = $("enabled").checked;
      return api.storage.local.set({ config: c });
    });
  });
  $("now").addEventListener("click", function () { send({ type: "fillNow" }).then(refresh); });
  $("test").addEventListener("click", function () {
    send({ type: "test" }).then(function (r) {
      $("info").textContent = !r ? "Sem resposta da página." : r.found ? "Encontrado: " + r.desc : "Elemento NÃO encontrado.";
    });
  });
  $("opts").addEventListener("click", function () { api.runtime.openOptionsPage(); window.close(); });

  refresh();
  setInterval(refresh, 1000);
})();
