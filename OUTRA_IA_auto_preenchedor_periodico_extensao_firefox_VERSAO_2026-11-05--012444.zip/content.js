(function () {
  "use strict";
  if (window.top !== window) return;

  var api = typeof browser !== "undefined" ? browser : chrome;
  var cfg = Object.assign({}, AP_DEFAULTS);
  var nextAt = 0, lastRun = null, lastResult = null, busy = false;

  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };

  /* ---------- configuração e agendamento ---------- */
  function intervalMs() {
    var m = Math.max(0, Number(cfg.minutes) || 0);
    var s = Math.max(0, Number(cfg.seconds) || 0);
    return Math.max(1000, (m * 60 + s) * 1000);
  }

  function urlOk() {
    var f = (cfg.urlFilter || "").trim();
    if (!f) return true;
    var m = f.match(/^\/(.+)\/([a-z]*)$/i);
    if (m) {
      try { return new RegExp(m[1], m[2]).test(location.href); } catch (e) { return false; }
    }
    return location.href.indexOf(f) !== -1;
  }

  function schedule(firstLoad) {
    nextAt = Date.now() + (firstLoad && cfg.runOnLoad ? 3000 : intervalMs());
  }

  function loadConfig(firstLoad) {
    return api.storage.local.get("config").then(function (r) {
      cfg = Object.assign({}, AP_DEFAULTS, r.config || {});
      schedule(firstLoad);
    });
  }

  /* ---------- localização do elemento ---------- */
  function splitTop(str) {           // separa por espaços fora de [] ()
    var out = [], cur = "", d = 0;
    for (var i = 0; i < str.length; i++) {
      var c = str[i];
      if (c === "[" || c === "(") d++;
      if (c === "]" || c === ")") d = Math.max(0, d - 1);
      if (/\s/.test(c) && d === 0) { if (cur) out.push(cur); cur = ""; } else cur += c;
    }
    if (cur) out.push(cur);
    return out;
  }

  function splitDots(tok) {          // separa por "." fora de [] ()
    var out = [], cur = "", d = 0;
    for (var i = 0; i < tok.length; i++) {
      var c = tok[i];
      if (c === "[" || c === "(") d++;
      if (c === "]" || c === ")") d = Math.max(0, d - 1);
      if (c === "." && d === 0) { out.push(cur); cur = ""; } else cur += c;
    }
    out.push(cur);
    return out;
  }

  function validSel(s) {
    try { document.createDocumentFragment().querySelector(s); return true; } catch (e) { return false; }
  }

  // Remove partes inválidas (ex.: classes Tailwind "[--x:y]", "group/x", "@max-x") de caminhos copiados do DevTools.
  function sanitizePath(path) {
    return splitTop(path.trim()).map(function (t) {
      if (t === ">" || t === "+" || t === "~") return t;
      var out = "";
      splitDots(t).forEach(function (p, i) {
        if (!p) return;
        var piece = i === 0 ? p : "." + p;
        if (validSel(piece)) out += piece;
      });
      return out;
    }).filter(Boolean).join(" ");
  }

  function qs(sel) {
    try { return sel ? document.querySelector(sel) : null; } catch (e) { return null; }
  }

  function locateCss(raw) {
    var sel = raw.trim();
    if (sel.charAt(0) === "{") {     // aceita o JSON da árvore de acessibilidade
      try { var j = JSON.parse(sel); if (j.nodeCssSelector) sel = j.nodeCssSelector; } catch (e) { /* ignora */ }
    }
    var el = qs(sel);
    if (el) return el;
    var clean = sanitizePath(sel);
    el = qs(clean);
    if (el) return el;
    var toks = splitTop(clean);
    el = qs(toks.slice(-3).join(" "));
    if (el) return el;
    return qs(toks.slice(-1).join(" "));
  }

  function locateXPath(x) {
    try {
      return document.evaluate(x.trim(), document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
    } catch (e) { return null; }
  }

  // Encontra no DOM atual o elemento mais parecido com o HTML externo informado.
  function locateHtml(html) {
    var tpl = document.createElement("template");
    tpl.innerHTML = html.trim();
    var ref = tpl.content.firstElementChild;
    if (!ref) return null;
    var cands = Array.prototype.slice.call(document.getElementsByTagName(ref.tagName.toLowerCase()));
    var refClasses = Array.prototype.slice.call(ref.classList);
    var best = null, bestScore = 0;
    cands.forEach(function (c) {
      var score = 0;
      Array.prototype.forEach.call(ref.attributes, function (a) {
        if (a.name === "style") return;
        if (a.name === "class") {
          refClasses.forEach(function (k) { if (c.classList.contains(k)) score += 1; });
        } else if (c.getAttribute(a.name) === a.value) {
          score += a.name === "id" ? 6 : 2;
        }
      });
      if (score > bestScore) { bestScore = score; best = c; }
    });
    return best;
  }

  function locate() {
    var t = cfg.target || "";
    switch (cfg.selectorType) {
      case "xpath": return locateXPath(t);
      case "outer-html": return locateHtml(t);
      default: return locateCss(t);
    }
  }

  function isEditable(el) {
    return el.isContentEditable || /^(textarea|input)$/i.test(el.tagName);
  }

  // Se o alvo for um contêiner (ex.: o rodapé do compositor), usa o campo editável dentro dele.
  function resolveEditable(el) {
    if (isEditable(el)) return el;
    var inner = el.querySelector(
      'textarea, input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]), ' +
      '[contenteditable=""], [contenteditable="true"], [contenteditable="plaintext-only"]');
    return inner || el;
  }

  /* ---------- preenchimento ---------- */
  function setNativeValue(el, value) {
    var proto = el.tagName.toLowerCase() === "textarea" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    var desc = Object.getOwnPropertyDescriptor(proto, "value");
    if (desc && desc.set) desc.set.call(el, value); else el.value = value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function fillEditable(el, text) {
    el.focus();
    if (/^(textarea|input)$/i.test(el.tagName)) {
      setNativeValue(el, cfg.clearBefore ? text : (el.value || "") + text);
      return;
    }
    var sel = window.getSelection();
    var range = document.createRange();
    range.selectNodeContents(el);
    if (!cfg.clearBefore) range.collapse(false);
    sel.removeAllRanges();
    sel.addRange(range);
    var ok = false;
    try { ok = document.execCommand("insertText", false, text); } catch (e) { ok = false; }
    if (!ok) {
      if (cfg.clearBefore) el.textContent = "";
      el.textContent += text;
      el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    }
  }

  function pressEnter(el) {
    var init = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true, composed: true };
    ["keydown", "keypress", "keyup"].forEach(function (type) {
      el.dispatchEvent(new KeyboardEvent(type, init));
    });
  }

  function flash(el) {
    var old = el.style.outline;
    el.style.outline = "3px solid #e0245e";
    setTimeout(function () { el.style.outline = old; }, 2000);
  }

  async function runFill(manual) {
    if (busy) return;
    busy = true;
    try {
      var target = locate();
      if (!target) throw new Error("Elemento não encontrado com o tipo/valor configurados.");
      var el = resolveEditable(target);
      fillEditable(el, cfg.text || "");
      await sleep(Math.max(0, Number(cfg.enterDelayMs) || 0));
      if (cfg.submitMode === "enter") {
        pressEnter(el);
      } else if (cfg.submitMode === "click") {
        var btn = qs(cfg.submitSelector);
        if (!btn) throw new Error("Botão de envio não encontrado (" + cfg.submitSelector + ").");
        btn.click();
      }
      lastResult = "OK";
    } catch (e) {
      lastResult = "Erro: " + e.message;
    } finally {
      lastRun = Date.now();
      nextAt = Date.now() + intervalMs();
      busy = false;
    }
  }

  /* ---------- mensagens (popup) ---------- */
  function status() {
    return { enabled: cfg.enabled, urlOk: urlOk(), nextAt: nextAt, lastRun: lastRun, lastResult: lastResult };
  }

  api.runtime.onMessage.addListener(function (msg) {
    if (!msg || !msg.type) return;
    if (msg.type === "status") return Promise.resolve(status());
    if (msg.type === "fillNow") return runFill(true).then(status);
    if (msg.type === "test") {
      var t = locate();
      if (!t) return Promise.resolve({ found: false });
      var el = resolveEditable(t);
      flash(el);
      return Promise.resolve({
        found: true,
        desc: el.tagName.toLowerCase() + (el.id ? "#" + el.id : "") + (isEditable(el) ? " (editável)" : " (NÃO editável)")
      });
    }
  });

  api.storage.onChanged.addListener(function (changes, area) {
    if (area === "local" && changes.config) loadConfig(false);
  });

  setInterval(function () {
    if (!cfg.enabled || busy || !urlOk()) return;
    if (Date.now() >= nextAt) runFill(false);
  }, 1000);

  loadConfig(true);
})();
