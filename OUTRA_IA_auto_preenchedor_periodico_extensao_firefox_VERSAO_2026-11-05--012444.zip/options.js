(function () {
  "use strict";
  var api = typeof browser !== "undefined" ? browser : chrome;
  var $ = function (id) { return document.getElementById(id); };
  var TEXT = ["urlFilter", "target", "text", "submitSelector", "selectorType", "submitMode"];
  var NUM = ["minutes", "seconds", "enterDelayMs"];
  var BOOL = ["enabled", "clearBefore", "runOnLoad"];

  function toForm(c) {
    TEXT.forEach(function (k) { $(k).value = c[k]; });
    NUM.forEach(function (k) { $(k).value = c[k]; });
    BOOL.forEach(function (k) { $(k).checked = !!c[k]; });
  }
  function fromForm() {
    var c = {};
    TEXT.forEach(function (k) { c[k] = $(k).value; });
    NUM.forEach(function (k) { c[k] = Math.max(0, Number($(k).value) || 0); });
    BOOL.forEach(function (k) { c[k] = $(k).checked; });
    return c;
  }
  function say(t) { $("msg").textContent = t; setTimeout(function () { $("msg").textContent = ""; }, 2500); }

  api.storage.local.get("config").then(function (r) { toForm(Object.assign({}, AP_DEFAULTS, r.config || {})); });
  $("save").addEventListener("click", function () {
    api.storage.local.set({ config: fromForm() }).then(function () { say("Salvo."); });
  });
  $("reset").addEventListener("click", function () {
    toForm(AP_DEFAULTS);
    api.storage.local.set({ config: Object.assign({}, AP_DEFAULTS) }).then(function () { say("Padrão restaurado."); });
  });
})();
